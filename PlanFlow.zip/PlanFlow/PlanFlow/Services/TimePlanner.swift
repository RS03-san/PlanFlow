import Foundation

/// 每天的工作時段設定
struct WorkHours {
    var start: Int          // 例如 540 = 09:00
    var end: Int            // 例如 1080 = 18:00
    var breakStart: Int?    // 午休開始
    var breakEnd: Int?      // 午休結束
    var gap: Int            // 兩項工作之間的休息（分鐘）

    static var current: WorkHours {
        let d = UserDefaults.standard
        func int(_ key: String, _ fallback: Int) -> Int { d.object(forKey: key) as? Int ?? fallback }
        let breakOn = d.object(forKey: SettingsKey.breakOn) as? Bool ?? true
        let start = int(SettingsKey.workStart, 540)
        let end = max(int(SettingsKey.workEnd, 1080), start + 30)
        return WorkHours(
            start: start,
            end: end,
            breakStart: breakOn ? int(SettingsKey.breakStart, 720) : nil,
            breakEnd: breakOn ? int(SettingsKey.breakEnd, 780) : nil,
            gap: int(SettingsKey.taskGap, 10)
        )
    }

    /// 扣掉午休後可以用的分鐘數
    var availableMinutes: Int {
        var total = end - start
        if let bs = breakStart, let be = breakEnd, be > bs {
            total -= max(0, min(be, end) - max(bs, start))
        }
        return max(total, 0)
    }
}

/// 把一天裡的工作排進具體時段
enum TimePlanner {

    enum Mode {
        /// 只幫「還沒有時段」的工作找空檔，已經排好的不動
        case fillMissing
        /// 除了自己指定時間的工作，其他全部重新排
        case replanAll
    }

    struct Result {
        var assigned: [UUID: Int] = [:]
        /// 當天塞不下的工作
        var unplaced: [UUID] = []
    }

    private struct Busy {
        let start: Int
        let end: Int
        let gap: Int
    }

    static func plan(
        day: Date,
        tasks dayTasks: [TaskItem],
        hours: WorkHours,
        mode: Mode,
        now: Date = Date()
    ) -> Result {
        var result = Result()
        // 過去的日子不排
        guard day.startOfDay >= Date.today else { return result }

        var busy: [Busy] = []
        if let bs = hours.breakStart, let be = hours.breakEnd, be > bs {
            busy.append(Busy(start: bs, end: be, gap: 0))
        }

        var toPlace: [TaskItem] = []
        for t in dayTasks {
            if let s = t.startMinute {
                let keep = t.isDone || t.timeLocked || mode == .fillMissing
                if keep {
                    busy.append(Busy(start: s, end: s + t.estimatedMinutes, gap: hours.gap))
                } else {
                    toPlace.append(t)
                }
            } else if !t.isDone {
                toPlace.append(t)
            }
        }

        // 今天的話，從現在之後開始排
        var earliest = hours.start
        if day.isSameDay(as: now) {
            earliest = max(earliest, roundUp(now.minuteOfDay, to: 5))
        }

        let ordered = toPlace.sorted { a, b in
            if a.priorityRaw != b.priorityRaw { return a.priorityRaw > b.priorityRaw }
            switch (a.deadline, b.deadline) {
            case let (x?, y?) where x != y: return x < y
            case (.some, .none): return true
            case (.none, .some): return false
            default: return a.createdAt < b.createdAt
            }
        }

        for t in ordered {
            var s = earliest
            var placed: Int?
            while s + t.estimatedMinutes <= hours.end {
                let e = s + t.estimatedMinutes
                if let clash = busy.first(where: { s < $0.end + $0.gap && $0.start < e + $0.gap }) {
                    s = roundUp(clash.end + clash.gap, to: 5)
                } else {
                    placed = s
                    break
                }
            }
            if let p = placed {
                result.assigned[t.id] = p
                busy.append(Busy(start: p, end: p + t.estimatedMinutes, gap: hours.gap))
            } else {
                result.unplaced.append(t.id)
            }
        }
        return result
    }

    private static func roundUp(_ value: Int, to step: Int) -> Int {
        ((value + step - 1) / step) * step
    }
}
