import Foundation
import SwiftUI

extension Date {
    static var today: Date { Calendar.current.startOfDay(for: Date()) }

    var startOfDay: Date { Calendar.current.startOfDay(for: self) }

    func adding(days: Int) -> Date {
        (Calendar.current.date(byAdding: .day, value: days, to: self) ?? self)
    }

    var isWeekend: Bool { Calendar.current.isDateInWeekend(self) }

    func isSameDay(as other: Date) -> Bool {
        Calendar.current.isDate(self, inSameDayAs: other)
    }

    /// 從 self 到 other 相差幾天（以日期計）
    func daysBetween(_ other: Date) -> Int {
        Calendar.current.dateComponents([.day], from: startOfDay, to: other.startOfDay).day ?? 0
    }

    /// 下一個星期一（不含今天）
    var nextMonday: Date {
        var d = startOfDay.adding(days: 1)
        while Calendar.current.component(.weekday, from: d) != 2 {
            d = d.adding(days: 1).startOfDay
        }
        return d
    }

    /// 這一週的星期日
    var weekStartSunday: Date {
        let wd = Calendar.current.component(.weekday, from: self)
        return startOfDay.adding(days: -(wd - 1)).startOfDay
    }
}

enum DateText {
    private static let locale = Locale(identifier: "zh_Hant_TW")

    private static func formatter(_ format: String) -> DateFormatter {
        let f = DateFormatter()
        f.locale = locale
        f.dateFormat = format
        return f
    }

    private static let mdF = formatter("M/d (EEE)")
    private static let shortF = formatter("M/d")
    private static let fullF = formatter("M月d日 EEEE")
    private static let monthF = formatter("yyyy年M月")
    private static let keyF = formatter("yyyy-MM-dd")
    private static let timeF = formatter("HH:mm")

    static let weekdaySymbols = ["日", "一", "二", "三", "四", "五", "六"]

    static func md(_ d: Date) -> String { mdF.string(from: d) }
    static func short(_ d: Date) -> String { shortF.string(from: d) }
    static func full(_ d: Date) -> String { fullF.string(from: d) }
    static func month(_ d: Date) -> String { monthF.string(from: d) }
    static func key(_ d: Date) -> String { keyF.string(from: d) }
    static func time(_ d: Date) -> String { timeF.string(from: d) }

    /// 今天 / 明天 / 後天 / 昨天 / 10/27 (週二)
    static func relative(_ d: Date) -> String {
        switch Date.today.daysBetween(d) {
        case 0: return "今天"
        case 1: return "明天"
        case 2: return "後天"
        case -1: return "昨天"
        default: return md(d)
        }
    }

    static func duration(_ minutes: Int) -> String {
        if minutes < 60 { return "\(minutes) 分鐘" }
        let h = minutes / 60
        let m = minutes % 60
        return m == 0 ? "\(h) 小時" : "\(h) 小時 \(m) 分"
    }
}

extension Color {
    init(hex: String) {
        var s = hex.trimmingCharacters(in: .whitespacesAndNewlines)
            .replacingOccurrences(of: "#", with: "")
        if s.count != 6 { s = "4F7CFF" }
        var value: UInt64 = 0
        Scanner(string: s).scanHexInt64(&value)
        self.init(
            red: Double((value >> 16) & 0xFF) / 255,
            green: Double((value >> 8) & 0xFF) / 255,
            blue: Double(value & 0xFF) / 255
        )
    }
}

enum SettingsKey {
    static let dailyCapacity = "dailyCapacity"
    static let skipWeekends = "skipWeekends"
    static let promptRollover = "promptRollover"
    static let lastRolloverPrompt = "lastRolloverPrompt"
    static let reminderHour = "reminderHour"
    static let didSeed = "didSeed"
}
