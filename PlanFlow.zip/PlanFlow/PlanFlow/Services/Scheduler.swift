import Foundation

struct ScheduleSettings {
    var dailyCapacity: Int
    var skipWeekends: Bool

    static var current: ScheduleSettings {
        let d = UserDefaults.standard
        let cap = d.object(forKey: SettingsKey.dailyCapacity) as? Int ?? 240
        return ScheduleSettings(dailyCapacity: cap, skipWeekends: d.bool(forKey: SettingsKey.skipWeekends))
    }
}

/// 智慧排程：依照「優先順序 → 截止日 → 所需時間」排序，
/// 把工作放進「每日可用時間」還裝得下的最早一天，並盡量不超過截止日。
enum Scheduler {

    /// 每天已排的未完成工作量（分鐘）
    static func load(of tasks: [TaskItem], excluding: Set<UUID> = []) -> [Date: Int] {
        var map: [Date: Int] = [:]
        for t in tasks where !t.isDone && !excluding.contains(t.id) {
            map[t.scheduledDate.startOfDay, default: 0] += t.estimatedMinutes
        }
        return map
    }

    /// 一次幫多項工作排日期。回傳 [工作 id: 建議日期]
    static func plan(
        _ moving: [TaskItem],
        allTasks: [TaskItem],
        start: Date,
        settings: ScheduleSettings = .current
    ) -> [UUID: Date] {
        let movingIDs = Set(moving.map(\.id))
        var dayLoad = load(of: allTasks, excluding: movingIDs)

        let ordered = moving.sorted { a, b in
            if a.priorityRaw != b.priorityRaw { return a.priorityRaw > b.priorityRaw }
            switch (a.deadline, b.deadline) {
            case let (x?, y?) where x != y: return x < y
            case (.some, .none): return true
            case (.none, .some): return false
            default: break
            }
            return a.estimatedMinutes < b.estimatedMinutes
        }

        var result: [UUID: Date] = [:]
        let first = start.startOfDay
        for task in ordered {
            let day = bestDay(
                minutes: task.estimatedMinutes,
                deadline: task.deadline,
                load: dayLoad,
                start: first,
                settings: settings
            )
            result[task.id] = day
            dayLoad[day, default: 0] += task.estimatedMinutes
        }
        return result
    }

    /// 幫單一工作找建議日期
    static func suggest(for task: TaskItem, allTasks: [TaskItem], start: Date) -> Date {
        plan([task], allTasks: allTasks, start: start)[task.id] ?? start.startOfDay
    }

    /// 幫還沒建立的工作（新增畫面）找建議日期
    static func suggest(
        minutes: Int,
        deadline: Date?,
        allTasks: [TaskItem],
        excluding: Set<UUID> = [],
        start: Date
    ) -> Date {
        bestDay(
            minutes: minutes,
            deadline: deadline,
            load: load(of: allTasks, excluding: excluding),
            start: start.startOfDay,
            settings: .current
        )
    }

    /// 某天排太滿時，找出應該移走的工作（保留優先順序高的）
    static func overflow(of dayTasks: [TaskItem], capacity: Int) -> [TaskItem] {
        let open = dayTasks.filter { !$0.isDone }.sorted {
            if $0.priorityRaw != $1.priorityRaw { return $0.priorityRaw > $1.priorityRaw }
            return $0.createdAt < $1.createdAt
        }
        var used = 0
        var extra: [TaskItem] = []
        for t in open {
            if used == 0 || used + t.estimatedMinutes <= capacity {
                used += t.estimatedMinutes
            } else {
                extra.append(t)
            }
        }
        return extra
    }

    // MARK: - 內部

    private static func isAllowed(_ day: Date, _ s: ScheduleSettings) -> Bool {
        !(s.skipWeekends && day.isWeekend)
    }

    private static func bestDay(
        minutes: Int,
        deadline: Date?,
        load: [Date: Int],
        start: Date,
        settings: ScheduleSettings
    ) -> Date {
        let cap = max(settings.dailyCapacity, 15)
        // 截止日已過的話，就只看起始日
        let limitDay: Date? = deadline.map { max($0.startOfDay, start) }

        var day = start
        var fallback: Date?
        var fallbackLoad = Int.max

        for _ in 0..<366 {
            if let limitDay, day > limitDay { break }
            if isAllowed(day, settings) {
                let used = load[day] ?? 0
                if used == 0 || used + minutes <= cap { return day }
                if used < fallbackLoad {
                    fallback = day
                    fallbackLoad = used
                }
            }
            day = day.adding(days: 1).startOfDay
        }

        // 截止日前每天都滿了 → 放到最空的那天
        if let fallback { return fallback }

        // 截止日前沒有可用日（例如只剩週末）→ 從起始日找第一個可用日
        var d = start
        for _ in 0..<14 {
            if isAllowed(d, settings) { return d }
            d = d.adding(days: 1).startOfDay
        }
        return start
    }
}
