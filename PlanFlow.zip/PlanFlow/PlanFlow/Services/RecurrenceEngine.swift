import Foundation
import SwiftData

/// 根據重複規則產生未來的工作
@MainActor
enum RecurrenceEngine {
    /// 預先產生幾天後的工作（行事曆、時間表、每日工作量都看得到）
    static let horizonDays = 28

    /// 開 App、回到 App、修改重複規則時呼叫
    static func refresh(context: ModelContext) {
        let allSeries = (try? context.fetch(FetchDescriptor<RecurringSeries>())) ?? []
        guard !allSeries.isEmpty else { return }
        let tasks = (try? context.fetch(FetchDescriptor<TaskItem>())) ?? []
        let today = Date.today
        let horizon = today.adding(days: horizonDays).startOfDay

        for s in allSeries {
            let mine = tasks.filter { $0.seriesID == s.id }

            // 1. 錯過的就略過（不累積成逾期）
            if s.skipMissed {
                for t in mine where !t.isDone && !t.detached && t.scheduledDate.startOfDay < today {
                    NotificationManager.cancel(for: t)
                    context.delete(t)
                }
            }

            // 2. 產生到 4 週後
            let existing = Set(mine.compactMap { $0.occurrenceDate?.startOfDay })
            var day = s.anchorDate.startOfDay
            if let g = s.generatedUntil { day = max(day, g.startOfDay.adding(days: 1).startOfDay) }
            day = max(day, today)
            var end = horizon
            if let u = s.untilDate { end = min(end, u.startOfDay) }

            while day <= end {
                if s.matches(day) && !existing.contains(day) {
                    let t = makeTask(from: s, on: day)
                    context.insert(t)
                    NotificationManager.schedule(for: t)
                }
                day = day.adding(days: 1).startOfDay
            }
            if end > (s.generatedUntil ?? .distantPast) {
                s.generatedUntil = end
            }
        }
    }

    static func makeTask(from s: RecurringSeries, on day: Date) -> TaskItem {
        let t = TaskItem(
            title: s.title,
            notes: s.notes,
            scheduledDate: day,
            deadline: s.deadlineOffset.map { day.adding(days: $0) },
            priority: Priority(rawValue: s.priorityRaw) ?? .medium,
            estimatedMinutes: s.estimatedMinutes,
            category: s.category
        )
        t.seriesID = s.id
        t.occurrenceDate = day.startOfDay
        if let m = s.startMinute {
            t.startMinute = m
            t.timeLocked = true
        }
        return t
    }

    /// 修改規則或內容後：刪掉之後還沒完成的，再依新規則重新產生
    static func regenerate(_ s: RecurringSeries, keeping keep: TaskItem?, context: ModelContext) {
        let tasks = (try? context.fetch(FetchDescriptor<TaskItem>())) ?? []
        let today = Date.today
        for t in tasks where t.seriesID == s.id && t.id != keep?.id && !t.isDone && !t.detached
            && t.scheduledDate.startOfDay >= today {
            NotificationManager.cancel(for: t)
            context.delete(t)
        }
        s.generatedUntil = nil
        refresh(context: context)
    }

    /// 停止重複：刪掉之後還沒完成的，保留 keep 這一次（變成一般工作）
    static func stop(_ s: RecurringSeries, keeping keep: TaskItem?, context: ModelContext) {
        let tasks = (try? context.fetch(FetchDescriptor<TaskItem>())) ?? []
        let today = Date.today
        for t in tasks where t.seriesID == s.id {
            if t.id == keep?.id {
                t.seriesID = nil
                t.occurrenceDate = nil
            } else if !t.isDone && t.scheduledDate.startOfDay >= today {
                NotificationManager.cancel(for: t)
                context.delete(t)
            }
        }
        context.delete(s)
    }
}
