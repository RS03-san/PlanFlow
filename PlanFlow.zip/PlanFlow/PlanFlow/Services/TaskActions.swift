import Foundation
import SwiftData
import UIKit

/// 所有修改工作的動作集中在這裡，確保通知、延後次數都會一起更新。
@MainActor
enum TaskActions {

    static func toggleDone(_ task: TaskItem) {
        task.isDone.toggle()
        task.completedAt = task.isDone ? Date() : nil
        if task.isDone {
            UINotificationFeedbackGenerator().notificationOccurred(.success)
            NotificationManager.cancel(for: task)
        } else {
            NotificationManager.schedule(for: task)
        }
    }

    /// 把工作移到某一天。往後移會計入「延後次數」，提醒時間也會跟著平移。
    static func reschedule(_ task: TaskItem, to date: Date) {
        let newDay = date.startOfDay
        let oldDay = task.scheduledDate.startOfDay
        guard newDay != oldDay else { return }

        let delta = oldDay.daysBetween(newDay)
        task.scheduledDate = newDay
        if delta > 0 { task.rescheduleCount += 1 }
        // 自動排的時段到新的一天要重新排；自己指定的時間保留
        if !task.timeLocked { task.startMinute = nil }

        if let reminder = task.reminderDate {
            task.reminderDate = reminder.adding(days: delta)
        }
        NotificationManager.schedule(for: task)
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
    }

    static func apply(_ plan: [UUID: Date], to tasks: [TaskItem]) {
        for t in tasks {
            if let d = plan[t.id] { reschedule(t, to: d) }
        }
    }

    /// 幫某一天的工作排時段。回傳排不下的工作。
    @discardableResult
    static func arrangeTimes(day: Date, tasks dayTasks: [TaskItem], mode: TimePlanner.Mode) -> [TaskItem] {
        let result = TimePlanner.plan(day: day, tasks: dayTasks, hours: .current, mode: mode)
        let unplaced = Set(result.unplaced)
        for t in dayTasks {
            if let m = result.assigned[t.id] {
                if t.startMinute != m {
                    t.startMinute = m
                    NotificationManager.schedule(for: t)
                }
            } else if unplaced.contains(t.id), t.startMinute != nil {
                t.startMinute = nil
                NotificationManager.schedule(for: t)
            }
        }
        return dayTasks.filter { unplaced.contains($0.id) }
    }

    static func delete(_ task: TaskItem, in context: ModelContext) {
        NotificationManager.cancel(for: task)
        context.delete(task)
    }
}
