import Foundation
import SwiftData
import UIKit

/// 所有修改工作的動作集中在這裡，確保通知、延後次數都會一起更新。
@MainActor
enum TaskActions {

    static func toggleDone(_ task: TaskItem) {
        task.isDone.toggle()
        task.completedAt = task.isDone ? Date() : nil
        if task.isDone {
            UINotificationFeedbackGenerator().notificationOccurred(.success)
            NotificationManager.cancel(for: task)
        } else {
            NotificationManager.schedule(for: task)
        }
    }

    /// 把工作移到某一天。往後移會計入「延後次數」，提醒時間也會跟著平移。
    static func reschedule(_ task: TaskItem, to date: Date) {
        let newDay = date.startOfDay
        let oldDay = task.scheduledDate.startOfDay
        guard newDay != oldDay else { return }

        let delta = oldDay.daysBetween(newDay)
        task.scheduledDate = newDay
        if delta > 0 { task.rescheduleCount += 1 }

        if let reminder = task.reminderDate {
            task.reminderDate = reminder.adding(days: delta)
        }
        NotificationManager.schedule(for: task)
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
    }

    static func apply(_ plan: [UUID: Date], to tasks: [TaskItem]) {
        for t in tasks {
            if let d = plan[t.id] { reschedule(t, to: d) }
        }
    }

    static func delete(_ task: TaskItem, in context: ModelContext) {
        NotificationManager.cancel(for: task)
        context.delete(task)
    }
}
