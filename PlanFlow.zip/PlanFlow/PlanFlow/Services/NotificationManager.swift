import Foundation
import UserNotifications

enum NotificationManager {

    @discardableResult
    static func requestAuthorization() async -> Bool {
        do {
            return try await UNUserNotificationCenter.current()
                .requestAuthorization(options: [.alert, .sound, .badge])
        } catch {
            return false
        }
    }

    /// 依照工作目前的狀態重新安排通知（會先清掉舊的）
    static func schedule(for task: TaskItem) {
        let center = UNUserNotificationCenter.current()
        let ids = identifiers(for: task)
        center.removePendingNotificationRequests(withIdentifiers: ids)
        guard !task.isDone else { return }

        // 1. 使用者自己設定的提醒時間
        if let reminder = task.reminderDate, reminder > Date() {
            let content = UNMutableNotificationContent()
            content.title = task.title
            content.body = task.notes.isEmpty ? "該處理這項工作了" : task.notes
            content.sound = .default
            let comps = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute], from: reminder)
            let trigger = UNCalendarNotificationTrigger(dateMatching: comps, repeats: false)
            center.add(UNNotificationRequest(identifier: ids[0], content: content, trigger: trigger))
        }

        // 2. 時段開始前 5 分鐘提醒
        let startOn = UserDefaults.standard.object(forKey: SettingsKey.startReminder) as? Bool ?? true
        if startOn, let start = task.startDate {
            let fire = start.addingTimeInterval(-5 * 60)
            if fire > Date() {
                let content = UNMutableNotificationContent()
                content.title = "5 分鐘後開始：\(task.title)"
                content.body = task.timeRangeText ?? ""
                content.sound = .default
                let comps = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute], from: fire)
                let trigger = UNCalendarNotificationTrigger(dateMatching: comps, repeats: false)
                center.add(UNNotificationRequest(identifier: ids[2], content: content, trigger: trigger))
            }
        }

        // 3. 截止日前一天提醒
        if let deadline = task.deadline {
            let hour = UserDefaults.standard.object(forKey: SettingsKey.reminderHour) as? Int ?? 9
            var comps = Calendar.current.dateComponents([.year, .month, .day], from: deadline.startOfDay.adding(days: -1))
            comps.hour = hour
            comps.minute = 0
            if let fire = Calendar.current.date(from: comps), fire > Date() {
                let content = UNMutableNotificationContent()
                content.title = "明天截止：\(task.title)"
                content.body = "還沒完成的話，記得今天安排時間處理。"
                content.sound = .default
                let trigger = UNCalendarNotificationTrigger(dateMatching: comps, repeats: false)
                center.add(UNNotificationRequest(identifier: ids[1], content: content, trigger: trigger))
            }
        }
    }

    static func cancel(for task: TaskItem) {
        UNUserNotificationCenter.current()
            .removePendingNotificationRequests(withIdentifiers: identifiers(for: task))
    }

    private static func identifiers(for task: TaskItem) -> [String] {
        ["\(task.id.uuidString)-reminder", "\(task.id.uuidString)-deadline", "\(task.id.uuidString)-start"]
    }
}
