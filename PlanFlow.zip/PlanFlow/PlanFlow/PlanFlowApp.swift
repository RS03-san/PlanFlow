import SwiftUI
import SwiftData

@main
struct PlanFlowApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) private var appDelegate

    var body: some Scene {
        WindowGroup {
            RootView()
        }
        .modelContainer(for: [TaskItem.self, TaskCategory.self, RecurringSeries.self])
    }
}
