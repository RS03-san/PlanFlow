import Foundation
import SwiftData

enum RepeatFreq: String, CaseIterable, Identifiable {
    case daily, weekly, monthly
    var id: String { rawValue }
}

/// 編輯畫面上的「重複」選項
enum RepeatPreset: String, CaseIterable, Identifiable {
    case none = "不重複"
    case daily = "每天"
    case weekdays = "平日（一到五）"
    case weekly = "每週"
    case monthly = "每月"
    case everyNDays = "每隔幾天"
    var id: String { rawValue }
}

/// 一組重複工作的規則與內容。實際每一次會產生成一個 TaskItem。
@Model
final class RecurringSeries {
    var id: UUID = UUID()
    var title: String = ""
    var notes: String = ""
    var priorityRaw: Int = 1
    var estimatedMinutes: Int = 30
    var category: TaskCategory?
    /// 固定開始時間（分鐘）；nil = 自動排時段
    var startMinute: Int?
    /// 截止日 = 當天 + N 天；nil = 沒有截止日
    var deadlineOffset: Int?
    var freqRaw: String = "daily"
    var interval: Int = 1
    /// Calendar 的 weekday（1 = 星期日 … 7 = 星期六），用逗號分隔
    var weekdaysRaw: String = ""
    /// 從哪一天開始
    var anchorDate: Date = Date()
    /// 重複到哪一天（nil = 一直重複）
    var untilDate: Date?
    /// 沒完成就略過，不累積成逾期工作
    var skipMissed: Bool = true
    /// 已經產生到哪一天
    var generatedUntil: Date?
    var createdAt: Date = Date()

    init() {
        self.id = UUID()
        self.createdAt = Date()
    }

    var freq: RepeatFreq {
        get { RepeatFreq(rawValue: freqRaw) ?? .daily }
        set { freqRaw = newValue.rawValue }
    }

    var weekdays: Set<Int> {
        get { Set(weekdaysRaw.split(separator: ",").compactMap { Int($0) }) }
        set { weekdaysRaw = newValue.sorted().map(String.init).joined(separator: ",") }
    }

    /// 這一天要不要產生一次
    func matches(_ day: Date) -> Bool {
        let cal = Calendar.current
        let d = day.startOfDay
        let a = anchorDate.startOfDay
        guard d >= a else { return false }
        if let u = untilDate, d > u.startOfDay { return false }
        let n = max(interval, 1)

        switch freq {
        case .daily:
            return a.daysBetween(d) % n == 0
        case .weekly:
            let wd = cal.component(.weekday, from: d)
            let days = weekdays.isEmpty ? [cal.component(.weekday, from: a)] : weekdays
            guard days.contains(wd) else { return false }
            let weeks = a.weekStartSunday.daysBetween(d.weekStartSunday) / 7
            return weeks % n == 0
        case .monthly:
            let anchorDay = cal.component(.day, from: a)
            let daysInMonth = cal.range(of: .day, in: .month, for: d)?.count ?? 31
            guard cal.component(.day, from: d) == min(anchorDay, daysInMonth) else { return false }
            let months = (cal.component(.year, from: d) - cal.component(.year, from: a)) * 12
                + cal.component(.month, from: d) - cal.component(.month, from: a)
            return months % n == 0
        }
    }

    /// 例如「每天」「每週一、三」「每月 5 日」
    var summary: String {
        let n = max(interval, 1)
        let cal = Calendar.current
        switch freq {
        case .daily:
            return n == 1 ? "每天" : "每 \(n) 天"
        case .weekly:
            let names = ["日", "一", "二", "三", "四", "五", "六"]
            let days = weekdays.isEmpty ? [cal.component(.weekday, from: anchorDate)] : weekdays
            if n == 1 && days == Set(2...6) { return "平日（一到五）" }
            let list = days.sorted().map { names[$0 - 1] }.joined(separator: "、")
            return n == 1 ? "每週\(list)" : "每 \(n) 週的週\(list)"
        case .monthly:
            let day = cal.component(.day, from: anchorDate)
            return n == 1 ? "每月 \(day) 日" : "每 \(n) 個月的 \(day) 日"
        }
    }
}
