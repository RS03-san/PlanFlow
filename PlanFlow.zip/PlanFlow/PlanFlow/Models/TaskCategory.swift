import Foundation
import SwiftData

@Model
final class TaskCategory {
    var name: String = ""
    var colorHex: String = "#4F7CFF"
    var symbol: String = "folder.fill"
    var sortOrder: Int = 0
    @Relationship(deleteRule: .nullify, inverse: \TaskItem.category)
    var tasks: [TaskItem]? = []
    @Relationship(deleteRule: .nullify, inverse: \RecurringSeries.category)
    var series: [RecurringSeries]? = []

    init(name: String, colorHex: String, symbol: String, sortOrder: Int) {
        self.name = name
        self.colorHex = colorHex
        self.symbol = symbol
        self.sortOrder = sortOrder
    }

    static let palette: [String] = [
        "#4F7CFF", "#8E5CF6", "#22B07D", "#F59E0B",
        "#EF4444", "#EC4899", "#14B8A6", "#64748B"
    ]

    static let symbols: [String] = [
        "briefcase.fill", "book.fill", "leaf.fill", "tray.fill",
        "flask.fill", "house.fill", "heart.fill", "cart.fill",
        "graduationcap.fill", "person.2.fill", "dumbbell.fill", "star.fill"
    ]
}
