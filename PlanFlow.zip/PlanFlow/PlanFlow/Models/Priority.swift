import SwiftUI

enum Priority: Int, CaseIterable, Identifiable, Comparable {
    case low = 0
    case medium = 1
    case high = 2
    case urgent = 3

    var id: Int { rawValue }

    var label: String {
        switch self {
        case .low: return "低"
        case .medium: return "中"
        case .high: return "高"
        case .urgent: return "緊急"
        }
    }

    var color: Color {
        switch self {
        case .low: return .gray
        case .medium: return .blue
        case .high: return .orange
        case .urgent: return .red
        }
    }

    var symbol: String {
        switch self {
        case .low, .medium: return "flag"
        case .high: return "flag.fill"
        case .urgent: return "exclamationmark.2"
        }
    }

    static func < (lhs: Priority, rhs: Priority) -> Bool {
        lhs.rawValue < rhs.rawValue
    }
}
