import Foundation
import SwiftData

/// 一項工作。`scheduledDate` 是「打算在哪一天做」，`deadline` 是「最晚哪天要完成」。
@Model
final class TaskItem {
    var id: UUID = UUID()
    var title: String = ""
    var notes: String = ""
    /// 排定日期（一律存成當天 00:00）
    var scheduledDate: Date = Date()
    /// 截止日期（可不填）
    var deadline: Date?
    var priorityRaw: Int = 1
    /// 預估所需時間（分鐘），智慧排程用來計算每天的工作量
    var estimatedMinutes: Int = 30
    var isDone: Bool = false
    var completedAt: Date?
    /// 被往後延的次數
    var rescheduleCount: Int = 0
    var reminderDate: Date?
    var createdAt: Date = Date()
    var category: TaskCategory?
    /// 當天的開始時間（從 00:00 起算的分鐘數，例如 540 = 09:00）。nil = 還沒排時段
    var startMinute: Int?
    /// true = 使用者自己指定的時間（固定，不會被自動排程移動）
    var timeLocked: Bool = false
    /// 屬於哪一組重複工作（nil = 不重複）
    var seriesID: UUID?
    /// 這一次原本是排在哪一天（用來避免重複產生）
    var occurrenceDate: Date?
    /// 這一次被單獨移動過，修改重複規則時不會動它
    var detached: Bool = false

    init(
        title: String,
        notes: String = "",
        scheduledDate: Date = Date.today,
        deadline: Date? = nil,
        priority: Priority = .medium,
        estimatedMinutes: Int = 30,
        category: TaskCategory? = nil,
        reminderDate: Date? = nil
    ) {
        self.id = UUID()
        self.title = title
        self.notes = notes
        self.scheduledDate = scheduledDate.startOfDay
        self.deadline = deadline?.startOfDay
        self.priorityRaw = priority.rawValue
        self.estimatedMinutes = estimatedMinutes
        self.category = category
        self.reminderDate = reminderDate
        self.createdAt = Date()
    }

    var priority: Priority {
        get { Priority(rawValue: priorityRaw) ?? .medium }
        set { priorityRaw = newValue.rawValue }
    }

    /// 排在今天以前、還沒完成
    var isOverdue: Bool {
        !isDone && scheduledDate.startOfDay < Date.today
    }

    var endMinute: Int? {
        startMinute.map { $0 + estimatedMinutes }
    }

    /// 例如「09:00–10:30」
    var timeRangeText: String? {
        guard let s = startMinute, let e = endMinute else { return nil }
        return "\(DateText.hm(s))–\(DateText.hm(e))"
    }

    /// 開始時間的完整日期
    var startDate: Date? {
        startMinute.map { scheduledDate.startOfDay.addingTimeInterval(TimeInterval($0 * 60)) }
    }

    /// 已經超過截止日還沒完成
    var isPastDeadline: Bool {
        guard let deadline, !isDone else { return false }
        return deadline.startOfDay < Date.today
    }
}
