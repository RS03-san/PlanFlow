import SwiftUI
import UIKit
import SwiftData

struct CalendarScreen: View {
    enum Mode: String, CaseIterable, Identifiable {
        case week = "週"
        case month = "月"
        var id: String { rawValue }
    }

    @Environment(\.modelContext) private var context
    @Query(sort: [
        SortDescriptor(\TaskItem.priorityRaw, order: .reverse),
        SortDescriptor(\TaskItem.createdAt)
    ])
    private var tasks: [TaskItem]
    @AppStorage(SettingsKey.dailyCapacity) private var capacity = 240

    @State private var mode: Mode = .month
    @State private var selected = Date.today
    @State private var anchor = Date.today
    @State private var showNew = false
    @State private var editTarget: TaskItem?
    @State private var rescheduleTarget: TaskItem?
    @State private var bulkTasks: [TaskItem] = []
    @State private var showBulk = false

    private var tasksByDay: [Date: [TaskItem]] {
        Dictionary(grouping: tasks) { $0.scheduledDate.startOfDay }
    }

    private var selectedTasks: [TaskItem] {
        (tasksByDay[selected.startOfDay] ?? []).sorted { a, b in
            if a.isDone != b.isDone { return !a.isDone }
            return (a.startMinute ?? Int.max) < (b.startMinute ?? Int.max)
        }
    }

    private var selectedMinutes: Int {
        selectedTasks.filter { !$0.isDone }.reduce(0) { $0 + $1.estimatedMinutes }
    }

    private var overflow: [TaskItem] {
        Scheduler.overflow(of: selectedTasks, capacity: capacity)
    }

    private var headerTitle: String {
        switch mode {
        case .month:
            return DateText.month(anchor)
        case .week:
            let s = anchor.weekStartSunday
            return "\(DateText.short(s)) – \(DateText.short(s.adding(days: 6)))"
        }
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                Picker("檢視", selection: $mode) {
                    ForEach(Mode.allCases) { Text($0.rawValue).tag($0) }
                }
                .pickerStyle(.segmented)
                .padding(.horizontal)

                HStack {
                    Button { shift(-1) } label: { Image(systemName: "chevron.left").padding(8) }
                    Spacer()
                    Text(headerTitle).font(.headline)
                    Spacer()
                    Button { shift(1) } label: { Image(systemName: "chevron.right").padding(8) }
                }
                .padding(.horizontal)
                .padding(.vertical, 4)

                Group {
                    if mode == .month {
                        MonthGrid(
                            month: anchor,
                            selected: $selected,
                            tasksByDay: tasksByDay,
                            capacity: capacity,
                            onDrop: handleDrop
                        )
                    } else {
                        WeekStrip(
                            weekStart: anchor.weekStartSunday,
                            selected: $selected,
                            tasksByDay: tasksByDay,
                            capacity: capacity,
                            onDrop: handleDrop
                        )
                    }
                }
                .padding(.bottom, 8)

                Divider()

                List {
                    Section {
                        if selectedTasks.isEmpty {
                            Text("這天沒有工作。按 ＋ 新增，或在其他天長按工作拖過來。")
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }
                        ForEach(selectedTasks) { task in
                            TaskRow(task: task)
                                .modifier(TaskRowActions(task: task, rescheduleTarget: $rescheduleTarget, editTarget: $editTarget))
                                .draggable(task.id.uuidString) {
                                    Label(task.title, systemImage: "calendar")
                                        .padding(8)
                                        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 8))
                                }
                        }
                        if !overflow.isEmpty {
                            Button {
                                bulkTasks = overflow
                                showBulk = true
                            } label: {
                                Label("這天排太滿，把 \(overflow.count) 項分散到其他天", systemImage: "wand.and.stars")
                            }
                        }
                        if !selectedTasks.isEmpty {
                            NavigationLink {
                                DayTimelineView(date: selected)
                                    .navigationTitle(DateText.md(selected))
                                    .navigationBarTitleDisplayMode(.inline)
                            } label: {
                                Label("查看這天的時間表", systemImage: "clock")
                            }
                        }
                    } header: {
                        HStack {
                            Text(DateText.full(selected))
                            Spacer()
                            Text("\(DateText.duration(selectedMinutes)) / \(DateText.duration(capacity))")
                                .foregroundStyle(selectedMinutes > capacity ? Color.red : Color.secondary)
                        }
                    }
                }
                .listStyle(.insetGrouped)
            }
            .navigationTitle("行事曆")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("今天") {
                        withAnimation {
                            anchor = Date.today
                            selected = Date.today
                        }
                    }
                }
                ToolbarItem(placement: .primaryAction) {
                    Button { showNew = true } label: { Image(systemName: "plus.circle.fill").font(.title2) }
                        .accessibilityLabel("新增工作")
                }
            }
            .onChange(of: mode) { anchor = selected }
            .sheet(isPresented: $showNew) {
                TaskEditorView(task: nil, defaultDate: max(selected, Date.today))
            }
            .sheet(item: $editTarget) { TaskEditorView(task: $0) }
            .sheet(item: $rescheduleTarget) { task in
                RescheduleSheet(task: task).presentationDetents([.medium, .large])
            }
            .sheet(isPresented: $showBulk) {
                BulkRescheduleView(tasks: bulkTasks, startFromTomorrow: true)
            }
        }
    }

    private func shift(_ direction: Int) {
        withAnimation(.snappy) {
            switch mode {
            case .month:
                anchor = Calendar.current.date(byAdding: .month, value: direction, to: anchor) ?? anchor
            case .week:
                anchor = anchor.adding(days: 7 * direction)
                selected = selected.adding(days: 7 * direction).startOfDay
            }
        }
    }

    private func handleDrop(_ id: String, _ day: Date) -> Bool {
        guard let uuid = UUID(uuidString: id),
              let task = tasks.first(where: { $0.id == uuid }) else { return false }
        withAnimation {
            TaskActions.reschedule(task, to: day)
            selected = day
        }
        return true
    }
}

// MARK: - 月曆

struct MonthGrid: View {
    let month: Date
    @Binding var selected: Date
    let tasksByDay: [Date: [TaskItem]]
    let capacity: Int
    let onDrop: (String, Date) -> Bool

    private var cells: [Date?] {
        let cal = Calendar.current
        guard let interval = cal.dateInterval(of: .month, for: month) else { return [] }
        let first = interval.start.startOfDay
        let leading = cal.component(.weekday, from: first) - 1
        let count = cal.range(of: .day, in: .month, for: first)?.count ?? 30
        var result: [Date?] = Array(repeating: nil, count: leading)
        for i in 0..<count { result.append(first.adding(days: i).startOfDay) }
        while result.count % 7 != 0 { result.append(nil) }
        return result
    }

    var body: some View {
        VStack(spacing: 4) {
            HStack(spacing: 4) {
                ForEach(DateText.weekdaySymbols, id: \.self) { s in
                    Text(s)
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                        .frame(maxWidth: .infinity)
                }
            }
            LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 4), count: 7), spacing: 4) {
                ForEach(Array(cells.enumerated()), id: \.offset) { _, day in
                    if let day {
                        DayCell(
                            date: day,
                            isSelected: day.isSameDay(as: selected),
                            tasks: tasksByDay[day] ?? [],
                            capacity: capacity
                        )
                        .onTapGesture { withAnimation(.snappy) { selected = day } }
                        .dropDestination(for: String.self) { items, _ in
                            guard let first = items.first else { return false }
                            return onDrop(first, day)
                        }
                    } else {
                        Color.clear.frame(height: 46)
                    }
                }
            }
        }
        .padding(.horizontal)
    }
}

struct DayCell: View {
    let date: Date
    let isSelected: Bool
    let tasks: [TaskItem]
    let capacity: Int

    private var open: [TaskItem] { tasks.filter { !$0.isDone } }
    private var minutes: Int { open.reduce(0) { $0 + $1.estimatedMinutes } }
    private var isToday: Bool { date.isSameDay(as: Date.today) }
    private var allDone: Bool { !tasks.isEmpty && open.isEmpty }
    private var hasOverdue: Bool { open.contains { $0.isOverdue } }

    private var numberColor: Color {
        if isSelected { return .white }
        if isToday { return .accentColor }
        return .primary
    }

    var body: some View {
        VStack(spacing: 4) {
            Text("\(Calendar.current.component(.day, from: date))")
                .font(.callout.weight(isToday || isSelected ? .bold : .regular))
                .foregroundStyle(numberColor)
            HStack(spacing: 2) {
                if allDone {
                    Image(systemName: "checkmark")
                        .font(.system(size: 7, weight: .bold))
                        .foregroundStyle(isSelected ? Color.white : Color.green)
                } else {
                    ForEach(Array(open.prefix(3).enumerated()), id: \.offset) { _, t in
                        Circle()
                            .fill(isSelected ? Color.white : dotColor(t))
                            .frame(width: 5, height: 5)
                    }
                }
            }
            .frame(height: 7)
        }
        .frame(maxWidth: .infinity)
        .frame(height: 46)
        .background(
            RoundedRectangle(cornerRadius: 10)
                .fill(isSelected ? Color.accentColor : (isToday ? Color.accentColor.opacity(0.12) : Color.clear))
        )
        .overlay(
            RoundedRectangle(cornerRadius: 10)
                .stroke(minutes > capacity || hasOverdue ? Color.red.opacity(0.6) : Color.clear, lineWidth: 1.5)
        )
        .contentShape(Rectangle())
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("\(DateText.md(date))，\(open.count) 項未完成")
    }

    private func dotColor(_ t: TaskItem) -> Color {
        t.category.map { Color(hex: $0.colorHex) } ?? Color.gray
    }
}

// MARK: - 週檢視

struct WeekStrip: View {
    let weekStart: Date
    @Binding var selected: Date
    let tasksByDay: [Date: [TaskItem]]
    let capacity: Int
    let onDrop: (String, Date) -> Bool

    var body: some View {
        HStack(spacing: 6) {
            ForEach(0..<7, id: \.self) { i in
                let day = weekStart.adding(days: i).startOfDay
                WeekDayColumn(
                    date: day,
                    weekday: DateText.weekdaySymbols[i],
                    isSelected: day.isSameDay(as: selected),
                    tasks: tasksByDay[day] ?? [],
                    capacity: capacity
                )
                .onTapGesture { withAnimation(.snappy) { selected = day } }
                .dropDestination(for: String.self) { items, _ in
                    guard let first = items.first else { return false }
                    return onDrop(first, day)
                }
            }
        }
        .padding(.horizontal)
    }
}

struct WeekDayColumn: View {
    let date: Date
    let weekday: String
    let isSelected: Bool
    let tasks: [TaskItem]
    let capacity: Int

    private var open: [TaskItem] { tasks.filter { !$0.isDone } }
    private var minutes: Int { open.reduce(0) { $0 + $1.estimatedMinutes } }
    private var ratio: Double { min(Double(minutes) / Double(max(capacity, 1)), 1.2) }
    private var isToday: Bool { date.isSameDay(as: Date.today) }

    var body: some View {
        VStack(spacing: 6) {
            Text(weekday)
                .font(.caption2)
                .foregroundStyle(isSelected ? Color.white.opacity(0.9) : Color.secondary)
            Text("\(Calendar.current.component(.day, from: date))")
                .font(.headline)
                .foregroundStyle(isSelected ? Color.white : (isToday ? Color.accentColor : Color.primary))
            ZStack(alignment: .bottom) {
                Capsule().fill((isSelected ? Color.white : Color.secondary).opacity(0.2))
                Capsule()
                    .fill(minutes > capacity ? Color.red : (isSelected ? Color.white : Color.accentColor))
                    .frame(height: 70 * ratio / 1.2)
            }
            .frame(width: 10, height: 70)
            Text(open.isEmpty ? "–" : "\(open.count)")
                .font(.caption2.monospacedDigit())
                .foregroundStyle(isSelected ? Color.white : Color.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 8)
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(isSelected ? Color.accentColor : Color(.secondarySystemBackground))
        )
        .contentShape(Rectangle())
    }
}
