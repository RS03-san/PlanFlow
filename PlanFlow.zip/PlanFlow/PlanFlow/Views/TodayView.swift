import SwiftUI
import SwiftData

struct TodayView: View {
    @Environment(\.modelContext) private var context
    @Environment(\.scenePhase) private var scenePhase

    @Query(sort: [
        SortDescriptor(\TaskItem.scheduledDate),
        SortDescriptor(\TaskItem.priorityRaw, order: .reverse),
        SortDescriptor(\TaskItem.createdAt)
    ])
    private var tasks: [TaskItem]

    @AppStorage(SettingsKey.dailyCapacity) private var dailyCapacity = 240
    @AppStorage(SettingsKey.promptRollover) private var promptRollover = true
    @AppStorage(SettingsKey.lastRolloverPrompt) private var lastPrompt = ""

    @State private var showNew = false
    @State private var editTarget: TaskItem?
    @State private var rescheduleTarget: TaskItem?
    @State private var bulkTasks: [TaskItem] = []
    @State private var showBulk = false

    private var overdue: [TaskItem] { tasks.filter { $0.isOverdue } }

    private var todayTasks: [TaskItem] {
        tasks.filter { $0.scheduledDate.isSameDay(as: Date.today) }
            .sorted { a, b in
                if a.isDone != b.isDone { return !a.isDone }
                switch (a.startMinute, b.startMinute) {
                case let (x?, y?): return x < y
                case (.some, .none): return true
                case (.none, .some): return false
                default: return a.priorityRaw > b.priorityRaw
                }
            }
    }

    enum Mode: String, CaseIterable, Identifiable {
        case list = "清單"
        case timeline = "時間表"
        var id: String { rawValue }
    }
    @State private var mode: Mode = .list

    private var upcoming: [TaskItem] {
        let end = Date.today.adding(days: 8)
        return tasks.filter { !$0.isDone && $0.scheduledDate > Date.today && $0.scheduledDate < end }
    }

    private var todayOpenMinutes: Int {
        todayTasks.filter { !$0.isDone }.reduce(0) { $0 + $1.estimatedMinutes }
    }

    private var todayOverflow: [TaskItem] {
        Scheduler.overflow(of: todayTasks, capacity: dailyCapacity)
    }

    var body: some View {
        NavigationStack {
            Group {
                if mode == .timeline {
                    DayTimelineView(date: Date.today)
                } else {
                    listContent
                }
            }
            .safeAreaInset(edge: .top, spacing: 0) {
                Picker("檢視", selection: $mode) {
                    ForEach(Mode.allCases) { Text($0.rawValue).tag($0) }
                }
                .pickerStyle(.segmented)
                .padding(.horizontal)
                .padding(.vertical, 8)
                .background(.bar)
            }
            .navigationTitle("今天")
            .toolbar {
                ToolbarItem(placement: .primaryAction) {
                    Button { showNew = true } label: {
                        Image(systemName: "plus.circle.fill").font(.title2)
                    }
                    .accessibilityLabel("新增工作")
                }
            }
            .sheet(isPresented: $showNew) {
                TaskEditorView(task: nil, defaultDate: Date.today)
            }
            .sheet(item: $editTarget) { task in
                TaskEditorView(task: task)
            }
            .sheet(item: $rescheduleTarget) { task in
                RescheduleSheet(task: task)
                    .presentationDetents([.medium, .large])
            }
            .sheet(isPresented: $showBulk) {
                BulkRescheduleView(tasks: bulkTasks, startFromTomorrow: bulkFromTomorrow)
            }
            .onAppear(perform: checkRollover)
            .onChange(of: scenePhase) { _, phase in
                if phase == .active { checkRollover() }
            }
        }
    }

    private var listContent: some View {
            List {
                Section {
                    TodayHeader(
                        done: todayTasks.filter(\.isDone).count,
                        total: todayTasks.count,
                        minutes: todayOpenMinutes,
                        capacity: dailyCapacity
                    )
                }

                if !overdue.isEmpty {
                    Section {
                        OverdueBanner(count: overdue.count) {
                            openBulk(overdue)
                        } moveAllToday: {
                            withAnimation {
                                for t in overdue { TaskActions.reschedule(t, to: Date.today) }
                            }
                        }
                        ForEach(overdue) { row($0, showDate: true) }
                    } header: {
                        Text("之前沒完成的")
                    }
                }

                Section {
                    if todayTasks.isEmpty {
                        Text("今天沒有排定工作，按右上角 ＋ 新增")
                            .foregroundStyle(.secondary)
                    }
                    ForEach(todayTasks) { row($0) }

                    if !todayOverflow.isEmpty {
                        Button {
                            openBulk(todayOverflow, fromTomorrow: true)
                        } label: {
                            Label("今天排太滿了，把 \(todayOverflow.count) 項分散到之後", systemImage: "wand.and.stars")
                        }
                    }
                } header: {
                    Text("今天")
                }

                if !upcoming.isEmpty {
                    Section("接下來 7 天") {
                        ForEach(upcoming) { row($0, showDate: true) }
                    }
                }
            }
    }

    @State private var bulkFromTomorrow = false

    private func openBulk(_ list: [TaskItem], fromTomorrow: Bool = false) {
        bulkTasks = list
        bulkFromTomorrow = fromTomorrow
        showBulk = true
    }

    @ViewBuilder
    private func row(_ task: TaskItem, showDate: Bool = false) -> some View {
        TaskRow(task: task, showDate: showDate)
            .modifier(TaskRowActions(task: task, rescheduleTarget: $rescheduleTarget, editTarget: $editTarget))
    }

    /// 每天第一次打開 App 時，如果有沒完成的工作，就跳出重新規劃畫面
    private func checkRollover() {
        let key = DateText.key(Date())
        guard promptRollover, lastPrompt != key, !overdue.isEmpty, !showBulk else { return }
        lastPrompt = key
        openBulk(overdue)
    }
}

// MARK: - 子元件

struct TodayHeader: View {
    let done: Int
    let total: Int
    let minutes: Int
    let capacity: Int

    private var progress: Double { total == 0 ? 0 : Double(done) / Double(total) }
    private var overloaded: Bool { minutes > capacity }

    var body: some View {
        HStack(spacing: 16) {
            ZStack {
                Circle().stroke(Color.accentColor.opacity(0.15), lineWidth: 8)
                Circle()
                    .trim(from: 0, to: progress)
                    .stroke(Color.accentColor, style: StrokeStyle(lineWidth: 8, lineCap: .round))
                    .rotationEffect(.degrees(-90))
                    .animation(.easeOut, value: progress)
                Text("\(Int(progress * 100))%")
                    .font(.caption.bold())
            }
            .frame(width: 58, height: 58)

            VStack(alignment: .leading, spacing: 6) {
                Text(DateText.full(Date()))
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                Text("完成 \(done) / \(total) 項")
                    .font(.headline)
                ProgressView(value: min(Double(minutes) / Double(max(capacity, 1)), 1))
                    .tint(overloaded ? Color.red : Color.accentColor)
                Text("剩餘 \(DateText.duration(minutes))・每日可用 \(DateText.duration(capacity))")
                    .font(.caption)
                    .foregroundStyle(overloaded ? Color.red : Color.secondary)
            }
        }
        .padding(.vertical, 6)
    }
}

struct OverdueBanner: View {
    let count: Int
    let smartReschedule: () -> Void
    let moveAllToday: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Label("有 \(count) 項工作還沒完成", systemImage: "exclamationmark.circle.fill")
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(Color.orange)
            HStack {
                Button(action: smartReschedule) {
                    Label("智慧重新規劃", systemImage: "sparkles")
                }
                .buttonStyle(.borderedProminent)
                Button("全部移到今天", action: moveAllToday)
                    .buttonStyle(.bordered)
            }
            .font(.subheadline)
        }
        .padding(.vertical, 4)
    }
}
