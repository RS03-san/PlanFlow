import SwiftUI
import SwiftData

struct TaskRow: View {
    let task: TaskItem
    var showDate: Bool = false

    private var categoryColor: Color {
        task.category.map { Color(hex: $0.colorHex) } ?? Color.secondary
    }

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Button {
                withAnimation(.snappy) { TaskActions.toggleDone(task) }
            } label: {
                Image(systemName: task.isDone ? "checkmark.circle.fill" : "circle")
                    .font(.title2)
                    .foregroundStyle(task.isDone ? Color.green : categoryColor)
            }
            .buttonStyle(.plain)
            .accessibilityLabel(task.isDone ? "標記為未完成" : "標記為完成")

            VStack(alignment: .leading, spacing: 4) {
                Text(task.title)
                    .font(.body)
                    .strikethrough(task.isDone)
                    .foregroundStyle(task.isDone ? Color.secondary : Color.primary)
                    .lineLimit(2)

                HStack(spacing: 10) {
                    if let range = task.timeRangeText, !showDate {
                        Label(range, systemImage: task.timeLocked ? "pin.fill" : "clock.fill")
                            .foregroundStyle(Color.accentColor)
                            .monospacedDigit()
                    }
                    if showDate {
                        Label(DateText.relative(task.scheduledDate), systemImage: "calendar")
                    }
                    if task.isOverdue {
                        Text("逾期 \(task.scheduledDate.daysBetween(Date.today)) 天")
                            .foregroundStyle(Color.red)
                    }
                    Label(DateText.duration(task.estimatedMinutes), systemImage: "clock")
                    if let deadline = task.deadline {
                        Label("截止 \(DateText.short(deadline))", systemImage: "flag.checkered")
                            .foregroundStyle(task.isPastDeadline ? Color.red : Color.secondary)
                    }
                    if task.rescheduleCount > 0 {
                        Label("\(task.rescheduleCount)", systemImage: "arrow.uturn.forward")
                            .foregroundStyle(task.rescheduleCount >= 3 ? Color.orange : Color.secondary)
                            .accessibilityLabel("已延後 \(task.rescheduleCount) 次")
                    }
                }
                .font(.caption)
                .foregroundStyle(.secondary)
                .lineLimit(1)
                .labelStyle(CompactLabelStyle())
            }

            Spacer(minLength: 0)

            if task.priority >= .high && !task.isDone {
                Image(systemName: task.priority.symbol)
                    .font(.caption.bold())
                    .foregroundStyle(task.priority.color)
                    .padding(.top, 4)
            }
        }
        .padding(.vertical, 2)
        .contentShape(Rectangle())
    }
}

struct CompactLabelStyle: LabelStyle {
    func makeBody(configuration: Configuration) -> some View {
        HStack(spacing: 3) {
            configuration.icon
            configuration.title
        }
    }
}

/// 每一列工作共用的滑動與長按選單
struct TaskRowActions: ViewModifier {
    let task: TaskItem
    @Binding var rescheduleTarget: TaskItem?
    @Binding var editTarget: TaskItem?
    @Environment(\.modelContext) private var context

    func body(content: Content) -> some View {
        content
            .onTapGesture { editTarget = task }
            .swipeActions(edge: .leading, allowsFullSwipe: true) {
                Button {
                    withAnimation { TaskActions.toggleDone(task) }
                } label: {
                    Label(task.isDone ? "未完成" : "完成", systemImage: task.isDone ? "arrow.uturn.backward" : "checkmark")
                }
                .tint(.green)
            }
            .swipeActions(edge: .trailing, allowsFullSwipe: true) {
                if !task.isDone {
                    if task.isOverdue {
                        Button {
                            withAnimation { TaskActions.reschedule(task, to: Date.today) }
                        } label: {
                            Label("今天", systemImage: "sun.max")
                        }
                        .tint(.orange)
                    } else {
                        Button {
                            withAnimation { TaskActions.reschedule(task, to: task.scheduledDate.adding(days: 1)) }
                        } label: {
                            Label("延後一天", systemImage: "arrow.right")
                        }
                        .tint(.orange)
                    }
                    Button {
                        rescheduleTarget = task
                    } label: {
                        Label("重新規劃", systemImage: "calendar.badge.clock")
                    }
                    .tint(.indigo)
                }
                Button(role: .destructive) {
                    withAnimation { TaskActions.delete(task, in: context) }
                } label: {
                    Label("刪除", systemImage: "trash")
                }
            }
            .contextMenu {
                Button {
                    withAnimation { TaskActions.toggleDone(task) }
                } label: {
                    Label(task.isDone ? "標記為未完成" : "標記為完成", systemImage: "checkmark.circle")
                }
                if !task.isDone {
                    Button { rescheduleTarget = task } label: {
                        Label("重新規劃…", systemImage: "calendar.badge.clock")
                    }
                }
                Button { editTarget = task } label: {
                    Label("編輯", systemImage: "pencil")
                }
                Button(role: .destructive) {
                    withAnimation { TaskActions.delete(task, in: context) }
                } label: {
                    Label("刪除", systemImage: "trash")
                }
            }
    }
}
