import SwiftUI
import UIKit
import SwiftData
import Charts

struct StatsView: View {
    @Query private var tasks: [TaskItem]
    @Query(sort: \TaskCategory.sortOrder) private var categories: [TaskCategory]
    @State private var range = 7

    private struct DayStat: Identifiable {
        let date: Date
        let count: Int
        var id: Date { date }
    }

    private struct CategoryStat: Identifiable {
        let name: String
        let status: String
        let count: Int
        var id: String { name + status }
    }

    private var start: Date { Date.today.adding(days: -(range - 1)) }
    private var end: Date { Date.today.adding(days: 1) }

    /// 範圍內「排定」的工作
    private var windowTasks: [TaskItem] {
        tasks.filter { $0.scheduledDate >= start && $0.scheduledDate < end }
    }

    private var completedInWindow: [TaskItem] {
        tasks.filter { t in
            guard let c = t.completedAt else { return false }
            return c >= start && c < end
        }
    }

    private var completionRate: Double {
        let total = windowTasks.count
        guard total > 0 else { return 0 }
        return Double(windowTasks.filter(\.isDone).count) / Double(total)
    }

    private var daily: [DayStat] {
        (0..<range).map { i in
            let d = start.adding(days: i).startOfDay
            let n = completedInWindow.filter { $0.completedAt?.isSameDay(as: d) ?? false }.count
            return DayStat(date: d, count: n)
        }
    }

    private var categoryStats: [CategoryStat] {
        var result: [CategoryStat] = []
        var names = categories.map(\.name)
        if windowTasks.contains(where: { $0.category == nil }) { names.append("未分類") }
        for name in names {
            let group = windowTasks.filter { ($0.category?.name ?? "未分類") == name }
            guard !group.isEmpty else { continue }
            result.append(CategoryStat(name: name, status: "已完成", count: group.filter(\.isDone).count))
            result.append(CategoryStat(name: name, status: "未完成", count: group.filter { !$0.isDone }.count))
        }
        return result
    }

    private var mostPostponed: [TaskItem] {
        tasks.filter { !$0.isDone && $0.rescheduleCount > 0 }
            .sorted { $0.rescheduleCount > $1.rescheduleCount }
            .prefix(5)
            .map { $0 }
    }

    private var overdueCount: Int { tasks.filter(\.isOverdue).count }
    private var postponedInWindow: Int { windowTasks.reduce(0) { $0 + $1.rescheduleCount } }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    Picker("範圍", selection: $range) {
                        Text("最近 7 天").tag(7)
                        Text("最近 30 天").tag(30)
                    }
                    .pickerStyle(.segmented)

                    LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                        StatCard(title: "完成工作", value: "\(completedInWindow.count)", symbol: "checkmark.circle.fill", color: .green)
                        StatCard(title: "完成率", value: "\(Int(completionRate * 100))%", symbol: "chart.pie.fill", color: .blue)
                        StatCard(title: "延後次數", value: "\(postponedInWindow)", symbol: "arrow.uturn.forward.circle.fill", color: .orange)
                        StatCard(title: "目前逾期", value: "\(overdueCount)", symbol: "exclamationmark.circle.fill", color: overdueCount > 0 ? .red : .gray)
                    }

                    ChartCard(title: "每天完成數") {
                        Chart(daily) { s in
                            BarMark(
                                x: .value("日期", s.date, unit: .day),
                                y: .value("完成", s.count)
                            )
                            .foregroundStyle(Color.accentColor.gradient)
                            .cornerRadius(4)
                        }
                        .chartXAxis {
                            AxisMarks(values: .stride(by: .day, count: range == 7 ? 1 : 5)) { _ in
                                AxisValueLabel(format: .dateTime.month(.defaultDigits).day())
                            }
                        }
                        .frame(height: 180)
                    }

                    if !categoryStats.isEmpty {
                        ChartCard(title: "各分類完成狀況") {
                            Chart(categoryStats) { s in
                                BarMark(
                                    x: .value("數量", s.count),
                                    y: .value("分類", s.name)
                                )
                                .foregroundStyle(by: .value("狀態", s.status))
                            }
                            .chartForegroundStyleScale(["已完成": Color.green, "未完成": Color.orange])
                            .frame(height: CGFloat(Set(categoryStats.map(\.name)).count) * 40 + 50)
                        }
                    }

                    if !mostPostponed.isEmpty {
                        ChartCard(title: "最常被延後的工作") {
                            VStack(alignment: .leading, spacing: 10) {
                                ForEach(mostPostponed) { t in
                                    HStack {
                                        Text(t.title).lineLimit(1)
                                        Spacer()
                                        Text("\(t.rescheduleCount) 次")
                                            .font(.subheadline.monospacedDigit())
                                            .foregroundStyle(t.rescheduleCount >= 3 ? Color.orange : Color.secondary)
                                    }
                                }
                                Text("一直延後的工作，可以試著拆成更小的步驟。")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                        }
                    }
                }
                .padding()
            }
            .background(Color(.systemGroupedBackground))
            .navigationTitle("統計")
        }
    }
}

struct StatCard: View {
    let title: String
    let value: String
    let symbol: String
    let color: Color

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Image(systemName: symbol)
                .font(.title3)
                .foregroundStyle(color)
            Text(value)
                .font(.title.bold().monospacedDigit())
            Text(title)
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding()
        .background(Color(.secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 14))
    }
}

struct ChartCard<Content: View>: View {
    let title: String
    @ViewBuilder var content: Content

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(title).font(.headline)
            content
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding()
        .background(Color(.secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 14))
    }
}
