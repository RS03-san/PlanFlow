import SwiftUI
import SwiftData
import UIKit
import UserNotifications

struct SettingsView: View {
    @Environment(\.modelContext) private var context
    @Environment(\.openURL) private var openURL

    @AppStorage(SettingsKey.dailyCapacity) private var capacity = 240
    @AppStorage(SettingsKey.skipWeekends) private var skipWeekends = false
    @AppStorage(SettingsKey.promptRollover) private var promptRollover = true
    @AppStorage(SettingsKey.reminderHour) private var reminderHour = 9

    @AppStorage(SettingsKey.workStart) private var workStart = 540
    @AppStorage(SettingsKey.workEnd) private var workEnd = 1080
    @AppStorage(SettingsKey.breakOn) private var breakOn = true
    @AppStorage(SettingsKey.breakStart) private var breakStart = 720
    @AppStorage(SettingsKey.breakEnd) private var breakEnd = 780
    @AppStorage(SettingsKey.taskGap) private var taskGap = 10
    @AppStorage(SettingsKey.startReminder) private var startReminder = true

    @State private var notifStatus: UNAuthorizationStatus = .notDetermined
    @State private var showCleanup = false
    @State private var cleanupMessage: String?

    /// ⚠️ 上架前換成你自己的隱私權政策網址
    private let privacyURL = URL(string: "https://example.com/planflow/privacy")!

    private var version: String {
        let v = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "1.0"
        let b = Bundle.main.infoDictionary?["CFBundleVersion"] as? String ?? "1"
        return "\(v) (\(b))"
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Stepper(value: $capacity, in: 30...720, step: 30) {
                        LabeledContent("每日可用時間", value: DateText.duration(capacity))
                    }
                    Toggle("排程時跳過週末", isOn: $skipWeekends)
                    Toggle("每天開啟時提示重新規劃", isOn: $promptRollover)
                } header: {
                    Text("排程")
                } footer: {
                    Text("智慧排程會把工作放進「每日可用時間」還裝得下的最早一天，並盡量在截止日前完成。")
                }

                Section {
                    DatePicker("開始工作", selection: minuteBinding($workStart), displayedComponents: .hourAndMinute)
                    DatePicker("結束工作", selection: minuteBinding($workEnd), displayedComponents: .hourAndMinute)
                    Toggle("午休", isOn: $breakOn)
                    if breakOn {
                        DatePicker("午休開始", selection: minuteBinding($breakStart), displayedComponents: .hourAndMinute)
                        DatePicker("午休結束", selection: minuteBinding($breakEnd), displayedComponents: .hourAndMinute)
                    }
                    Stepper(value: $taskGap, in: 0...30, step: 5) {
                        LabeledContent("工作之間休息", value: taskGap == 0 ? "不休息" : "\(taskGap) 分鐘")
                    }
                    Button("把「每日可用時間」設成 \(DateText.duration(WorkHours.current.availableMinutes))") {
                        capacity = max(30, WorkHours.current.availableMinutes / 30 * 30)
                    }
                } header: {
                    Text("時段")
                } footer: {
                    Text(workEnd <= workStart
                         ? "結束時間要比開始時間晚。"
                         : "時間表會在這個範圍內，依優先順序自動把工作排進有空的時段。")
                }

                Section {
                    Toggle("時段開始前 5 分鐘提醒", isOn: $startReminder)
                    Picker("截止提醒時間", selection: $reminderHour) {
                        ForEach(6..<23, id: \.self) { h in
                            Text("\(h):00").tag(h)
                        }
                    }
                    HStack {
                        Text("通知")
                        Spacer()
                        switch notifStatus {
                        case .authorized, .provisional, .ephemeral:
                            Text("已開啟").foregroundStyle(.secondary)
                        case .denied:
                            Button("到設定開啟") {
                                if let url = URL(string: UIApplication.openSettingsURLString) { openURL(url) }
                            }
                        default:
                            Button("開啟通知") {
                                Task {
                                    await NotificationManager.requestAuthorization()
                                    await refreshStatus()
                                }
                            }
                        }
                    }
                } header: {
                    Text("提醒")
                }

                Section("資料") {
                    NavigationLink("分類管理") { CategoryManagerView() }
                    Button("清除 30 天前已完成的工作", role: .destructive) { showCleanup = true }
                    if let cleanupMessage {
                        Text(cleanupMessage).font(.caption).foregroundStyle(.secondary)
                    }
                }

                Section {
                    LabeledContent("版本", value: version)
                    Link("隱私權政策", destination: privacyURL)
                } header: {
                    Text("關於")
                } footer: {
                    Text("所有資料只存在你的裝置上，不會上傳到任何伺服器。")
                }
            }
            .navigationTitle("設定")
            .task { await refreshStatus() }
            .confirmationDialog("刪除 30 天前已完成的工作？這個動作無法復原。", isPresented: $showCleanup, titleVisibility: .visible) {
                Button("刪除", role: .destructive, action: cleanup)
            }
        }
    }

    @MainActor
    private func refreshStatus() async {
        notifStatus = await UNUserNotificationCenter.current().notificationSettings().authorizationStatus
    }

    private func cleanup() {
        let cutoff = Date.today.adding(days: -30)
        let all = (try? context.fetch(FetchDescriptor<TaskItem>())) ?? []
        let old = all.filter { $0.isDone && ($0.completedAt ?? Date()) < cutoff }
        for t in old { context.delete(t) }
        cleanupMessage = "已刪除 \(old.count) 項"
    }
}

// MARK: - 分類管理

struct CategoryManagerView: View {
    @Environment(\.modelContext) private var context
    @Query(sort: \TaskCategory.sortOrder) private var categories: [TaskCategory]
    @State private var editing: TaskCategory?
    @State private var showNew = false

    var body: some View {
        List {
            ForEach(categories) { c in
                Button { editing = c } label: {
                    HStack {
                        Image(systemName: c.symbol)
                            .foregroundStyle(Color(hex: c.colorHex))
                            .frame(width: 28)
                        Text(c.name).foregroundStyle(Color.primary)
                        Spacer()
                        Text("\(c.tasks?.count ?? 0)").foregroundStyle(.secondary)
                    }
                }
            }
            .onDelete { offsets in
                for i in offsets { context.delete(categories[i]) }
            }
            .onMove { from, to in
                var list = categories
                list.move(fromOffsets: from, toOffset: to)
                for (i, c) in list.enumerated() { c.sortOrder = i }
            }
        }
        .navigationTitle("分類管理")
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) { EditButton() }
            ToolbarItem(placement: .primaryAction) {
                Button { showNew = true } label: { Image(systemName: "plus") }
            }
        }
        .sheet(isPresented: $showNew) {
            CategoryEditor(category: nil, nextOrder: (categories.map(\.sortOrder).max() ?? -1) + 1)
        }
        .sheet(item: $editing) { c in
            CategoryEditor(category: c, nextOrder: c.sortOrder)
        }
    }
}

struct CategoryEditor: View {
    let category: TaskCategory?
    let nextOrder: Int

    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss
    @State private var name = ""
    @State private var colorHex = TaskCategory.palette[0]
    @State private var symbol = TaskCategory.symbols[0]
    @State private var loaded = false

    private let columns = Array(repeating: GridItem(.flexible(), spacing: 12), count: 6)

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    HStack {
                        Image(systemName: symbol)
                            .font(.title2)
                            .foregroundStyle(Color(hex: colorHex))
                            .frame(width: 36)
                        TextField("分類名稱", text: $name)
                    }
                }
                Section("顏色") {
                    LazyVGrid(columns: columns, spacing: 12) {
                        ForEach(TaskCategory.palette, id: \.self) { hex in
                            Button { colorHex = hex } label: {
                                Circle()
                                    .fill(Color(hex: hex))
                                    .frame(width: 32, height: 32)
                                    .overlay(Circle().stroke(Color.primary, lineWidth: hex == colorHex ? 3 : 0))
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .padding(.vertical, 6)
                }
                Section("圖示") {
                    LazyVGrid(columns: columns, spacing: 12) {
                        ForEach(TaskCategory.symbols, id: \.self) { s in
                            Button { symbol = s } label: {
                                Image(systemName: s)
                                    .frame(width: 36, height: 36)
                                    .background(
                                        RoundedRectangle(cornerRadius: 8)
                                            .fill(s == symbol ? Color(hex: colorHex).opacity(0.2) : Color.clear)
                                    )
                                    .foregroundStyle(s == symbol ? Color(hex: colorHex) : Color.secondary)
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .padding(.vertical, 6)
                }
            }
            .navigationTitle(category == nil ? "新增分類" : "編輯分類")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("儲存", action: save)
                        .disabled(name.trimmingCharacters(in: .whitespaces).isEmpty)
                }
            }
            .onAppear {
                guard !loaded else { return }
                loaded = true
                if let category {
                    name = category.name
                    colorHex = category.colorHex
                    symbol = category.symbol
                }
            }
        }
    }

    private func save() {
        let trimmed = name.trimmingCharacters(in: .whitespaces)
        if let category {
            category.name = trimmed
            category.colorHex = colorHex
            category.symbol = symbol
        } else {
            context.insert(TaskCategory(name: trimmed, colorHex: colorHex, symbol: symbol, sortOrder: nextOrder))
        }
        dismiss()
    }
}
