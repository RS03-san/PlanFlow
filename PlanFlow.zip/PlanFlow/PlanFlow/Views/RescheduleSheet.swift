import SwiftUI
import SwiftData

/// 單一工作的重新規劃畫面
struct RescheduleSheet: View {
    let task: TaskItem

    @Environment(\.dismiss) private var dismiss
    @Query private var allTasks: [TaskItem]
    @AppStorage(SettingsKey.dailyCapacity) private var capacity = 240

    @State private var customDate = Date.today.adding(days: 1)
    @State private var suggestion: Date?

    private struct QuickOption: Identifiable {
        let id: String
        let date: Date
        let icon: String
    }

    /// 已經逾期的工作從今天開始找；今天以後的工作從明天開始找
    private var searchStart: Date {
        task.isOverdue ? Date.today : Date.today.adding(days: 1)
    }

    private var quickOptions: [QuickOption] {
        var list: [QuickOption] = []
        if !task.scheduledDate.isSameDay(as: Date.today) {
            list.append(QuickOption(id: "今天", date: Date.today, icon: "sun.max"))
        }
        list.append(QuickOption(id: "明天", date: Date.today.adding(days: 1), icon: "sunrise"))
        list.append(QuickOption(id: "後天", date: Date.today.adding(days: 2), icon: "arrow.right.circle"))
        list.append(QuickOption(id: "下週一", date: Date.today.nextMonday, icon: "calendar.badge.plus"))
        let base = max(task.scheduledDate.startOfDay, Date.today)
        list.append(QuickOption(id: "一週後", date: base.adding(days: 7), icon: "calendar"))
        return list
    }

    private var otherLoad: [Date: Int] {
        Scheduler.load(of: allTasks, excluding: [task.id])
    }

    var body: some View {
        NavigationStack {
            List {
                Section {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(task.title).font(.headline)
                        HStack(spacing: 12) {
                            Text("目前：\(DateText.relative(task.scheduledDate))")
                            Text("需要 \(DateText.duration(task.estimatedMinutes))")
                            if let d = task.deadline { Text("截止 \(DateText.md(d))") }
                        }
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        if task.rescheduleCount >= 3 {
                            Text("這項工作已經延後 \(task.rescheduleCount) 次了，考慮拆小一點或提高優先順序？")
                                .font(.caption)
                                .foregroundStyle(Color.orange)
                        }
                    }
                }

                if let suggestion {
                    Section("智慧建議") {
                        Button { apply(suggestion) } label: {
                            HStack {
                                Image(systemName: "sparkles").foregroundStyle(Color.purple)
                                VStack(alignment: .leading) {
                                    Text(DateText.relative(suggestion) == DateText.md(suggestion)
                                         ? DateText.md(suggestion)
                                         : "\(DateText.relative(suggestion))  \(DateText.md(suggestion))")
                                        .foregroundStyle(Color.primary)
                                    Text(loadText(for: suggestion))
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }
                                Spacer()
                                Image(systemName: "chevron.right").font(.caption).foregroundStyle(.tertiary)
                            }
                        }
                    }
                }

                Section("快速選擇") {
                    ForEach(quickOptions) { opt in
                        Button { apply(opt.date) } label: {
                            HStack {
                                Label(opt.id, systemImage: opt.icon).foregroundStyle(Color.primary)
                                Spacer()
                                VStack(alignment: .trailing) {
                                    Text(DateText.md(opt.date)).foregroundStyle(.secondary)
                                    Text(loadText(for: opt.date)).font(.caption2).foregroundStyle(.tertiary)
                                }
                            }
                        }
                    }
                }

                Section("自訂日期") {
                    DatePicker("日期", selection: $customDate, in: Date.today..., displayedComponents: .date)
                        .datePickerStyle(.graphical)
                    Text(loadText(for: customDate))
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    Button("移到 \(DateText.md(customDate))") { apply(customDate) }
                        .frame(maxWidth: .infinity)
                }
            }
            .navigationTitle("重新規劃")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("取消") { dismiss() }
                }
            }
            .onAppear {
                suggestion = Scheduler.suggest(for: task, allTasks: allTasks, start: searchStart)
                customDate = max(task.scheduledDate.startOfDay, Date.today).adding(days: 1)
            }
        }
    }

    private func loadText(for date: Date) -> String {
        let used = otherLoad[date.startOfDay] ?? 0
        let after = used + task.estimatedMinutes
        if used == 0 { return "當天還沒有其他工作" }
        let warn = after > capacity ? "（會超過每日可用時間）" : ""
        return "當天已排 \(DateText.duration(used))\(warn)"
    }

    private func apply(_ date: Date) {
        withAnimation { TaskActions.reschedule(task, to: date) }
        dismiss()
    }
}

/// 多項工作一次重新規劃（預覽 → 調整 → 套用）
struct BulkRescheduleView: View {
    let tasks: [TaskItem]
    var startFromTomorrow: Bool = false

    @Environment(\.dismiss) private var dismiss
    @Query private var allTasks: [TaskItem]
    @AppStorage(SettingsKey.dailyCapacity) private var capacity = 240
    @AppStorage(SettingsKey.skipWeekends) private var skipWeekends = false

    @State private var plan: [UUID: Date] = [:]
    @State private var selected: Set<UUID> = []
    @State private var fromTomorrow = false
    @State private var loaded = false

    var body: some View {
        NavigationStack {
            List {
                Section {
                    Text("依照優先順序、截止日和每日可用時間（\(DateText.duration(capacity))）自動分配日期，可以逐項調整。")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                    Toggle("從明天開始排", isOn: $fromTomorrow)
                    Toggle("跳過週末", isOn: $skipWeekends)
                }

                Section("排程預覽") {
                    ForEach(tasks) { t in
                        HStack(spacing: 10) {
                            Button {
                                if selected.contains(t.id) { selected.remove(t.id) } else { selected.insert(t.id) }
                            } label: {
                                Image(systemName: selected.contains(t.id) ? "checkmark.circle.fill" : "circle")
                                    .font(.title3)
                                    .foregroundStyle(selected.contains(t.id) ? Color.accentColor : Color.secondary)
                            }
                            .buttonStyle(.plain)

                            VStack(alignment: .leading, spacing: 2) {
                                Text(t.title).lineLimit(2)
                                HStack(spacing: 6) {
                                    Text("優先：\(t.priority.label)")
                                    Text(DateText.duration(t.estimatedMinutes))
                                    if let d = t.deadline { Text("截止 \(DateText.short(d))") }
                                }
                                .font(.caption)
                                .foregroundStyle(.secondary)
                            }
                            Spacer(minLength: 4)
                            DatePicker("", selection: binding(for: t), in: Date.today..., displayedComponents: .date)
                                .labelsHidden()
                                .opacity(selected.contains(t.id) ? 1 : 0.35)
                        }
                    }
                }
            }
            .navigationTitle("重新規劃 \(tasks.count) 項")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("稍後") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("套用") { applyPlan() }
                        .disabled(selected.isEmpty)
                }
            }
            .onAppear {
                guard !loaded else { return }
                loaded = true
                fromTomorrow = startFromTomorrow
                selected = Set(tasks.map(\.id))
                recompute()
            }
            .onChange(of: fromTomorrow) { recompute() }
            .onChange(of: skipWeekends) { recompute() }
        }
    }

    private func recompute() {
        let start = fromTomorrow ? Date.today.adding(days: 1) : Date.today
        plan = Scheduler.plan(tasks, allTasks: allTasks, start: start)
    }

    private func binding(for task: TaskItem) -> Binding<Date> {
        Binding(
            get: { plan[task.id] ?? Date.today },
            set: { plan[task.id] = $0.startOfDay }
        )
    }

    private func applyPlan() {
        withAnimation {
            for t in tasks where selected.contains(t.id) {
                TaskActions.reschedule(t, to: plan[t.id] ?? Date.today)
            }
        }
        dismiss()
    }
}
