import SwiftUI
import SwiftData

struct RootView: View {
    @Environment(\.modelContext) private var context
    @AppStorage(SettingsKey.didSeed) private var didSeed = false

    var body: some View {
        TabView {
            TodayView()
                .tabItem { Label("今天", systemImage: "checklist") }
            CalendarScreen()
                .tabItem { Label("行事曆", systemImage: "calendar") }
            StatsView()
                .tabItem { Label("統計", systemImage: "chart.bar.xaxis") }
            SettingsView()
                .tabItem { Label("設定", systemImage: "gearshape") }
        }
        .task { seedIfNeeded() }
    }

    /// 第一次開啟時建立預設分類與示範工作
    private func seedIfNeeded() {
        guard !didSeed else { return }
        let defaults: [(String, String, String)] = [
            ("工作", "#4F7CFF", "briefcase.fill"),
            ("學習", "#8E5CF6", "book.fill"),
            ("生活", "#22B07D", "leaf.fill"),
            ("其他", "#F59E0B", "tray.fill")
        ]
        var created: [TaskCategory] = []
        for (i, d) in defaults.enumerated() {
            let c = TaskCategory(name: d.0, colorHex: d.1, symbol: d.2, sortOrder: i)
            context.insert(c)
            created.append(c)
        }
        context.insert(TaskItem(
            title: "歡迎使用！點一下圓圈完成工作",
            notes: "在工作上往左滑，可以延後或重新規劃到其他日期。",
            priority: .medium,
            estimatedMinutes: 15,
            category: created.first
        ))
        let meeting = TaskItem(
            title: "範例：固定時間的會議（14:00）",
            notes: "編輯工作時打開「指定開始時間」，時間表就不會移動它。",
            priority: .high,
            estimatedMinutes: 60,
            category: created.first
        )
        meeting.startMinute = 14 * 60
        meeting.timeLocked = true
        context.insert(meeting)
        context.insert(TaskItem(
            title: "在行事曆長按工作，可以拖到別天",
            estimatedMinutes: 15,
            category: created.last
        ))
        didSeed = true
    }
}
