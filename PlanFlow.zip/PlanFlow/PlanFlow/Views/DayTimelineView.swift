import SwiftUI
import SwiftData
import UIKit

/// 一天的時間表：把工作排進具體時段
struct DayTimelineView: View {
    let date: Date

    @Query(sort: \TaskItem.createdAt) private var allTasks: [TaskItem]

    @AppStorage(SettingsKey.workStart) private var workStart = 540
    @AppStorage(SettingsKey.workEnd) private var workEnd = 1080
    @AppStorage(SettingsKey.breakOn) private var breakOn = true
    @AppStorage(SettingsKey.breakStart) private var breakStart = 720
    @AppStorage(SettingsKey.breakEnd) private var breakEnd = 780

    @State private var editTarget: TaskItem?
    @State private var rescheduleTarget: TaskItem?
    @State private var showBulk = false
    @State private var bulkTasks: [TaskItem] = []
    @State private var showNew = false

    private let pxPerMin: CGFloat = 1.3
    private let labelWidth: CGFloat = 46

    private var dayTasks: [TaskItem] {
        allTasks.filter { $0.scheduledDate.isSameDay(as: date) }
    }
    private var timed: [TaskItem] {
        dayTasks.filter { $0.startMinute != nil }
            .sorted { ($0.startMinute ?? 0) < ($1.startMinute ?? 0) }
    }
    private var untimed: [TaskItem] {
        dayTasks.filter { $0.startMinute == nil && !$0.isDone }
            .sorted { $0.priorityRaw > $1.priorityRaw }
    }
    private var isPast: Bool { date.startOfDay < Date.today }
    private var isToday: Bool { date.isSameDay(as: Date.today) }

    private var firstHour: Int {
        let earliest = min(workStart, timed.compactMap(\.startMinute).min() ?? workStart)
        return max(0, earliest / 60 - 1)
    }
    private var lastHour: Int {
        let latest = max(workEnd, timed.compactMap(\.endMinute).max() ?? workEnd)
        return min(24, (latest + 59) / 60 + 1)
    }

    private var plannedMinutes: Int {
        dayTasks.filter { !$0.isDone && $0.startMinute != nil }.reduce(0) { $0 + $1.estimatedMinutes }
    }

    private func y(_ minute: Int) -> CGFloat {
        CGFloat(minute - firstHour * 60) * pxPerMin
    }

    var body: some View {
        ScrollViewReader { proxy in
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    summaryCard
                    if !untimed.isEmpty { untimedCard }
                    timeline
                }
                .padding()
            }
            .background(Color(.systemGroupedBackground))
            .onAppear {
                if !isPast {
                    TaskActions.arrangeTimes(day: date, tasks: dayTasks, mode: .fillMissing)
                }
                let target = isToday ? Date().minuteOfDay / 60 : (timed.first?.startMinute ?? workStart) / 60
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                    withAnimation { proxy.scrollTo("h\(max(firstHour, target - 1))", anchor: .top) }
                }
            }
        }
        .sheet(item: $editTarget) { TaskEditorView(task: $0) }
        .sheet(item: $rescheduleTarget) { task in
            RescheduleSheet(task: task).presentationDetents([.medium, .large])
        }
        .sheet(isPresented: $showBulk) {
            BulkRescheduleView(tasks: bulkTasks, startFromTomorrow: true)
        }
        .sheet(isPresented: $showNew) {
            TaskEditorView(task: nil, defaultDate: max(date, Date.today))
        }
    }

    // MARK: - 上方摘要

    private var summaryCard: some View {
        let hours = WorkHours.current
        return VStack(alignment: .leading, spacing: 10) {
            HStack {
                Label("\(DateText.hm(workStart))–\(DateText.hm(workEnd))", systemImage: "clock")
                    .font(.subheadline.weight(.semibold))
                if breakOn {
                    Text("午休 \(DateText.hm(breakStart))–\(DateText.hm(breakEnd))")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Spacer()
            }
            Text("已排 \(DateText.duration(plannedMinutes))・可用 \(DateText.duration(hours.availableMinutes))")
                .font(.caption)
                .foregroundStyle(plannedMinutes > hours.availableMinutes ? Color.red : Color.secondary)
            if isPast {
                Text("過去的日子不會自動排時段。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            } else {
                HStack {
                    Button {
                        withAnimation {
                            TaskActions.arrangeTimes(day: date, tasks: dayTasks, mode: .replanAll)
                        }
                        UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                    } label: {
                        Label(isToday ? "從現在重新安排" : "重新安排時段", systemImage: "wand.and.stars")
                    }
                    .buttonStyle(.borderedProminent)
                    Button {
                        showNew = true
                    } label: {
                        Label("新增", systemImage: "plus")
                    }
                    .buttonStyle(.bordered)
                }
                .font(.subheadline)
                Text("自己指定時間的工作（有 \(Image(systemName: "pin.fill")) 圖示）不會被移動。")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(.secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 14))
    }

    // MARK: - 排不進時段的工作

    private var untimedCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            Label("工作時段內排不下 \(untimed.count) 項", systemImage: "exclamationmark.circle.fill")
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(Color.orange)
            ForEach(untimed) { t in
                HStack {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(t.title).lineLimit(1)
                        Text("\(DateText.duration(t.estimatedMinutes))・優先 \(t.priority.label)")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    Spacer()
                    Button("改日期") { rescheduleTarget = t }
                        .font(.caption)
                        .buttonStyle(.bordered)
                }
                .contentShape(Rectangle())
                .onTapGesture { editTarget = t }
            }
            if !isPast {
                Button {
                    bulkTasks = untimed
                    showBulk = true
                } label: {
                    Label("全部移到之後有空的日子", systemImage: "calendar.badge.clock")
                }
                .font(.subheadline)
            }
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(.secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 14))
    }

    // MARK: - 時間軸

    private var timeline: some View {
        ZStack(alignment: .topLeading) {
            // 工作時段底色
            Rectangle()
                .fill(Color.accentColor.opacity(0.06))
                .frame(height: max(0, y(workEnd) - y(workStart)))
                .padding(.leading, labelWidth + 4)
                .offset(y: y(workStart))

            // 午休
            if breakOn && breakEnd > breakStart {
                ZStack {
                    Rectangle().fill(Color.secondary.opacity(0.12))
                    Text("午休")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                .frame(height: y(breakEnd) - y(breakStart))
                .padding(.leading, labelWidth + 4)
                .offset(y: y(breakStart))
            }

            // 整點線
            ForEach(firstHour...lastHour, id: \.self) { h in
                HStack(alignment: .center, spacing: 4) {
                    Text(String(format: "%02d:00", h))
                        .font(.caption2.monospacedDigit())
                        .foregroundStyle(.secondary)
                        .frame(width: labelWidth, alignment: .trailing)
                    Rectangle()
                        .fill(Color.secondary.opacity(0.25))
                        .frame(height: 0.5)
                }
                .frame(height: 12)
                .offset(y: y(h * 60) - 6)
                .id("h\(h)")
            }

            // 工作
            ForEach(timed) { t in
                TimeBlock(task: t, height: max(CGFloat(t.estimatedMinutes) * pxPerMin - 2, 26))
                    .padding(.leading, labelWidth + 8)
                    .padding(.trailing, 2)
                    .offset(y: y(t.startMinute ?? 0) + 1)
                    .onTapGesture { editTarget = t }
                    .contextMenu {
                        Button { withAnimation { TaskActions.toggleDone(t) } } label: {
                            Label(t.isDone ? "標記為未完成" : "標記為完成", systemImage: "checkmark.circle")
                        }
                        if !t.isDone {
                            Button { rescheduleTarget = t } label: {
                                Label("改到別天", systemImage: "calendar.badge.clock")
                            }
                        }
                        Button { editTarget = t } label: { Label("編輯", systemImage: "pencil") }
                    }
            }

            // 現在時間
            if isToday {
                TimelineView(.periodic(from: .now, by: 60)) { ctx in
                    let m = ctx.date.minuteOfDay
                    if m >= firstHour * 60 && m <= lastHour * 60 {
                        HStack(spacing: 0) {
                            Circle().fill(Color.red).frame(width: 8, height: 8)
                            Rectangle().fill(Color.red).frame(height: 1.5)
                        }
                        .padding(.leading, labelWidth)
                        .offset(y: y(m) - 4)
                    }
                }
            }
        }
        .frame(maxWidth: .infinity, alignment: .topLeading)
        .frame(height: y(lastHour * 60) + 12, alignment: .topLeading)
    }
}

/// 時間表上的一個工作方塊
struct TimeBlock: View {
    let task: TaskItem
    let height: CGFloat

    private var color: Color {
        task.category.map { Color(hex: $0.colorHex) } ?? Color.gray
    }

    var body: some View {
        HStack(alignment: .top, spacing: 8) {
            Button {
                withAnimation(.snappy) { TaskActions.toggleDone(task) }
            } label: {
                Image(systemName: task.isDone ? "checkmark.circle.fill" : "circle")
                    .foregroundStyle(task.isDone ? Color.green : color)
            }
            .buttonStyle(.plain)
            .accessibilityLabel(task.isDone ? "標記為未完成" : "標記為完成")

            VStack(alignment: .leading, spacing: 1) {
                HStack(spacing: 4) {
                    if task.timeLocked {
                        Image(systemName: "pin.fill").font(.caption2).foregroundStyle(color)
                    }
                    Text(task.title)
                        .font(.subheadline.weight(.medium))
                        .strikethrough(task.isDone)
                        .lineLimit(height > 50 ? 2 : 1)
                }
                if height > 40, let range = task.timeRangeText {
                    Text(range)
                        .font(.caption2.monospacedDigit())
                        .foregroundStyle(.secondary)
                }
            }
            Spacer(minLength: 0)
            if task.priority >= .high && !task.isDone {
                Text(task.priority.label)
                    .font(.caption2.bold())
                    .foregroundStyle(task.priority.color)
            }
        }
        .padding(.horizontal, 8)
        .padding(.vertical, 4)
        .frame(maxWidth: .infinity, alignment: .topLeading)
        .frame(height: height, alignment: .topLeading)
        .background(
            RoundedRectangle(cornerRadius: 8)
                .fill(color.opacity(task.isDone ? 0.08 : 0.18))
        )
        .overlay(alignment: .leading) {
            RoundedRectangle(cornerRadius: 2)
                .fill(color)
                .frame(width: 4)
                .padding(.vertical, 3)
        }
        .opacity(task.isDone ? 0.6 : 1)
        .contentShape(Rectangle())
        .accessibilityElement(children: .combine)
    }
}
