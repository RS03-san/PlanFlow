import SwiftUI
import SwiftData

/// 新增 / 編輯工作
struct TaskEditorView: View {
    let task: TaskItem?
    var defaultDate: Date = Date.today

    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss
    @Query(sort: \TaskCategory.sortOrder) private var categories: [TaskCategory]
    @Query private var allTasks: [TaskItem]
    @AppStorage(SettingsKey.reminderHour) private var reminderHour = 9

    @State private var title = ""
    @State private var notes = ""
    @State private var scheduledDate = Date.today
    @State private var hasDeadline = false
    @State private var deadline = Date.today.adding(days: 3)
    @State private var priority: Priority = .medium
    @State private var minutes = 30
    @State private var category: TaskCategory?
    @State private var hasReminder = false
    @State private var reminder = Date()
    @State private var loaded = false
    @State private var showDeleteConfirm = false
    @State private var suggestedHint: String?
    @FocusState private var titleFocused: Bool

    private var trimmedTitle: String {
        title.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    TextField("工作名稱", text: $title)
                        .focused($titleFocused)
                        .submitLabel(.done)
                    TextField("備註（選填）", text: $notes, axis: .vertical)
                        .lineLimit(1...5)
                }

                Section("分類與優先順序") {
                    Picker("分類", selection: $category) {
                        Text("無").tag(TaskCategory?.none)
                        ForEach(categories) { c in
                            Label(c.name, systemImage: c.symbol).tag(Optional(c))
                        }
                    }
                    Picker("優先順序", selection: $priority) {
                        ForEach(Priority.allCases) { p in
                            Text(p.label).tag(p)
                        }
                    }
                    .pickerStyle(.segmented)
                }

                Section {
                    DatePicker("排定日期", selection: $scheduledDate, displayedComponents: .date)
                    Stepper(value: $minutes, in: 15...600, step: 15) {
                        LabeledContent("預估時間", value: DateText.duration(minutes))
                    }
                    Toggle("截止日期", isOn: $hasDeadline.animation())
                    if hasDeadline {
                        DatePicker("截止", selection: $deadline, displayedComponents: .date)
                    }
                    Button {
                        suggestDate()
                    } label: {
                        Label("幫我找有空的一天", systemImage: "sparkles")
                    }
                    if let suggestedHint {
                        Text(suggestedHint)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                } header: {
                    Text("時間")
                } footer: {
                    Text("智慧排程會考慮每天已排的工作量、優先順序與截止日。")
                }

                Section("提醒") {
                    Toggle("提醒我", isOn: $hasReminder.animation())
                    if hasReminder {
                        DatePicker("提醒時間", selection: $reminder)
                    }
                    if hasDeadline {
                        Text("截止日前一天 \(reminderHour):00 也會自動提醒")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    }
                }

                if let task {
                    Section {
                        if task.rescheduleCount > 0 {
                            LabeledContent("已延後", value: "\(task.rescheduleCount) 次")
                        }
                        LabeledContent("建立於", value: DateText.md(task.createdAt))
                        Button("刪除這項工作", role: .destructive) { showDeleteConfirm = true }
                    }
                }
            }
            .navigationTitle(task == nil ? "新增工作" : "編輯工作")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("取消") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("儲存") { save() }
                        .disabled(trimmedTitle.isEmpty)
                }
            }
            .confirmationDialog("確定要刪除？", isPresented: $showDeleteConfirm, titleVisibility: .visible) {
                Button("刪除", role: .destructive) {
                    if let task { TaskActions.delete(task, in: context) }
                    dismiss()
                }
            }
            .onChange(of: hasReminder) { _, on in
                if on { Task { await NotificationManager.requestAuthorization() } }
            }
            .onChange(of: hasDeadline) { _, on in
                if on { Task { await NotificationManager.requestAuthorization() } }
            }
            .onAppear(perform: load)
        }
    }

    private func load() {
        guard !loaded else { return }
        loaded = true
        if let task {
            title = task.title
            notes = task.notes
            scheduledDate = task.scheduledDate
            hasDeadline = task.deadline != nil
            deadline = task.deadline ?? task.scheduledDate.adding(days: 3)
            priority = task.priority
            minutes = task.estimatedMinutes
            category = task.category
            hasReminder = task.reminderDate != nil
            reminder = task.reminderDate ?? defaultReminder(on: task.scheduledDate)
        } else {
            scheduledDate = defaultDate.startOfDay
            deadline = defaultDate.adding(days: 3)
            reminder = defaultReminder(on: defaultDate)
            category = categories.first
            titleFocused = true
        }
    }

    private func defaultReminder(on day: Date) -> Date {
        var comps = Calendar.current.dateComponents([.year, .month, .day], from: day)
        comps.hour = reminderHour
        comps.minute = 0
        let candidate = Calendar.current.date(from: comps) ?? Date()
        return candidate > Date() ? candidate : Date().addingTimeInterval(3600)
    }

    private func suggestDate() {
        var excluding = Set<UUID>()
        if let task { excluding.insert(task.id) }
        let day = Scheduler.suggest(
            minutes: minutes,
            deadline: hasDeadline ? deadline : nil,
            allTasks: allTasks,
            excluding: excluding,
            start: Date.today
        )
        withAnimation {
            scheduledDate = day
            suggestedHint = "建議排在 \(DateText.relative(day))（\(DateText.md(day))）"
        }
    }

    private func save() {
        let item: TaskItem
        if let task {
            item = task
        } else {
            item = TaskItem(title: trimmedTitle)
            context.insert(item)
        }

        let newDay = scheduledDate.startOfDay
        if task != nil, newDay > item.scheduledDate.startOfDay {
            item.rescheduleCount += 1
        }

        item.title = trimmedTitle
        item.notes = notes
        item.scheduledDate = newDay
        item.deadline = hasDeadline ? deadline.startOfDay : nil
        item.priority = priority
        item.estimatedMinutes = minutes
        item.category = category
        item.reminderDate = hasReminder ? reminder : nil

        NotificationManager.schedule(for: item)
        dismiss()
    }
}
