import SwiftUI
import SwiftData

/// 新增 / 編輯工作
struct TaskEditorView: View {
    let task: TaskItem?
    var defaultDate: Date = Date.today

    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss
    @Query(sort: \TaskCategory.sortOrder) private var categories: [TaskCategory]
    @Query private var allTasks: [TaskItem]
    @Query private var allSeries: [RecurringSeries]
    @AppStorage(SettingsKey.reminderHour) private var reminderHour = 9

    @State private var title = ""
    @State private var notes = ""
    @State private var scheduledDate = Date.today
    @State private var hasDeadline = false
    @State private var deadline = Date.today.adding(days: 3)
    @State private var priority: Priority = .medium
    @State private var minutes = 30
    @State private var category: TaskCategory?
    @State private var hasFixedTime = false
    @State private var fixedTime = Date.todayAt(minute: 540)
    @State private var hasReminder = false
    @State private var reminder = Date()
    @State private var loaded = false
    @State private var showDeleteConfirm = false
    @State private var suggestedHint: String?
    @State private var series: RecurringSeries?
    @State private var repeatPreset: RepeatPreset = .none
    @State private var weeklyDays: Set<Int> = []
    @State private var weekInterval = 1
    @State private var dayInterval = 2
    @State private var hasUntil = false
    @State private var untilDate = Date.today.adding(days: 30)
    @State private var skipMissed = true
    @FocusState private var titleFocused: Bool

    private var trimmedTitle: String {
        title.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    TextField("工作名稱", text: $title)
                        .focused($titleFocused)
                        .submitLabel(.done)
                    TextField("備註（選填）", text: $notes, axis: .vertical)
                        .lineLimit(1...5)
                }

                Section("分類與優先順序") {
                    Picker("分類", selection: $category) {
                        Text("無").tag(TaskCategory?.none)
                        ForEach(categories) { c in
                            Label(c.name, systemImage: c.symbol).tag(Optional(c))
                        }
                    }
                    Picker("優先順序", selection: $priority) {
                        ForEach(Priority.allCases) { p in
                            Text(p.label).tag(p)
                        }
                    }
                    .pickerStyle(.segmented)
                }

                Section {
                    DatePicker("排定日期", selection: $scheduledDate, displayedComponents: .date)
                    Stepper(value: $minutes, in: 15...600, step: 15) {
                        LabeledContent("預估時間", value: DateText.duration(minutes))
                    }
                    Toggle("截止日期", isOn: $hasDeadline.animation())
                    if hasDeadline {
                        DatePicker("截止", selection: $deadline, displayedComponents: .date)
                    }
                    Button {
                        suggestDate()
                    } label: {
                        Label("幫我找有空的一天", systemImage: "sparkles")
                    }
                    if let suggestedHint {
                        Text(suggestedHint)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                } header: {
                    Text("時間")
                } footer: {
                    Text("智慧排程會考慮每天已排的工作量、優先順序與截止日。")
                }

                Section {
                    Toggle("指定開始時間", isOn: $hasFixedTime.animation())
                    if hasFixedTime {
                        DatePicker("開始", selection: $fixedTime, displayedComponents: .hourAndMinute)
                        LabeledContent(
                            "結束",
                            value: DateText.hm(fixedTime.minuteOfDay + minutes)
                        )
                    } else if let task, let range = task.timeRangeText {
                        LabeledContent("目前自動排在", value: range)
                    }
                } header: {
                    Text("時段")
                } footer: {
                    Text(hasFixedTime
                         ? "固定時間的工作（例如會議、上課）不會被自動排程移動。"
                         : "不指定的話，會在時間表裡自動排進當天有空的時段。")
                }

                Section {
                    Picker("重複", selection: $repeatPreset) {
                        ForEach(RepeatPreset.allCases) { Text($0.rawValue).tag($0) }
                    }
                    if repeatPreset == .weekly {
                        WeekdayPicker(selection: $weeklyDays)
                        Stepper(value: $weekInterval, in: 1...4) {
                            LabeledContent("間隔", value: weekInterval == 1 ? "每週" : "每 \(weekInterval) 週")
                        }
                    }
                    if repeatPreset == .everyNDays {
                        Stepper(value: $dayInterval, in: 2...30) {
                            LabeledContent("每隔", value: "\(dayInterval) 天")
                        }
                    }
                    if repeatPreset == .monthly {
                        LabeledContent("日期", value: "每月 \(Calendar.current.component(.day, from: scheduledDate)) 日")
                    }
                    if repeatPreset != .none {
                        Toggle("結束日期", isOn: $hasUntil.animation())
                        if hasUntil {
                            DatePicker("重複到", selection: $untilDate, in: scheduledDate..., displayedComponents: .date)
                        }
                        Toggle("沒完成就略過", isOn: $skipMissed)
                    }
                } header: {
                    Text("重複")
                } footer: {
                    Text(repeatFooter)
                }

                Section("提醒") {
                    Toggle("提醒我", isOn: $hasReminder.animation())
                    if hasReminder {
                        DatePicker("提醒時間", selection: $reminder)
                    }
                    if hasDeadline {
                        Text("截止日前一天 \(reminderHour):00 也會自動提醒")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    }
                }

                if let task {
                    Section {
                        if task.rescheduleCount > 0 {
                            LabeledContent("已延後", value: "\(task.rescheduleCount) 次")
                        }
                        if let series {
                            LabeledContent("重複", value: series.summary)
                        }
                        LabeledContent("建立於", value: DateText.md(task.createdAt))
                        Button("刪除這項工作", role: .destructive) { showDeleteConfirm = true }
                    }
                }
            }
            .navigationTitle(task == nil ? "新增工作" : "編輯工作")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("取消") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("儲存") { save() }
                        .disabled(trimmedTitle.isEmpty)
                }
            }
            .confirmationDialog(series == nil ? "確定要刪除？" : "這是重複的工作", isPresented: $showDeleteConfirm, titleVisibility: .visible) {
                if let series {
                    Button("只刪除這一次", role: .destructive) {
                        if let task { TaskActions.delete(task, in: context) }
                        dismiss()
                    }
                    Button("刪除這次和之後全部", role: .destructive) {
                        if let task {
                            RecurrenceEngine.stop(series, keeping: task, context: context)
                            TaskActions.delete(task, in: context)
                        }
                        dismiss()
                    }
                } else {
                    Button("刪除", role: .destructive) {
                        if let task { TaskActions.delete(task, in: context) }
                        dismiss()
                    }
                }
            }
            .onChange(of: repeatPreset) { _, preset in
                if preset == .weekly && weeklyDays.isEmpty {
                    weeklyDays = [Calendar.current.component(.weekday, from: scheduledDate)]
                }
            }
            .onChange(of: hasReminder) { _, on in
                if on { Task { await NotificationManager.requestAuthorization() } }
            }
            .onChange(of: hasDeadline) { _, on in
                if on { Task { await NotificationManager.requestAuthorization() } }
            }
            .onAppear(perform: load)
        }
    }

    private func load() {
        guard !loaded else { return }
        loaded = true
        if let task {
            title = task.title
            notes = task.notes
            scheduledDate = task.scheduledDate
            hasDeadline = task.deadline != nil
            deadline = task.deadline ?? task.scheduledDate.adding(days: 3)
            priority = task.priority
            minutes = task.estimatedMinutes
            category = task.category
            hasReminder = task.reminderDate != nil
            reminder = task.reminderDate ?? defaultReminder(on: task.scheduledDate)
            hasFixedTime = task.timeLocked && task.startMinute != nil
            fixedTime = Date.todayAt(minute: task.startMinute ?? WorkHours.current.start)
            if let sid = task.seriesID, let s = allSeries.first(where: { $0.id == sid }) {
                loadSeries(s)
            }
        } else {
            scheduledDate = defaultDate.startOfDay
            deadline = defaultDate.adding(days: 3)
            reminder = defaultReminder(on: defaultDate)
            category = categories.first
            fixedTime = Date.todayAt(minute: WorkHours.current.start)
            titleFocused = true
        }
    }

    private var repeatFooter: String {
        guard repeatPreset != .none else {
            return "例如每天運動、每週三上課、每月繳房租。"
        }
        var text = "從排定日期開始，自動產生未來 4 週的工作。"
        text += skipMissed ? "沒完成的那一次會自動略過，不會累積成逾期。" : "沒完成的會留下來，可以重新規劃。"
        if series != nil { text += "儲存後會套用到之後還沒完成的每一次。" }
        return text
    }

    private func loadSeries(_ s: RecurringSeries) {
        series = s
        let n = max(s.interval, 1)
        switch s.freq {
        case .daily:
            if n == 1 { repeatPreset = .daily } else { repeatPreset = .everyNDays; dayInterval = n }
        case .weekly:
            let days = s.weekdays.isEmpty ? [Calendar.current.component(.weekday, from: s.anchorDate)] : s.weekdays
            if n == 1 && days == Set(2...6) {
                repeatPreset = .weekdays
            } else {
                repeatPreset = .weekly
                weeklyDays = days
                weekInterval = n
            }
        case .monthly:
            repeatPreset = .monthly
        }
        hasUntil = s.untilDate != nil
        untilDate = s.untilDate ?? scheduledDate.adding(days: 30)
        skipMissed = s.skipMissed
    }

    /// 把畫面上的內容與重複規則寫進 series
    private func applySeries(_ s: RecurringSeries, anchor: Date) {
        let day = anchor.startOfDay
        s.title = trimmedTitle
        s.notes = notes
        s.priorityRaw = priority.rawValue
        s.estimatedMinutes = minutes
        s.category = category
        s.startMinute = hasFixedTime ? fixedTime.minuteOfDay : nil
        s.deadlineOffset = hasDeadline ? max(0, day.daysBetween(deadline)) : nil
        switch repeatPreset {
        case .none:
            break
        case .daily:
            s.freq = .daily; s.interval = 1
        case .everyNDays:
            s.freq = .daily; s.interval = dayInterval
        case .weekdays:
            s.freq = .weekly; s.interval = 1; s.weekdays = Set(2...6)
        case .weekly:
            s.freq = .weekly; s.interval = weekInterval
            s.weekdays = weeklyDays.isEmpty ? [Calendar.current.component(.weekday, from: day)] : weeklyDays
        case .monthly:
            s.freq = .monthly; s.interval = 1
        }
        s.anchorDate = day
        s.untilDate = hasUntil ? untilDate.startOfDay : nil
        s.skipMissed = skipMissed
    }

    private func defaultReminder(on day: Date) -> Date {
        var comps = Calendar.current.dateComponents([.year, .month, .day], from: day)
        comps.hour = reminderHour
        comps.minute = 0
        let candidate = Calendar.current.date(from: comps) ?? Date()
        return candidate > Date() ? candidate : Date().addingTimeInterval(3600)
    }

    private func suggestDate() {
        var excluding = Set<UUID>()
        if let task { excluding.insert(task.id) }
        let day = Scheduler.suggest(
            minutes: minutes,
            deadline: hasDeadline ? deadline : nil,
            allTasks: allTasks,
            excluding: excluding,
            start: Date.today
        )
        withAnimation {
            scheduledDate = day
            suggestedHint = "建議排在 \(DateText.relative(day))（\(DateText.md(day))）"
        }
    }

    private func save() {
        // 新增一個重複工作：只建立規則，由 RecurrenceEngine 產生每一次
        if task == nil && repeatPreset != .none {
            let s = RecurringSeries()
            context.insert(s)
            applySeries(s, anchor: scheduledDate)
            RecurrenceEngine.refresh(context: context)
            dismiss()
            return
        }

        let item: TaskItem
        if let task {
            item = task
        } else {
            item = TaskItem(title: trimmedTitle)
            context.insert(item)
        }

        let newDay = scheduledDate.startOfDay
        let dayChanged = !newDay.isSameDay(as: item.scheduledDate)
        if task != nil, newDay > item.scheduledDate.startOfDay {
            item.rescheduleCount += 1
        }

        if hasFixedTime {
            item.timeLocked = true
            item.startMinute = fixedTime.minuteOfDay
        } else {
            // 原本是固定時間、或換了日期、或時間長度改了 → 交給自動排程重新排
            if item.timeLocked || dayChanged || item.estimatedMinutes != minutes {
                item.startMinute = nil
            }
            item.timeLocked = false
        }

        item.title = trimmedTitle
        item.notes = notes
        item.scheduledDate = newDay
        item.deadline = hasDeadline ? deadline.startOfDay : nil
        item.priority = priority
        item.estimatedMinutes = minutes
        item.category = category
        item.reminderDate = hasReminder ? reminder : nil

        if task != nil {
            if repeatPreset == .none {
                if let series { RecurrenceEngine.stop(series, keeping: item, context: context) }
            } else {
                let s: RecurringSeries
                if let series {
                    s = series
                } else {
                    s = RecurringSeries()
                    context.insert(s)
                }
                applySeries(s, anchor: newDay)
                item.seriesID = s.id
                item.occurrenceDate = newDay
                item.detached = false
                RecurrenceEngine.regenerate(s, keeping: item, context: context)
            }
        }

        NotificationManager.schedule(for: item)
        dismiss()
    }
}

/// 選星期幾（可複選）
struct WeekdayPicker: View {
    @Binding var selection: Set<Int>
    private let names = ["日", "一", "二", "三", "四", "五", "六"]

    var body: some View {
        HStack(spacing: 6) {
            ForEach(1...7, id: \.self) { wd in
                let on = selection.contains(wd)
                Button {
                    if on { if selection.count > 1 { selection.remove(wd) } } else { selection.insert(wd) }
                } label: {
                    Text(names[wd - 1])
                        .font(.subheadline.weight(on ? .bold : .regular))
                        .frame(maxWidth: .infinity, minHeight: 34)
                        .background(on ? Color.accentColor : Color(.tertiarySystemFill), in: Circle())
                        .foregroundStyle(on ? Color.white : Color.primary)
                }
                .buttonStyle(.plain)
                .accessibilityLabel("星期\(names[wd - 1])")
                .accessibilityAddTraits(on ? .isSelected : [])
            }
        }
        .padding(.vertical, 4)
    }
}
