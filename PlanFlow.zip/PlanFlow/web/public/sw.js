/* 排程本 service worker
 * - 通知：App 開著時由網頁送出；App 關掉時由推播伺服器送來
 * - 加快開啟：Firebase 程式、字型、圖示存在手機裡；網頁本身先跟網路拿最新的（3 秒拿不到就用存著的）
 */
const CACHE = "planflow-v2";
const IMMUTABLE = /^https:\/\/www\.gstatic\.com\/firebasejs\/\d+\.\d+\.\d+\//;
const FONTS = /^https:\/\/fonts\.(googleapis|gstatic)\.com\//;
self.addEventListener("install", e => {
  self.skipWaiting();
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(["/", "/icon-192.png", "/manifest.webmanifest"]).catch(() => {})));
});
self.addEventListener("activate", e => e.waitUntil((async () => {
  for (const k of await caches.keys()) if (k !== CACHE) await caches.delete(k);
  await self.clients.claim();
})()));
async function cacheFirst(req) {
  const c = await caches.open(CACHE), hit = await c.match(req);
  if (hit) return hit;
  const res = await fetch(req);
  if (res && (res.ok || res.type === "opaque")) c.put(req, res.clone());
  return res;
}
async function staleWhileRevalidate(req) {
  const c = await caches.open(CACHE), hit = await c.match(req);
  const net = fetch(req).then(res => { if (res && (res.ok || res.type === "opaque")) c.put(req, res.clone()); return res; }).catch(() => hit);
  return hit || net;
}
async function networkFirst(req, ms) {
  const c = await caches.open(CACHE);
  const net = fetch(req).then(res => { if (res && res.ok) c.put(req, res.clone()); return res; });
  const timeout = new Promise(r => setTimeout(r, ms));
  const first = await Promise.race([net.catch(() => null), timeout]);
  if (first) return first;
  const hit = await c.match(req, { ignoreSearch: true });
  return hit || net;
}
self.addEventListener("fetch", e => {
  const req = e.request;
  if (req.method !== "GET") return;
  const url = req.url;
  if (IMMUTABLE.test(url)) return e.respondWith(cacheFirst(req));
  if (FONTS.test(url)) return e.respondWith(staleWhileRevalidate(req));
  const u = new URL(url);
  if (u.origin !== location.origin) return;                       // Firestore、Google 登入、AI 都不經過這裡
  if (u.pathname.startsWith("/__/auth")) return;                  // 登入流程不要碰
  if (req.mode === "navigate" || u.pathname === "/" || u.pathname.endsWith(".html")) return e.respondWith(networkFirst(req, 3000));
  if (u.pathname === "/__/firebase/init.json") return e.respondWith(networkFirst(req, 2500));
  if (/\.(png|webmanifest|bin|svg|ico)$/.test(u.pathname)) return e.respondWith(staleWhileRevalidate(req));
});
self.addEventListener("push", e => {
  let d = {};
  try { d = e.data ? e.data.json() : {}; } catch (err) { d = { title: "排程本", body: e.data ? e.data.text() : "" }; }
  e.waitUntil(self.registration.showNotification(d.title || "排程本", {
    body: d.body || "", tag: d.tag || undefined, icon: "/icon-192.png", badge: "/icon-192.png", data: { url: "/" }
  }));
});
self.addEventListener("notificationclick", e => {
  e.notification.close();
  e.waitUntil((async () => {
    const list = await self.clients.matchAll({ type: "window", includeUncontrolled: true });
    for (const c of list) { if ("focus" in c) return c.focus(); }
    if (self.clients.openWindow) return self.clients.openWindow("/");
  })());
});
