(() => {
"use strict";

/* ---------- Icons ---------- */
const I = {
  folder: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2.5 6.2c0-1.1.9-2 2-2h4.6c.6 0 1.1.3 1.5.7l1.3 1.5h7.6c1.1 0 2 .9 2 2v9.4c0 1.1-.9 2-2 2h-15c-1.1 0-2-.9-2-2z" fill="currentColor" opacity=".35"/><path d="M2.5 9.2c0-1.1.9-2 2-2h15c1.1 0 2 .9 2 2v8.6c0 1.1-.9 2-2 2h-15c-1.1 0-2-.9-2-2z" fill="currentColor"/><path d="M8.6 13.6l2.2 2.2 4.6-4.6" fill="none" stroke="#fff" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>',
  plus: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>',
  move: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="13" height="14" rx="2.5"/><path d="M3 9.5h13M7 3v4M12 3v4"/><path d="M15 15h6M18.5 12.5L21 15l-2.5 2.5"/></svg>',
  cal: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="3.5" y="5" width="17" height="15" rx="3"/><path d="M3.5 10h17M8 3v4M16 3v4"/></svg>',
  clock: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/></svg>',
  flag: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 21V4h11l-2 4 2 4H5"/></svg>',
  redo: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 16a7 7 0 0 1 13-5"/><path d="M18 6v5h-5"/></svg>',
  spark: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l1.9 5.6L19.5 9.5l-5.6 1.9L12 17l-1.9-5.6L4.5 9.5l5.6-1.9z"/><path d="M19 15l.9 2.1L22 18l-2.1.9L19 21l-.9-2.1L16 18l2.1-.9z"/></svg>',
  pencil: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13.5 6.5l4 4"/></svg>',
  trash: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/></svg>',
  x: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"><path d="M7 7l10 10M17 7L7 17"/></svg>',
  clip: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5l-8.6 8.6a5.5 5.5 0 01-7.8-7.8l8.6-8.6a3.7 3.7 0 015.2 5.2l-8.6 8.6a1.8 1.8 0 01-2.6-2.6l7.9-7.9"/></svg>',
  bell: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 16V11a6 6 0 0112 0v5l1.5 2h-15z"/><path d="M10 20.5a2 2 0 004 0"/></svg>',
  alert: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M12 7.5v5.5M12 16.5v.01"/></svg>',
  sun: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="4"/><path d="M12 2.5v2M12 19.5v2M2.5 12h2M19.5 12h2M5.3 5.3l1.4 1.4M17.3 17.3l1.4 1.4M5.3 18.7l1.4-1.4M17.3 6.7l1.4-1.4"/></svg>',
  arrow: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 12h15M14 6l6 6-6 6"/></svg>',
  left: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M15 5l-7 7 7 7"/></svg>',
  right: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M9 5l7 7-7 7"/></svg>',
  wand: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 20L15 9M13 7l4 4"/><path d="M18 3v3M16.5 4.5h3M20 9v2M19 10h2M9 3v2M8 4h2"/></svg>',
  tToday: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 6.5l1.8 1.8L9 5M4 12.5l1.8 1.8L9 11M4 18.5l1.8 1.8L9 17"/><path d="M12 7h8M12 13h8M12 19h8"/></svg>',
  tStats: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 20h16"/><rect x="5.5" y="11" width="3" height="6" rx="1"/><rect x="10.5" y="6" width="3" height="11" rx="1"/><rect x="15.5" y="13" width="3" height="4" rx="1"/></svg>',
  repeat: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 2l3 3-3 3"/><path d="M4 11V9a4 4 0 0 1 4-4h12"/><path d="M7 22l-3-3 3-3"/><path d="M20 13v2a4 4 0 0 1-4 4H4"/></svg>',
  pin: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M15 3l6 6-2.5 1-3.5 3.5.5 4.5-2 2-4-4-5 5-1-1 5-5-4-4 2-2 4.5.5L14 5.5z"/></svg>',
  tSet: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 7h10M18 7h2M4 17h2M10 17h10"/><circle cx="16" cy="7" r="2.2"/><circle cx="8" cy="17" r="2.2"/></svg>'
};

/* ---------- Dates (all dates are "YYYY-MM-DD" strings) ---------- */
const WD = ["日", "一", "二", "三", "四", "五", "六"];
const pad = n => String(n).padStart(2, "0");
const key = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const parse = k => { const [y, m, d] = k.split("-").map(Number); return new Date(y, m - 1, d); };
const addDays = (k, n) => { const d = parse(k); d.setDate(d.getDate() + n); return key(d); };
const today = () => key(new Date());
const diff = (a, b) => Math.round((parse(b) - parse(a)) / 86400000);
const isWeekend = k => { const w = parse(k).getDay(); return w === 0 || w === 6; };
const md = k => { const d = parse(k); return `${d.getMonth() + 1}/${d.getDate()} (${WD[d.getDay()]})`; };
const short = k => { const d = parse(k); return `${d.getMonth() + 1}/${d.getDate()}`; };
const full = k => { const d = parse(k); return `${d.getMonth() + 1}月${d.getDate()}日 星期${WD[d.getDay()]}`; };
const rel = k => { const n = diff(today(), k); return n === 0 ? "今天" : n === 1 ? "明天" : n === 2 ? "後天" : n === -1 ? "昨天" : md(k); };
const hm = m => `${pad(Math.floor(m / 60))}:${pad(m % 60)}`;
const toMin = s => { const [h, m] = String(s || "0:0").split(":").map(Number); return (h || 0) * 60 + (m || 0); };
const nowMin = () => { const d = new Date(); return d.getHours() * 60 + d.getMinutes(); };
const range = t => t.start == null ? null : `${hm(t.start)}–${hm(t.start + t.min)}`;
const dur = m => m < 60 ? `${m} 分鐘` : (m % 60 ? `${Math.floor(m / 60)} 小時 ${m % 60} 分` : `${m / 60} 小時`);
const nextMonday = () => { let k = addDays(today(), 1); while (parse(k).getDay() !== 1) k = addDays(k, 1); return k; };
const weekStart = k => addDays(k, -parse(k).getDay());
const maxKey = (a, b) => a > b ? a : b;
const esc = s => String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const uid = () => Math.random().toString(36).slice(2, 10);

const PRI = ["低", "中", "高", "緊急"];
const PALETTE = ["#4F6BFF", "#8E5CF6", "#24965F", "#E8A23C", "#DC3F45", "#E2559B", "#159C93", "#64748B"];
const MINUTES = [15, 30, 45, 60, 90, 120, 180, 240, 300, 360, 480];

/* ---------- State ---------- */
let S;

function seed() {
  const t = today();
  const cats = [
    { id: "c1", name: "工作", color: "#4F6BFF" },
    { id: "c2", name: "學習", color: "#8E5CF6" },
    { id: "c3", name: "生活", color: "#24965F" },
    { id: "c4", name: "其他", color: "#E8A23C" },
    { id: "cev", name: "固定事件", color: "#64748B", event: true }
  ];
  const mk = (title, off, o = {}) => ({
    id: uid(), title, notes: o.notes || "", date: addDays(t, off), deadline: o.dl == null ? null : addDays(t, o.dl),
    pri: o.pri ?? 1, min: o.min ?? 30, cat: o.cat || "c1", done: !!o.done, doneOn: o.done ? addDays(t, off) : null,
    resched: o.r || 0, created: Date.now() - 86400000 * 20,
    start: o.at == null ? null : o.at, locked: o.at != null
  });
  const tasks = [
    mk("整理實驗數據", -2, { pri: 2, min: 90, dl: 2, r: 1 }),
    mk("回覆客戶 email", -1, { pri: 1, min: 15 }),
    mk("讀完第三章講義", -1, { pri: 2, min: 60, cat: "c2", dl: 5, r: 3 }),
    mk("寫週報", 0, { pri: 3, min: 45, dl: 0 }),
    mk("組會報告（固定時間）", 0, { pri: 2, min: 60, at: 14 * 60 }),
    mk("上課", 0, { min: 120, at: 10 * 60, cat: "cev" }),
    mk("完成作業第 5 題", 0, { pri: 2, min: 120, cat: "c2", dl: 1 }),
    mk("買衛生紙和洗衣精", 0, { pri: 0, min: 20, cat: "c3" }),
    mk("預約健身房", 0, { pri: 0, min: 10, cat: "c3", done: true }),
    mk("準備報告投影片", 1, { pri: 2, min: 120, dl: 4 }),
    mk("讀兩篇論文", 2, { pri: 1, min: 90, cat: "c2" }),
    mk("繳電話費", 3, { pri: 1, min: 10, cat: "c3", dl: 5 }),
    mk("整理房間", 5, { pri: 0, min: 60, cat: "c3" })
  ];
  const past = [
    ["寄出會議記錄", -1, "c1"], ["洗衣服", -1, "c3"], ["複習上週筆記", -2, "c2"], ["訂高鐵票", -3, "c4"],
    ["跑步 30 分鐘", -3, "c3"], ["修改報告格式", -4, "c1"], ["交實驗報告", -5, "c2"], ["整理信箱", -5, "c1"],
    ["買菜", -6, "c3"], ["看線上課程", -6, "c2"], ["更新進度表", -8, "c1"], ["繳房租", -10, "c3"], ["讀論文", -12, "c2"]
  ];
  for (const [title, off, cat] of past) tasks.push(mk(title, off, { cat, done: true, min: 30 }));
  tasks.push(mk("填報帳單據", -4, { pri: 1, min: 20, done: false, r: 2 }));
  tasks[tasks.length - 1].date = addDays(t, -1);
  return { tasks, cats };
}

const DEFAULT_SETTINGS = {
  cap: 240, skipWeekends: false, prompt: true, lastPrompt: "",
  workStart: 540, workEnd: 1080, breakOn: true, breakStart: 720, breakEnd: 780, gap: 10,
  dinnerOn: false, dinnerStart: 1080, dinnerEnd: 1140, setupDone: false,
  swipeR: ["done", "extend15"], swipeL: ["cancel", "autolater"], anim: "ios",
  autoReflow: true, reflowMode: "ask", eventCatAdded: false,
  notifyOn: false, notifyLead: 10, notifyDeadline: true, notifyDue: true,
  chunkMax: 120, chunkMin: 30, estLog: [], learnLog: [], gemLog: [],
  bufferX: 1.5, aiAuto: true, morningPlan: true, claudeModel: "claude-haiku-5-5"
};
const defaultCats = () => [
  { id: "c1", name: "工作", color: "#4F6BFF" },
  { id: "c2", name: "學習", color: "#8E5CF6" },
  { id: "c3", name: "生活", color: "#24965F" },
  { id: "c4", name: "其他", color: "#E8A23C" },
  { id: "cev", name: "固定事件", color: "#64748B", event: true }
];
function normalize(t) {
  return {
    id: t.id, title: String(t.title || ""), notes: t.notes || "", date: t.date || today(), deadline: t.deadline || null,
    pri: t.pri ?? 1, min: t.min ?? 30, cat: t.cat || "", done: !!t.done, doneOn: t.doneOn || null,
    resched: t.resched || 0, created: t.created || Date.now(), start: t.start ?? null, locked: !!t.locked,
    series: t.series || null, occ: t.occ || null, detached: !!t.detached,
    ...(t.wid ? { wid: t.wid, wname: String(t.wname || t.title || ""), wtype: t.wtype || "其他" } : {}),
    ...(t.cancelled ? { cancelled: true } : {}), ...(t.ot ? { ot: +t.ot, ...(t.otk ? { otk: t.otk } : {}) } : {}),
    ...(t.endDate && t.endDate > (t.date || "") ? { endDate: t.endDate } : {}), ...(t.dday ? { dday: true } : {}),
    ...(t.doneAt != null && t.done ? { doneAt: +t.doneAt } : {}), ...(t.actMin ? { actMin: +t.actMin } : {}),
    ...(t.order != null ? { order: +t.order } : {}), ...(t.rate ? { rate: +t.rate } : {}), ...(t.anytime && t.start == null ? { anytime: true } : {})
  };
}

S = { tasks: [], series: [], cats: defaultCats(), settings: { ...DEFAULT_SETTINGS }, sample: false };

/* ---------- Cloud sync (Firebase: Google 登入 + Firestore) ---------- */
const FB = { ready: false, user: null, db: null, loaded: false, preview: false, error: "", synced: { tasks: {}, series: {}, meta: "" }, unsub: [] };

/* ---------- 開啟速度：先用上次存在手機裡的資料畫出來，雲端同步好再換成最新的 ---------- */
const SNAP_KEY = "planflow-snap", CFG_KEY = "planflow-cfg";
const SDK = "https://www.gstatic.com/firebasejs/10.12.2/";
function loadScript(src) {
  return new Promise((res, rej) => { const s = document.createElement("script"); s.src = src; s.async = false; s.onload = res; s.onerror = () => rej(new Error("load " + src)); document.head.appendChild(s); });
}
async function loadFirebaseSDK() {
  if (typeof firebase !== "undefined" && firebase.firestore && firebase.auth) return;
  await loadScript(SDK + "firebase-app-compat.js");
  await Promise.all([loadScript(SDK + "firebase-auth-compat.js"), loadScript(SDK + "firebase-firestore-compat.js")]);
}
let snapT = 0;
function saveSnap(now) {
  const uidNow = FB.user && FB.loaded ? FB.user.uid : FB.preview;
  if (!uidNow) return;
  clearTimeout(snapT);
  const write = () => {
    try {
      const cut = addDays(today(), -21);
      const { gemLog, learnLog, ...st } = S.settings;
      const u = FB.user || FB.previewUser || {};
      const memos = {}; for (const k in S.memos || {}) if (k >= cut) memos[k] = { text: S.memos[k].text, clips: S.memos[k].clips, updated: S.memos[k].updated || 0 };
      localStorage.setItem(SNAP_KEY, JSON.stringify({ uid: uidNow, at: Date.now(), cats: S.cats, settings: st, sample: S.sample,
        tasks: S.tasks.filter(t => t.date >= cut || !t.done), series: S.series, name: u.displayName || "", email: u.email || "", memos,
        // 還沒傳上雲端的修改：記住「改之前」的樣子，下次打開時才知道哪些是自己改的
        ...(FB.preview && FB.base ? { base: FB.base } : {}) }));
    } catch (e) {}
  };
  if (now) write(); else snapT = setTimeout(write, FB.preview ? 150 : 800);
}
function loadSnap() {
  try {
    const x = JSON.parse(localStorage.getItem(SNAP_KEY) || "null");
    if (!x || !x.uid || !Array.isArray(x.tasks)) return false;
    S.cats = x.cats || S.cats; S.settings = { ...DEFAULT_SETTINGS, ...(x.settings || {}) }; S.sample = !!x.sample;
    S.tasks = x.tasks.map(normalize); S.series = x.series || [];
    if (x.memos) S.memos = x.memos;
    FB.preview = x.uid; FB.previewUser = { displayName: x.name, email: x.email };
    FB.base = x.base || previewBase();
    return true;
  } catch (e) { return false; }
}
/** 「從手機暫存打開、雲端還沒連上」時也能直接改：記住打開時的樣子，連上後把自己改過的部分合併回去 */
function previewBase() {
  const m = {}, sr = {};
  for (const t of S.tasks) m[t.id] = JSON.stringify(normalize(t));
  for (const x of S.series) sr[x.id] = JSON.stringify(x);
  return { tasks: m, series: sr, meta: metaJSON() };
}
function capturePreview() {
  if (FB.preview && FB.base && !FB.local) FB.local = { tasks: S.tasks.map(t => ({ ...t })), series: S.series.map(x => ({ ...x })), meta: metaJSON() };
}
function mergePreview() {
  const L = FB.local, B = FB.base; FB.local = null; FB.base = null;
  if (!L || !B) return false;
  let changed = false;
  for (const coll of ["tasks", "series"]) {
    const out = new Map(S[coll].map(x => [x.id, x])), loc = new Map(L[coll].map(x => [x.id, x]));
    const j = x => coll === "tasks" ? JSON.stringify(normalize(x)) : JSON.stringify(x);
    for (const [id, x] of loc) if (B[coll][id] !== j(x)) { out.set(id, coll === "tasks" ? normalize(x) : x); changed = true; }
    for (const id in B[coll]) if (!loc.has(id) && out.has(id)) { out.delete(id); changed = true; }
    S[coll] = [...out.values()];
  }
  if (L.meta !== B.meta) {
    const m = JSON.parse(L.meta);
    S.cats = m.cats; S.settings = { ...S.settings, ...m.settings }; S.sample = m.sample; changed = true;
  }
  return changed;
}
let splashGone = false;
function hideSplash() {
  if (splashGone) return; splashGone = true;
  const el = document.getElementById("splash"); if (!el) return;
  el.classList.add("out");
  setTimeout(() => el.remove(), 480);
}
/** 太久沒反應時，在開啟畫面上說明一下 */
setTimeout(() => { if (!splashGone) { const m = document.getElementById("sp-msg"); if (m) m.textContent = "網路比較慢，正在連線…"; } }, 4000);
setTimeout(() => { if (!splashGone) { hideSplash(); renderMain(); } }, 9000);
const metaJSON = () => JSON.stringify({ cats: S.cats, settings: S.settings, sample: !!S.sample });
const userRef = () => FB.db.collection("users").doc(FB.user.uid);

function fbError(err) {
  const code = (err && err.code) || "";
  if (code === "permission-denied") return "沒有權限讀寫資料，請確認 Firestore 規則已部署。";
  if (code.includes("unauthorized-domain")) return "這個網址還沒加入 Firebase 的授權網域。";
  if (code.includes("operation-not-allowed")) return "Firebase 還沒開啟 Google 登入。";
  if (code.includes("network")) return "網路連線失敗，請稍後再試。";
  return (err && err.message) || "發生錯誤";
}

async function initFirebase() {
  // web.app 網址統一轉到 firebaseapp.com，登入才會在同一個網域完成
  if (/\.web\.app$/.test(location.hostname)) {
    location.replace(location.href.replace(".web.app", ".firebaseapp.com"));
    return;
  }
  let cfg = null;
  try { cfg = JSON.parse(localStorage.getItem(CFG_KEY) || "null"); } catch (e) {}
  const cfgFetch = fetch("/__/firebase/init.json").then(r => { if (!r.ok) throw new Error(r.status); return r.json(); })
    .then(c => { try { localStorage.setItem(CFG_KEY, JSON.stringify(c)); } catch (e) {} return c; });
  try {
    // 設定和 Firebase 程式同時下載；有上次的設定就不用等
    const [, fresh] = await Promise.all([loadFirebaseSDK(), cfg ? cfgFetch.catch(() => null) && null : cfgFetch]);
    if (!cfg) cfg = fresh;
  } catch (e) {
    FB.error = typeof firebase === "undefined" ? "無法載入 Firebase，請檢查網路後重新打開。" : "讀不到 Firebase 設定。請確認網站是部署在 Firebase Hosting，並且已在 Firebase 專案新增「網頁應用程式」。";
    FB.ready = true; FB.preview = false; render(); hideSplash(); return;
  }
  cfg.authDomain = location.hostname;
  FB.cfg = cfg;
  firebase.initializeApp(cfg);
  FB.db = firebase.firestore();
  try { await FB.db.enablePersistence({ synchronizeTabs: true }); } catch (e) {}
  const auth = firebase.auth();
  auth.getRedirectResult().then(r => { gmailFromRedirect(r); if (gmailUI.afterLoad && FB.loaded) { gmailUI.afterLoad = null; checkGmail(true); } })
    .catch(err => { try { if (localStorage.getItem(GMAIL_PENDING)) { localStorage.removeItem(GMAIL_PENDING); toast("Gmail 沒有連結成功：" + fbError(err)); return; } } catch (e) {} FB.error = fbError(err); render(); });
  auth.onAuthStateChanged(u => {
    FB.user = u; FB.ready = true;
    if (!u || u.uid !== FB.preview) { if (FB.preview) { S.tasks = []; S.series = []; } FB.preview = false; FB.base = null; FB.local = null; }
    FB.unsub.forEach(f => f()); FB.unsub = [];
    FB.loaded = false;
    if (u) subscribe(); else { S.tasks = []; S.series = []; FB.synced = { tasks: {}, series: {}, meta: "" }; }
    render();
  });
}

function signIn() {
  FB.error = "";
  const provider = new firebase.auth.GoogleAuthProvider();
  provider.setCustomParameters({ prompt: "select_account" });
  firebase.auth().signInWithRedirect(provider).catch(err => { FB.error = fbError(err); render(); });
}
function signOut() { firebase.auth().signOut(); ui.tab = "today"; applyBg(""); try { localStorage.removeItem(BG_CACHE); } catch (e) {} }

function subscribe() {
  const ref = userRef();
  let gotMeta = false, gotTasks = false, gotSeries = false;
  const done = () => {
    if (!gotMeta || !gotTasks || !gotSeries) return;
    const first = !FB.loaded;
    FB.loaded = true;
    const wasPreview = !!FB.preview;
    FB.preview = false;
    if (wasPreview && mergePreview()) { save(); toast("剛剛的修改已同步"); }
    renderMain();
    if (!wasPreview && first) animateView("fade-in");
    saveSnap();
    if (!ui.sheet) renderSheet();
    if (first) rolloverPrompt();
    if (first) setTimeout(() => {
      if (gmailUI.afterLoad) { gmailUI.afterLoad = null; checkGmail(true); }
      else if (S.settings.gmailAuto && !ui.sheet) {
        if (gmailToken()) checkGmail(false);
        else { const k = "planflow-gmail-hint"; let d = ""; try { d = localStorage.getItem(k); localStorage.setItem(k, today()); } catch (e) {} if (d !== today()) toast("Gmail 授權過期了：到「設定 › Gmail」按一下重新連結"); }
      }
    }, 900);
  };
  FB.unsub.push(ref.onSnapshot(snap => {
    capturePreview();
    if (!snap.exists) {
      ref.set({ cats: defaultCats(), settings: { ...DEFAULT_SETTINGS }, sample: false, createdAt: Date.now() });
      return;
    }
    const d = snap.data();
    S.cats = Array.isArray(d.cats) ? d.cats : defaultCats();
    S.settings = { ...DEFAULT_SETTINGS, ...(d.settings || {}) };
    applySkin(S.settings.skin); applyAnim(S.settings.anim);
    S.sample = !!d.sample;
    FB.synced.meta = metaJSON();
    gotMeta = true; done();
  }, err => { FB.error = fbError(err); render(); }));
  FB.unsub.push(ref.collection("tasks").onSnapshot(qs => {
    capturePreview();
    const arr = [], map = {};
    qs.forEach(doc => { const t = normalize({ ...doc.data(), id: doc.id }); arr.push(t); map[t.id] = JSON.stringify(t); });
    S.tasks = arr; FB.synced.tasks = map;
    gotTasks = true; done();
  }, err => { FB.error = fbError(err); render(); }));
  subscribeBg();
  subscribePushlog();
  subscribeMemos();
  FB.unsub.push(ref.collection("series").onSnapshot(qs => {
    capturePreview();
    const arr = [], map = {};
    qs.forEach(doc => { const x = { ...doc.data(), id: doc.id }; arr.push(x); map[x.id] = JSON.stringify(x); });
    S.series = arr; FB.synced.series = map;
    gotSeries = true; done();
  }, err => { FB.error = fbError(err); render(); }));
}

/** 把有變動的工作和設定寫回雲端 */
/** 加班的整理：
 *  1. 過了半夜 12 點的部分接到隔天（沒有 25 點這種東西）
 *  2. 加班的工作被延後／移走了 → 拿掉加班標籤（之後又超時，會再出現加班提示） */
const otKey = t => `${t.date}@${t.start}`;
function markOT(t, add) { t.ot = (t.ot || 0) + add; t.otk = otKey(t); }
function fixOvertime() {
  for (let i = 0; i < S.tasks.length; i++) {
    const t = S.tasks[i];
    if (t.start == null || t.cancelled) continue;
    if (t.start >= 1440) {                                     // 整段都在半夜之後 → 搬到隔天
      const hadOT = t.ot && t.otk === otKey(t);
      t.date = addDays(t.date, Math.floor(t.start / 1440)); t.start %= 1440;
      if (hadOT) t.otk = otKey(t);
    }
    if (t.start + t.min > 1440 && !t.done) {                   // 跨過半夜 → 切成兩段，後面那段接到隔天 00:00
      const extra = t.start + t.min - 1440, hadOT = t.ot && t.otk === otKey(t);
      t.min = 1440 - t.start;
      const c = { ...t, id: uid(), date: addDays(t.date, 1), start: 0, min: extra, locked: true, created: Date.now(), series: null, occ: null, detached: false };
      if (t.series) c.title = t.title;
      if (hadOT) { t.ot = Math.min(t.ot, t.min); c.ot = extra; c.otk = otKey(c); } else { delete c.ot; delete c.otk; }
      S.tasks.push(c);
    }
  }
  for (const t of S.tasks) {
    if (!t.ot) continue;
    if (!t.otk) { t.otk = otKey(t); continue; }                // 舊資料：從現在開始追蹤
    if (t.otk !== otKey(t)) {                                  // 被延後、改日期或改時間 → 不再算加班
      const movedDay = t.otk.split("@")[0] !== t.date;
      delete t.ot; delete t.otk;
      // 換到別天：不要再固定在加班的時段，回到工作時間內重新排
      if (movedDay && t.start != null && !isEvent(t) && (t.start < S.settings.workStart || t.start >= S.settings.workEnd)) { t.start = null; t.locked = false; }
    }
  }
}
function save() {
  fixOvertime();
  if (FB.preview) { saveSnap(); return; }          // 還沒連上：先存在手機裡，連上後自動傳上去
  if (!FB.user || !FB.loaded) return;
  saveSnap();
  publishShare();
  const ref = userRef();
  const ops = [];
  for (const [coll, list] of [["tasks", S.tasks], ["series", S.series]]) {
    const now = {}, prev = FB.synced[coll];
    for (const x of list) {
      const j = JSON.stringify(x);
      now[x.id] = j;
      if (prev[x.id] !== j) { const { id, ...rest } = x; ops.push(b => b.set(ref.collection(coll).doc(id), rest)); }
    }
    for (const id in prev) if (!(id in now)) ops.push(b => b.delete(ref.collection(coll).doc(id)));
    FB.synced[coll] = now;
  }
  const m = metaJSON();
  if (m !== FB.synced.meta) ops.push(b => b.set(ref, JSON.parse(m), { merge: true }));
  FB.synced.meta = m;
  for (let i = 0; i < ops.length; i += 400) {
    const batch = FB.db.batch();
    ops.slice(i, i + 400).forEach(f => f(batch));
    batch.commit().catch(err => toast(fbError(err)));
  }
}


const ui = { tab: "today", todayMode: "list", calDayMode: "list", calMode: "month", anchor: today(), sel: today(), range: 7, sheet: null, dismissNote: false };

/* ---------- Queries ---------- */
const cat = id => S.cats.find(c => c.id === id);
const task = id => S.tasks.find(t => t.id === id);
const isEvent = t => { const c = cat(t.cat); return !!(c && c.event); };
const isOverdue = t => !t.done && !isEvent(t) && t.date < today();
const pastDeadline = t => !t.done && t.deadline && t.deadline < today();
const sortTasks = list => [...list].sort((a, b) => (a.done - b.done) || ((a.start ?? 9999) - (b.start ?? 9999)) || (b.pri - a.pri) || (a.created - b.created));
const onDay = k => sortTasks(S.tasks.filter(t => t.date === k));
const openMinutes = list => list.filter(t => !t.done && !isEvent(t)).reduce((s, t) => s + t.min, 0);
const eventMinutes = list => list.filter(t => isEvent(t) && !t.cancelled).reduce((s, t) => s + t.min, 0);
const eventsOn = k => S.tasks.filter(t => t.date === k && isEvent(t)).sort((a, b) => (a.start ?? 9999) - (b.start ?? 9999));

/** 每天要空下來的時間：午餐（午休）、晚餐 */
function breaks() {
  const s = S.settings, out = [];
  if (s.breakOn && s.breakEnd > s.breakStart) out.push([s.breakStart, s.breakEnd, "午休"]);
  if (s.dinnerOn && s.dinnerEnd > s.dinnerStart) out.push([s.dinnerStart, s.dinnerEnd, "晚餐"]);
  return out;
}
/* ---------- Scheduler (same logic as the iOS app) ---------- */
function loadMap(excl) {
  const m = {};
  for (const t of S.tasks) if (!t.done && !excl.has(t.id)) m[t.date] = (m[t.date] || 0) + t.min;
  return m;
}
function bestDay(min, deadline, map, start) {
  const cap = dayCap(), skip = S.settings.skipWeekends;
  const limit = deadline ? maxKey(deadline, start) : null;
  let d = start, fb = null, fbl = Infinity;
  for (let i = 0; i < 366; i++) {
    if (limit && d > limit) break;
    if (!(skip && isWeekend(d))) {
      const u = map[d] || 0;
      if (u === 0 || u + min <= cap) return d;
      if (u < fbl) { fb = d; fbl = u; }
    }
    d = addDays(d, 1);
  }
  if (fb) return fb;
  d = start;
  for (let i = 0; i < 14; i++) { if (!(skip && isWeekend(d))) return d; d = addDays(d, 1); }
  return start;
}
function plan(list, start) {
  const map = loadMap(new Set(list.map(t => t.id)));
  const ord = [...list].sort((a, b) => {
    if (a.pri !== b.pri) return b.pri - a.pri;
    if (a.deadline && b.deadline && a.deadline !== b.deadline) return a.deadline < b.deadline ? -1 : 1;
    if (a.deadline && !b.deadline) return -1;
    if (!a.deadline && b.deadline) return 1;
    return a.min - b.min;
  });
  const r = {};
  for (const t of ord) {
    // 有截止日的：先試著在截止日前一天以前排好，留一天當緩衝
    const d = (t.deadline && t.deadline > start && bestDayFit(t.min, addDays(t.deadline, -1), map, start)) || bestDay(t.min, t.deadline, map, start);
    r[t.id] = d; map[d] = (map[d] || 0) + t.min;
  }
  return r;
}
function overflow(dayTasks) {
  const open = dayTasks.filter(t => !t.done && !isEvent(t)).sort((a, b) => (b.pri - a.pri) || (a.created - b.created));
  const cap = Math.max(0, dayCap() - eventMinutes(dayTasks));
  let used = 0; const extra = [];
  for (const t of open) {
    if (used === 0 || used + t.min <= cap) used += t.min; else extra.push(t);
  }
  return extra;
}

/* ---------- Time slots (same logic as the iOS app) ---------- */
/** 每天能排工作的時間 = 工作時段（開始～結束）扣掉午休 */
function dayCap() { return Math.max(30, availMin()); }
function availMin() {
  const s = S.settings; let total = s.workEnd - s.workStart;
  for (const [a, b] of breaks()) total -= Math.max(0, Math.min(b, s.workEnd) - Math.max(a, s.workStart));
  return Math.max(0, total);
}
/* ---------- 時段習慣：學你習慣在幾點做哪一類事 ---------- */
const habitKey = t => { const c = cat(t.cat); return c && !c.event ? c.name : "_"; };
/** 某一類事在某個時間（分鐘）加分或扣分：做完 +1、自己指定時間 +1.5、被延後 −0.7 */
function habitAdd(catName, minute, w) {
  if (minute == null || isNaN(minute)) return;
  const H = S.settings.habit = { ...(S.settings.habit || {}) };
  const arr = (H[catName] || Array(24).fill(0)).map(v => v * 0.985);       // 舊的習慣慢慢淡掉
  const h = Math.max(0, Math.min(23, Math.floor(minute / 60)));
  arr[h] += w;
  if (h > 0) arr[h - 1] += w * 0.35;
  if (h < 23) arr[h + 1] += w * 0.35;
  H[catName] = arr.map(v => Math.round(Math.max(-5, Math.min(50, v)) * 100) / 100);
}
const habitLearnTask = (t, minute, w) => {
  if (!t || isEvent(t)) return;
  habitAdd(habitKey(t), minute, w);
  habitAdd("_all", minute, w * 0.6);                        // 整體效率：什麼時候比較做得完事
  const k = durKey(t); if (k) habitAdd("t:" + k, minute, w);  // 這件事本身習慣在幾點做
  const H = S.settings.habit, tk = Object.keys(H).filter(x => x.startsWith("t:"));
  if (tk.length > 150) { const sum = x => H[x].reduce((a, v) => a + Math.max(0, v), 0); tk.sort((a, b) => sum(a) - sum(b)).slice(0, tk.length - 150).forEach(x => delete H[x]); }
};
/** 這類事有沒有足夠的習慣資料（累積分數 ≥ 4） */
function habitOf(catName) {
  const a = (S.settings.habit || {})[catName];
  if (!a) return null;
  const pos = a.reduce((x, v) => x + Math.max(0, v), 0);
  return pos >= 4 ? a : null;
}
/** 在可以放的開始時間裡，挑最符合習慣的；沒有習慣資料就挑最早的 */
function pickStart(t, cands) {
  if (!cands.length) return null;
  const own = t.title ? (S.settings.habit || {})["t:" + durKey(t)] : null;
  const ownOk = own && own.reduce((x, v) => x + Math.max(0, v), 0) >= 2 ? own : null;
  const a = ownOk || habitOf(habitKey(t)) || (isFocus(t) ? habitOf("_all") : null);
  if (!a) return cands[0];
  const mx = Math.max(...a, 0.01);
  let best = cands[0], bs = -1e9;
  for (const st of cands) {
    let sc = 0, n = 0;
    for (let m = st; m < st + t.min; m += 30) { sc += a[Math.min(23, Math.floor(m / 60))] / mx; n++; }
    sc = sc / Math.max(1, n) - 0.02 * (st - cands[0]) / 60;      // 越晚扣一點點，避免拖太晚
    if (sc > bs + 1e-9) { bs = sc; best = st; }
  }
  return best;
}
function arrangeTimes(k, mode) {
  if (k < today()) return;
  const s = S.settings, list = S.tasks.filter(t => t.date === k);
  const busy = [];
  for (const [a, b] of breaks()) busy.push([a, b, 0]);
  const todo = [];
  for (const t of list) {
    if (t.cancelled) continue;
    if (t.start != null) {
      if (t.done || t.locked || mode === "fill") busy.push([t.start, t.start + t.min, s.gap]); else todo.push(t);
    } else if (!t.done && !t.anytime) todo.push(t);      // 「隨時」的事（行程頁的待辦盤）不自動排時間
  }
  let earliest = s.workStart;
  if (k === today()) earliest = Math.max(earliest, Math.ceil(nowMin() / 5) * 5);
  todo.sort((a, b) => (b.pri - a.pri) || (a.deadline && b.deadline && a.deadline !== b.deadline ? (a.deadline < b.deadline ? -1 : 1) : (a.deadline ? -1 : b.deadline ? 1 : a.created - b.created)));
  for (const t of todo) {
    // 列出所有放得下的開始時間（每 15 分鐘一格），再依你的時段習慣挑
    const cands = [];
    let st = earliest;
    while (st + t.min <= s.workEnd && cands.length < 120) {
      const e = st + t.min;
      const c = busy.find(b => st < b[1] + b[2] && b[0] < e + b[2]);
      if (c) st = Math.ceil((c[1] + c[2]) / 5) * 5;
      else { cands.push(st); st = Math.ceil((st + 15) / 15) * 15; }
    }
    const placed = pickStart(t, cands);
    t.start = placed;
    if (placed != null) busy.push([placed, placed + t.min, s.gap]);
  }
}

/* ---------- Recurring tasks (same logic as the iOS app) ---------- */
const HORIZON = 28;
const REPEAT_PRESETS = [["none", "不重複"], ["daily", "每天"], ["weekdays", "平日（一到五）"], ["weekly", "每週"], ["monthly", "每月"], ["ndays", "每隔幾天"]];
const seriesOf = id => S.series.find(x => x.id === id);
function seriesMatches(s, k) {
  if (k < s.anchor) return false;
  if (s.until && k > s.until) return false;
  const n = Math.max(1, s.interval || 1);
  if (s.freq === "daily") return diff(s.anchor, k) % n === 0;
  if (s.freq === "weekly") {
    const days = s.weekdays && s.weekdays.length ? s.weekdays : [parse(s.anchor).getDay()];
    if (!days.includes(parse(k).getDay())) return false;
    return Math.round(diff(weekStart(s.anchor), weekStart(k)) / 7) % n === 0;
  }
  if (s.freq === "monthly") {
    const a = parse(s.anchor), d = parse(k);
    const dim = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate();
    if (d.getDate() !== Math.min(a.getDate(), dim)) return false;
    return ((d.getFullYear() - a.getFullYear()) * 12 + d.getMonth() - a.getMonth()) % n === 0;
  }
  return false;
}
function seriesSummary(s) {
  const n = Math.max(1, s.interval || 1);
  if (s.freq === "daily") return n === 1 ? "每天" : `每 ${n} 天`;
  if (s.freq === "weekly") {
    const days = (s.weekdays && s.weekdays.length ? s.weekdays : [parse(s.anchor).getDay()]).slice().sort();
    if (n === 1 && days.join() === "1,2,3,4,5") return "平日（一到五）";
    const list = days.map(d => WD[d]).join("、");
    return n === 1 ? `每週${list}` : `每 ${n} 週的週${list}`;
  }
  const day = parse(s.anchor).getDate();
  return n === 1 ? `每月 ${day} 日` : `每 ${n} 個月的 ${day} 日`;
}
function makeOccurrence(s, k) {
  return {
    id: uid(), title: s.title, notes: s.notes || "", date: k, deadline: s.dlOffset == null ? null : addDays(k, s.dlOffset),
    pri: s.pri, min: s.min, cat: s.cat || "", done: false, doneOn: null, resched: 0, created: Date.now(),
    start: s.start == null ? null : s.start, locked: s.start != null, series: s.id, occ: k, detached: false
  };
}
/** 產生未來 4 週的重複工作，並略過錯過的。有變動就回傳 true */
function refreshRecurring() {
  if (!S.series.length) return false;
  const t0 = today(), horizon = addDays(t0, HORIZON);
  let changed = false;
  for (const s of S.series) {
    if (s.skipMissed) {
      const before = S.tasks.length;
      S.tasks = S.tasks.filter(t => !(t.series === s.id && !t.done && !t.detached && t.date < t0));
      if (S.tasks.length !== before) changed = true;
    }
    const existing = new Set(S.tasks.filter(t => t.series === s.id).map(t => t.occ));
    let d = s.anchor;
    if (s.genUntil) d = maxKey(d, addDays(s.genUntil, 1));
    d = maxKey(d, t0);
    let end = horizon;
    if (s.until && s.until < end) end = s.until;
    for (; d <= end; d = addDays(d, 1)) {
      if (seriesMatches(s, d) && !existing.has(d)) { S.tasks.push(makeOccurrence(s, d)); changed = true; }
    }
    if (!s.genUntil || end > s.genUntil) { s.genUntil = end; changed = true; }
  }
  return changed;
}
function regenerateSeries(s, keepId) {
  const t0 = today();
  S.tasks = S.tasks.filter(t => !(t.series === s.id && t.id !== keepId && !t.done && !t.detached && t.date >= t0));
  s.genUntil = null;
  refreshRecurring();
}
function stopSeries(s, keepId) {
  const t0 = today();
  S.tasks = S.tasks.filter(t => !(t.series === s.id && t.id !== keepId && !t.done && t.date >= t0));
  S.tasks.forEach(t => { if (t.id === keepId) { t.series = null; t.occ = null; t.detached = false; } });
  S.series = S.series.filter(x => x.id !== s.id);
}
let lastRefreshDay = "";
function refreshIfNewDay() {
  if (!FB.loaded || lastRefreshDay === today()) return;
  lastRefreshDay = today();
  if (refreshRecurring()) save();
}

/* ---------- Actions ---------- */
let undoSnap = null;
function snapshot() { undoSnap = JSON.stringify(S.tasks); }
function reschedule(t, k) {
  if (!t || t.date === k) return;
  if (diff(t.date, k) > 0) t.resched++;
  t.date = k;
  if (!t.locked) t.start = null;
  if (t.series) t.detached = true;
}
function toggle(t) {
  if (t && t.cancelled) { t.cancelled = false; t.done = false; t.doneOn = null; return; }   // 取消的再按一次 → 恢復
  if (!t || isEvent(t)) return;
  t.done = !t.done; t.doneOn = t.done ? today() : null;
  if (t.done) t.doneAt = nowMin(); else delete t.doneAt;
  // 今天做完的：記下你實際在什麼時候做這類事
  if (t.done && t.date === today()) { habitLearnTask(t, nowMin() - t.min / 2, 1); durFromDone(t); }
}

/** 過了時間還沒做完的工作，自動往後重新安排。回傳移動的數量 */
/** 把今天這些工作往後排：先找今天之後的空檔，排不下就移到之後有空的日子 */
function pushLater(list) {
  const t0 = today();
  list.forEach(t => { if (t.start != null) habitLearnTask(t, t.start + t.min / 2, -0.7); });   // 這個時段常沒做到 → 扣分
  list.forEach(t => { t.start = null; t.locked = false; });
  arrangeTimes(t0, "fill");
  const still = list.filter(t => t.start == null);
  if (still.length) {
    const r = plan(still, addDays(t0, 1));
    still.forEach(t => reschedule(t, r[t.id]));
    [...new Set(still.map(t => t.date))].forEach(k => arrangeTimes(k, "fill"));
  }
  return still.length;
}
let autoShort = [];
function autoReflow() {
  if (S.settings.reflowMode !== "auto" || !FB.loaded) return 0;
  const t0 = today(), now = nowMin();
  const before = JSON.stringify(S.tasks);
  let moved = 0;
  // 0. 拆段的工作：只把剩下的時數排進截止日前的空檔
  autoShort = [];
  [...new Set(S.tasks.filter(t => t.wid && !t.done).map(t => t.wid))].forEach(w => {
    const r = autoReplanWork(w);
    moved += r.moved;
    if (r.short > 0) autoShort.push(`「${r.name}」截止日前還差 ${hrsTxt(r.short)} 小時`);
  });
  // 1. 之前的日子沒做完 → 排到今天以後有空的日子
  const overdue = S.tasks.filter(t => isOverdue(t) && !t.wid);
  if (overdue.length) {
    const r = plan(overdue, t0);
    overdue.forEach(t => reschedule(t, r[t.id]));
    moved += overdue.length;
  }
  // 2. 今天的時段已經過了還沒做完 → 往後排；今天排不下就移到之後
  const passed = S.tasks.filter(t => t.date === t0 && !t.done && !isEvent(t) && !t.locked && !t.wid && t.start != null && t.start + t.min <= now);
  if (passed.length) {
    passed.forEach(t => { habitLearnTask(t, t.start + t.min / 2, -0.7); t.start = null; });
    arrangeTimes(t0, "fill");
    const still = passed.filter(t => t.start == null);
    if (still.length) {
      const r = plan(still, addDays(t0, 1));
      still.forEach(t => reschedule(t, r[t.id]));
    }
    moved += passed.length;
  }
  if (moved) { undoSnap = before; save(); }
  return moved;
}

/* ---------- 內建規則：不用 AI 就看懂待辦句子 ---------- */
const CN_DIGIT = { "零": 0, "〇": 0, "一": 1, "二": 2, "兩": 2, "两": 2, "三": 3, "四": 4, "五": 5, "六": 6, "七": 7, "八": 8, "九": 9 };
function cnNum(str) {
  if (str == null || str === "") return NaN;
  str = String(str).replace(/[０-９]/g, c => String.fromCharCode(c.charCodeAt(0) - 0xFEE0));
  if (/^\d+(\.\d+)?$/.test(str)) return +str;
  if (str.includes("十")) {
    const [a, b] = str.split("十");
    return (a ? (CN_DIGIT[a] ?? NaN) : 1) * 10 + (b ? (CN_DIGIT[b] ?? NaN) : 0);
  }
  return str.length === 1 ? (CN_DIGIT[str] ?? NaN) : NaN;
}
const N = "[0-9０-９零〇一二兩两三四五六七八九十]+";
const WD_MAP = { "一": 1, "二": 2, "三": 3, "四": 4, "五": 5, "六": 6, "日": 0, "天": 0, "1": 1, "2": 2, "3": 3, "4": 4, "5": 5, "6": 6, "7": 0 };
const WK = "(?:週|周|星期|禮拜|礼拜|個禮拜|个礼拜)";

/* 私人活動 → 「其他」，不當固定事件 */
const OTHER_RE = /約會|聚餐|聚會|朋友|家人|爸媽|爸爸|媽媽|男友|女友|另一半|看電影|電影|逛街|唱歌|ktv|旅遊|出遊|旅行|露營|玩|生日|派對|婚禮|喜酒|演唱會|展覽|音樂會|夜市|追劇|打電動|遊戲/i;
/* 有固定時間、要準時出席的事 */
const EVENT_RE = /會議|開會|組會|大咪|小咪|meeting|seminar|workshop|研討會|工作坊|講座|演講|上課|課|補習|家教|助教課|實習|面試|面談|口試|答辯|考試|期中考|期末考|小考|看醫生|看診|門診|回診|牙醫|復健|健檢|打疫苗|抽血|簽約|面交|說明會|典禮|集合/i;
const CAT_RULES = [
  { name: "其他", re: OTHER_RE },
  { name: "學習", re: /(?:教授|老師|指導教授|學長|學姐|學弟|學妹|同學).{0,4}(?:開會|meeting|討論)|專題|書報|期末報告|期中報告|交.{0,4}報告/i },
  { name: "工作", re: /家教|改考卷|履歷|合約|報價|帳目|系辦|所辦|廠商|耗材|器材/ },
  { name: "學習", re: /課|作業|讀|書|論文|paper|報告|考|複習|預習|研究|實驗|量測|數據|分析|模擬|hw|期中|期末|講義|單字|筆記|投影片|簡報|程式|code|coding|leetcode|刷題|練習|閱讀|讀書會|助教|批改|教授|老師|指導|meeting with|托福|多益|雅思|英文|日文/i },
  { name: "生活", re: /買|採買|超市|全聯|家樂福|好市多|洗|曬衣|收衣|摺衣|打掃|掃地|拖地|倒垃圾|資源回收|煮|做飯|備餐|運動|跑步|健身|瑜珈|游泳|騎車|散步|醫|牙|剪頭|理髮|寄|領|繳|房租|水電|電話費|修|保養|加油|洗車|換床單|整理房|搬家|看醫生|吃藥|睡覺|午睡|洗澡/ },
  { name: "工作", re: /會議|開會|組會|email|信|回覆|回信|工作|專案|客戶|進度|老闆|主管|報帳|請款|核銷|申請|表單|行政|文件|合約|出差|簽約|打電話|電話/i }
];
/* 沒寫多久時，依事情估計（分鐘） */
const DUR_RULES = [
  [/^交|交.{0,8}作業|交.{0,4}(資料|單)/, 30],
  [/旅遊|出遊|旅行|露營|搬家|出去玩|[墾丁花蓮宜蘭台中台南日本].{0,2}玩|一日遊/, 480],
  [/準備.{0,8}(考|口試)|考.{0,8}準備|期末報告|國科會|計畫書|打工|上班|值班|演唱會|回老家/, 240],
  [/論文第.章|寫.{0,6}(報告|proposal|論文)|改.{0,4}論文|報告|proposal|做.{0,6}實驗|實驗做|逛街|看展|唱歌|ktv|上課|(?<![早晚線馬網])上(?![網午班])\S{2,5}$/i, 180],
  [/作業|習題|hw|看電影|電影|讀.{1,6}(和|跟).{1,6}/i, 150],
  [/^(?!.*讀完).*(?:讀|看).{0,4}(論文|paper)|整理.{0,10}數據|數據整理|分析|模擬|程式|matlab|python|code|改考卷|投影片|簡報|大咪|助教課|家教|健檢|聚餐|吃飯|約會|吃.{0,3}(燒肉|火鍋|飯)|口試|考試|期中考|期末考|跟.{1,4}(玩|出去)/i, 120],
  [/讀|念|唸|複習|預習|看.{0,6}講義|校正|組會|專題會議|書報|讀書會|研討會|講座|演講|說明會|看小說|紀錄片|運動(?=.*晚)|打.{0,1}(球|籃球|羽球)|午餐|吃午/, 90],
  [/打掃|整理(房間|實驗室|書櫃|照片)|運動|健身|游泳|瑜珈|看醫生|看診|門診|牙醫|回診|皮膚科|眼科|剪頭|理髮|檢查|開會|meeting|討論|面談|面試|線上會議|會議|帳目|買.{0,6}禮物|搬.{0,4}器材/i, 60],
  [/買菜|全聯|超市|家樂福|好市多|核銷|報帳|會議記錄|週報|月報|跑步|散步|整理(?!.{0,6}數據)/, 45],
  [/背單字|單字|摺衣|洗衣服|寄包裹|郵局|銀行|交.{0,8}(作業|報告|資料|單)|上網買|網購|耗材|寄履歷|履歷|打電話|視訊|確認|寄合約|合約|藥局/, 30],
  [/回.{0,8}(信|email|mail|訊息|line)|回覆|寄信|預約|填.{0,4}表|繳.{0,2}學費|買.{0,6}(跟|和)|買\S{2,4}藥/i, 20],
  [/倒垃圾|資源回收|曬衣|收衣|吃藥|繳|領|取貨|訂.{0,3}(票|位|餐廳)|訂位|簽名|洗碗|寫日記|報價|買/, 15]
];
/* 只說時段沒說幾點（越前面越優先） */
const VAGUE_TIMES = [
  [/起床後|起床/, 450], [/早餐前/, 420], [/一早|清晨/, 480], [/早上|今早|明早|早晨/, 540], [/上午/, 600],
  [/午餐後|午飯後/, 780], [/午休/, 750], [/中午/, 720], [/下午茶/, 900], [/放學後|放學/, 1020], [/下午/, 840],
  [/下班後|下班/, 1110], [/傍晚/, 1050], [/晚餐後|晚飯後|吃完晚餐/, 1170],
  [/睡前|睡覺前/, 1350], [/深夜|半夜/, 1380], [/晚上|今晚|明晚|夜裡|晚間/, 1140]
];
const VAGUE_WORDS = /起床後|起床|早餐前|一早|清晨|早上|今早|明早|早晨|上午|午餐後|午飯後|午休|中午|下午茶|放學後|放學|下午|下班後|下班|傍晚|晚餐後|晚飯後|吃完晚餐|睡前|睡覺前|深夜|半夜|晚上|今晚|明晚|夜裡|晚間/g;
const PLACE_RE = /(?:在|去|到|於|回)\s*(學校|公司|辦公室|實驗室|研究室|系館|系辦|圖書館|醫院|診所|家裡|老家|家|咖啡廳|星巴克|健身房|超市|全聯|家樂福|好市多|郵局|銀行|便利商店|7-11|小七|全家|夜市|捷運站|車站|高鐵站|機場|[一-龥A-Za-z]{1,6}(?:大學|教室|館|廳|店|室|站|樓|中心|公園))/;

function weekdayDate(target, mode) {
  const t0 = today(), d0 = parse(t0).getDay();
  const mon = addDays(t0, -((d0 + 6) % 7));
  const off = (target + 6) % 7;
  if (mode === "this") return addDays(mon, off);
  if (mode === "nextweek") return addDays(mon, 7 + off);
  if (mode === "next2") return addDays(mon, 14 + off);
  let k = t0;
  for (let i = 0; i < 7; i++) { if (parse(k).getDay() === target) return k; k = addDays(k, 1); }
  return t0;
}
function monthDay(monthOffset, day) {
  const d = parse(today());
  const last = new Date(d.getFullYear(), d.getMonth() + monthOffset + 1, 0).getDate();
  return key(new Date(d.getFullYear(), d.getMonth() + monthOffset, Math.min(day, last)));
}

function parseLine(raw) {
  raw = raw.replace(/[０-９]/g, c => String.fromCharCode(c.charCodeAt(0) - 0xFEE0)).replace(/：/g, ":").trim();
  let s = raw;
  if (!s) return null;
  let date = null, deadline = null, time = null, min = null, pri = 1, endTime = null, repeat = null, notes = [];

  // ---- 重複（每天、每週三、每月5號、平日…） ----
  const wdList = str => [...new Set(str.split("").map(c => WD_MAP[c]).filter(x => x != null))];
  const repRules = [
    [new RegExp(`每隔\\s*(${N})\\s*天|每\\s*(${N})\\s*天`), m => ({ freq: "daily", interval: Math.max(2, cnNum(m[1] || m[2]) || 2) })],
    [/每天|每日|天天|每晚|每早/, () => ({ freq: "daily", interval: 1 })],
    [new RegExp(`平日|工作日|${WK}一到${WK}?五`), () => ({ freq: "weekly", interval: 1, weekdays: [1, 2, 3, 4, 5] })],
    [new RegExp(`每個?${WK}末|每${WK}六日|每個?週末`), () => ({ freq: "weekly", interval: 1, weekdays: [6, 0] })],
    [new RegExp(`(?:每兩|每2|隔)${WK}([一二三四五六日天](?:[、,和跟及與]?[一二三四五六日天])*)?`), m => ({ freq: "weekly", interval: 2, weekdays: m[1] ? wdList(m[1]) : [] })],
    [new RegExp(`每個?${WK}([一二三四五六日天](?:[、,和跟及與]?[一二三四五六日天])*)`), m => ({ freq: "weekly", interval: 1, weekdays: wdList(m[1]) })],
    [new RegExp(`每個?${WK}`), () => ({ freq: "weekly", interval: 1, weekdays: [] })],
    [new RegExp(`每個?月\\s*(${N})\\s*[號号日]`), m => ({ freq: "monthly", interval: 1, day: cnNum(m[1]) })],
    [/每個?月/, () => ({ freq: "monthly", interval: 1 })]
  ];
  for (const [re, fn] of repRules) {
    const m = s.match(re);
    if (m) { repeat = fn(m); s = s.replace(m[0], " "); break; }
  }

  // ---- 地點 → 備註 ----
  const pm = s.match(PLACE_RE);
  let placeText = "";
  if (pm) { notes.push(`地點：${pm[1]}`); placeText = pm[0].trim(); s = s.replace(pm[0], " "); }

  // ---- 日期 ----
  const isDue = after => /^\s*(之前|以前|前|截止|到期|就截止|的)/.test(after);
  const dateRules = [
    [new RegExp(`(${N})\\s*${WK}後|(${N})\\s*週後`), m => addDays(today(), 7 * cnNum(m[1] || m[2]))],
    [new RegExp(`(?:過\\s*)?(${N})\\s*天(?:後|后|以後)`), m => addDays(today(), cnNum(m[1]))],
    [/過兩天|過2天/, () => addDays(today(), 2)],
    [/過幾天|這幾天|改天/, () => addDays(today(), 3)],
    [new RegExp(`下個?月\\s*(${N})\\s*[號号日]`), m => monthDay(1, cnNum(m[1]))],
    [/下個?月初/, () => monthDay(1, 1)],
    [/下個?月底/, () => monthDay(2, 0)],
    [/下個?月/, () => monthDay(1, 1)],
    [/(這個?月|本月)?月底/, () => monthDay(1, 0)],
    [/月初/, () => { const k = monthDay(0, 1); return k >= today() ? k : monthDay(1, 1); }],
    [/大後天|大后天/, () => addDays(today(), 3)],
    [/後天|后天/, () => addDays(today(), 2)],
    [/明天|明日|明早|明晚|明兒/, () => addDays(today(), 1)],
    [/今天|今日|今晚|今早|今兒|等等|等一下|待會/, () => today()],
    [new RegExp(`下下${WK}([一二三四五六日天1-7])`), m => weekdayDate(WD_MAP[m[1]], "next2")],
    [new RegExp(`下${WK}([一二三四五六日天1-7])`), m => weekdayDate(WD_MAP[m[1]], "nextweek")],
    [new RegExp(`(?:這|这|本)${WK}([一二三四五六日天1-7])`), m => weekdayDate(WD_MAP[m[1]], "this")],
    [new RegExp(`${WK}([一二三四五六日天1-7])`), m => weekdayDate(WD_MAP[m[1]], "next")],
    [new RegExp(`下${WK}末|下個?週末`), () => weekdayDate(6, "nextweek")],
    [/(這|这)?(週末|周末)/, () => weekdayDate(6, "next")],
    [new RegExp(`下${WK}`), () => weekdayDate(1, "nextweek")],
    [new RegExp(`(${N})\\s*[月/]\\s*(${N})\\s*[日號号]?`), m => {
      const mo = cnNum(m[1]), da = cnNum(m[2]);
      if (!(mo >= 1 && mo <= 12 && da >= 1 && da <= 31)) return null;
      const y = parse(today()).getFullYear();
      let k = key(new Date(y, mo - 1, da));
      if (diff(k, today()) > 60) k = key(new Date(y + 1, mo - 1, da));
      return k;
    }],
    [new RegExp(`(?<![月/\\d])(${N})\\s*[號号](?!碼)`), m => { const d = cnNum(m[1]); if (!(d >= 1 && d <= 31)) return null; const k = monthDay(0, d); return k >= today() ? k : monthDay(1, d); }]
  ];
  for (const [re, fn] of dateRules) {
    const m = s.match(re);
    if (!m) continue;
    const k = fn(m);
    if (!k) continue;
    const after = s.slice(m.index + m[0].length);
    s = s.slice(0, m.index) + " " + after.replace(/^\s*(之前|以前|前|截止|到期|就截止了?|的)/, " ");
    if (isDue(after) || /截止|due|期限|deadline/i.test(raw)) deadline = k; else date = k;
    break;
  }

  // ---- 時間（含「2點到4點」） ----
  const period = "(早上|上午|中午|下午|晚上|傍晚|凌晨|半夜|早|晚)?";
  const tRe = new RegExp(`${period}\\s*(${N})\\s*(?:[點点時]\\s*(半|整|${N})?\\s*分?|:(\\d{2}))`);
  const evening = /今晚|明晚|晚上|傍晚|晚餐|下班|夜/.test(raw), morning = /今早|明早|早上|上午|起床|早餐/.test(raw);
  const toMinutes = (per, hStr, mStr, colonMin) => {
    let h = cnNum(hStr); if (isNaN(h) || h > 24) return null;
    let m = colonMin != null ? +colonMin : mStr === "半" ? 30 : (mStr && mStr !== "整") ? cnNum(mStr) : 0;
    if (isNaN(m) || m > 59) m = 0;
    if (/下午|晚上|傍晚|晚/.test(per || "") && h < 12) h += 12;
    else if (/中午/.test(per || "") && h < 11) h += 12;
    else if (!per && evening && h < 12) h += 12;
    else if (!per && !morning && colonMin == null && h >= 1 && h <= 6) h += 12;
    return Math.min(h * 60 + m, 23 * 60 + 55);
  };
  const t1 = s.match(tRe);
  if (t1) {
    time = toMinutes(t1[1], t1[2], t1[3], t1[4]);
    s = s.replace(t1[0], " ");
    const r2 = s.match(new RegExp(`(到|至|-|~|～|—)\\s*${period}\\s*(${N})\\s*(?:[點点時]\\s*(半|整|${N})?\\s*分?|:(\\d{2}))`));
    if (r2 && time != null) {
      endTime = toMinutes(r2[2] || (t1[1] && /下午|晚上|傍晚|中午|晚/.test(t1[1]) ? "下午" : ""), r2[3], r2[4], r2[5]);
      if (endTime != null && endTime <= time) endTime += 12 * 60;
      s = s.replace(r2[0], " ");
    }
  }
  let vague = false;
  if (time == null) {
    const v = VAGUE_TIMES.find(([re]) => re.test(raw));
    if (v) { time = v[1]; vague = true; }
  }
  s = s.replace(VAGUE_WORDS, " ");

  // ---- 需要多久 ----
  let m;
  if ((m = s.match(new RegExp(`(${N}|\\d+\\.\\d+)?\\s*個?\\s*(半)?\\s*(小時|鐘頭|钟头|hrs?|hours?|h)(?![a-z])`, "i")))) {
    const n = m[1] ? cnNum(m[1]) : 0;
    min = Math.round(((isNaN(n) ? 0 : n) + (m[2] ? 0.5 : 0)) * 60); s = s.replace(m[0], " ");
  }
  if ((m = s.match(new RegExp(`(${N})\\s*(分鐘|分钟|min|mins|minutes)`, "i")))) { min = (min || 0) + cnNum(m[1]); s = s.replace(m[0], " "); }
  const durWords = [[/一整天|整天|全天/, 480], [/半天/, 240], [/一個下午|整個下午/, 240], [/一個上午|整個上午|一個早上/, 180], [/一個晚上|整個晚上|整晚/, 180], [/一下下|一下子|幾分鐘|快速|順手/, 15]];
  if (!min) for (const [re, v] of durWords) { if (re.test(s)) { min = v; s = s.replace(re, " "); break; } }
  if (!min && endTime != null && time != null) min = endTime - time;
  const minGiven = !!min, dateGiven = !!date;

  // ---- 優先順序 ----
  if (/緊急|很急|超急|急件|急|asap|馬上|立刻|今天一定|火燒|來不及|超重要|非常重要|就截止|快截止|要截止/i.test(raw)) pri = 3;
  else if (/重要|優先|必須|一定要|務必|考試|期中考|期末考|口試|趕快|趕緊|快(?=[寫做讀交弄完])/i.test(raw)) pri = 2;
  else if (/有空|順便|隨便|不急|有時間|改天|再說|可做可不做|行有餘力|之後再/.test(raw)) pri = 0;
  // 快到期（4 天內）→ 至少「高」；今天就到期 → 「緊急」
  if (deadline && diff(today(), deadline) <= 0) pri = 3;
  else if (deadline && diff(today(), deadline) <= 4 && pri < 2) pri = 2;
  const priGiven = pri !== 1;

  // ---- 標題：只留重點 ----
  let title = s
    .replace(/…+|\.{2,}|⋯+/g, " ")
    .replace(/欸對了|欸對|對了|欸|誒|那個|這個|就是說|就是|我想說|想說|好像|大概|反正|總之|不然會忘記|不然|其實|感覺|之類的|什麼的|要記得|不要忘記|別忘了|拜託|幫我記一下|記一下|我必須|盡量|看能不能|稍微|有點|有空的話|比較好|就好|弄一弄|處理一下|給它|這件事|那件事|的事情|的事(?=\s|$)|好了(?=\s|$)|這樣(?=\s|$)|一下下|快到了|還沒/g, " ")
    .replace(/^[\s:：,，、]+/, "")
    .replace(/就截止了?|快截止了?|要截止了?|截止了/g, " ")
    .replace(/緊急|很急|超急|急件|asap|馬上|立刻|火燒|來不及|超重要|非常重要|很重要|重要|優先|必須|一定要|務必|有空再|有空|順便|不急|有時間再|有時間|再說|可做可不做|行有餘力/gi, " ")
    .replace(/大約|約(?=\s*[0-9一二兩三四五六七八九十半])|左右|需要|要花|預計|估計|的時候|截止|期限|之前|以前|deadline/gi, " ")
    .replace(/(^|\s)(嗯+|呃+|啊+|喔+|哦+|耶|欸|啦|吧|呢|嘛)(?=\s|$)/g, " ")
    .replace(/記得|提醒我|提醒|幫我|我們|我要|我得|我想|我|要去|想要|應該|可能|得要|一下|然後|還有|趕快|趕緊|一起|順手|開始/g, " ")
    .replace(/[，,。；;！!？?～~、()（）「」\s]+/g, " ")
    .replace(/(^|\s)(要|得|去|來|很|的|跟|和|把|先|再|也|就|會|在|到|該)(?=\s|$)/g, " ")
    .replace(/^\s*(?:(?:要|去|來|先|再|把|該|晚點|等等|等一下)\s*)+/, "")
    .replace(/(了|啦|喔|哦|吧|呢|嘛|哈|囉|唷|要|一下)\s*$/, "")
    .replace(/(了|啦|喔|哦|吧|呢|嘛|哈|囉|唷|要)\s*$/, "")
    .replace(/\s+/g, " ")
    .trim();
  title = title.replace(/([\u4e00-\u9fff])\s+(?=[\u4e00-\u9fff])/g, "$1")
    .replace(/^[\s:：,，、了]+/, "").replace(/^快(?=[寫做讀交弄完改])/, "").replace(/([買吃看喝寫讀])個(?=[\u4e00-\u9fff])/g, "$1")
    .replace(/那(?:家|個|篇|部|份|些|位)/g, "").trim();
  // 只剩人名（「跟爸媽」）或什麼都沒剩：把地點的說法放回來（「跟爸媽回老家」「去銀行」）
  if (placeText && (!title || (/^(?:跟|和|陪)/.test(title) && !title.slice(1).replace(PERSON_RE, "")))) title = (title + placeText.replace(/^(?:在|於)/, "")).trim();
  if (!title) title = raw.replace(/[，,。]/g, " ").trim();

  // ---- 分類、固定事件、預估時間 ----
  // 有明確時間、而且是要出席的事（上課、開會…，或寫了「幾點到幾點」）→ 固定事件
  const isEv = !!(time != null && !vague && !OTHER_RE.test(raw) && (EVENT_RE.test(raw) || endTime != null || /^上\S/.test(title)));
  let durRule = false;
  if (!min) { const r = DUR_RULES.find(([re]) => re.test(raw)); min = r ? r[1] : 30; durRule = !!r; }
  min = Math.min(480, Math.max(10, Math.round(min / 5) * 5));
  let catName = null;
  const direct = S.cats.find(c => !c.event && raw.includes(c.name));
  if (direct) catName = direct.name;
  else { const r = CAT_RULES.find(c => c.re.test(raw)); if (r) catName = r.name; else if (/^上\S/.test(title)) catName = "學習"; }

  // 重複：決定第一次是哪天
  if (repeat) {
    if (repeat.freq === "weekly" && repeat.weekdays && repeat.weekdays.length && !date) {
      const cands = repeat.weekdays.map(w => weekdayDate(w, "next")).sort();
      date = cands[0];
    } else if (repeat.freq === "monthly" && repeat.day && !date) {
      const k = monthDay(0, repeat.day); date = k >= today() ? k : monthDay(1, repeat.day);
    }
    if (!date) date = time != null && time <= nowMin() ? addDays(today(), 1) : today();
    delete repeat.day;
  }
  return {
    title: title.slice(0, 40), notes: notes.join("\n"), minutes: min, priority: pri, category: catName, isEvent: isEv,
    date: date || null,
    time: time != null ? hm(time) : null, deadline, repeat, dateGiven, minGiven, durRule, vague, priGiven
  };
}
/* ---------- 日期區間：「11/1到11/7」「這週」「未來5天」… ---------- */
const RANGE_SIDE = `(?:(?:${N})\\s*[月/]\\s*(?:${N})\\s*[日號号]?|(?:${N})\\s*[日號号]|今天|明天|後天|(?:這|这|本|下)?${WK}[一二三四五六日天1-7]|月底)`;
const endOfWeek = k => addDays(k, (7 - parse(k).getDay()) % 7);   // 這週日
function sideDate(str) {
  const r = parseLine(str);
  return r ? (r.date || r.deadline) : null;
}
/** 找出一句話裡的日期區間，回傳 { start, end, text } */
function detectRange(line) {
  const str = line.replace(/[０-９]/g, c => String.fromCharCode(c.charCodeAt(0) - 0xFEE0));
  const t0 = today();
  const ok = (a, b, text) => (a && b && b >= a && diff(a, b) <= 180) ? { start: a, end: b, text } : null;
  let m = str.match(new RegExp(`(?:從|自)?\\s*(${RANGE_SIDE})\\s*(?:到|至|~|～|-|—|–)\\s*(${RANGE_SIDE})\\s*(?:之間|期間|這段時間|以內|內|為止)?`));
  if (m) {
    const a = sideDate(m[1]);
    let b = sideDate(m[2]);
    // 「11/1到7號」：右邊只寫幾號，就跟左邊同一個月
    const onlyDay = m[2].match(new RegExp(`^(${N})\\s*[日號号]$`));
    if (a && onlyDay) {
      const d = parse(a), n = cnNum(onlyDay[1]);
      b = key(new Date(d.getFullYear(), d.getMonth(), n));
      if (b < a) b = key(new Date(d.getFullYear(), d.getMonth() + 1, n));
    }
    if (a && b && b < a) b = key(new Date(parse(b).getFullYear() + 1, parse(b).getMonth(), parse(b).getDate()));
    const r = ok(a, b, m[0]); if (r) return r;
  }
  const rules = [
    [/今明[兩二2]天(?:內|之內|以內)?|今明天|今天(?:跟|和|或|、)?明天(?:內|之內|以內)?|今明(?=[要把做寫讀完弄處準])/, () => [t0, addDays(t0, 1)]],
    [/明後[兩二2]天(?:內|之內|以內)?|明後天|明天(?:跟|和|或|、)?後天/, () => [addDays(t0, 1), addDays(t0, 2)]],
    [/(?:這|最近|未來|接下來)(?:兩三|幾)天(?:內|之內|以內)?/, () => [t0, addDays(t0, 2)]],
    [new RegExp(`(?:未來|接下來|之後|這|近|最近)\\s*(${N})\\s*(?:天|日)(?:內|之內|以內)?`), m => [t0, addDays(t0, cnNum(m[1]) - 1)]],
    [new RegExp(`(?:未來|接下來|之後|這|近|最近)\\s*(${N})\\s*(?:個)?(?:週|周|星期|禮拜|礼拜)(?:內|之內|以內)?`), m => [t0, addDays(t0, 7 * cnNum(m[1]) - 1)]],
    // 「這週末」「週末」→ 這週六～週日；「下週末」→ 下週六～週日（「每個週末」是重複，不算）
    [new RegExp(`(?<!每個?)(?:下個?)(?:${WK}末|週末|周末)`), () => { const a = weekdayDate(6, "nextweek"); return [a, addDays(a, 1)]; }],
    [new RegExp(`(?<!每個?|下個?)(?:(?:這|这|本)個?)?(?:${WK}末|週末|周末)`), () => { const a = parse(t0).getDay() === 0 ? t0 : weekdayDate(6, "this"); return [maxKey(a, t0), endOfWeek(t0)]; }],
    [new RegExp(`(?:這|这|本)個?${WK}(?![一二三四五六日天1-7末])(?:內|之內|以內)?`), () => [t0, endOfWeek(t0)]],
    [new RegExp(`下個?${WK}(?![一二三四五六日天1-7末])(?:內|之內|以內)?`), () => { const a = weekdayDate(1, "nextweek"); return [a, addDays(a, 6)]; }],
    [new RegExp(`(?:這|这|本)個?月(?!\\s*(?:${N}|底|初))(?:內|之內|以內)?`), () => [t0, monthDay(1, 0)]],
    [new RegExp(`下個?月(?!\\s*(?:${N}|底|初))(?:內|之內|以內)?`), () => [monthDay(1, 1), monthDay(2, 0)]]
  ];
  for (const [re, fn] of rules) {
    const mm = str.match(re);
    if (mm) { const [a, b] = fn(mm); const r = ok(a, b, mm[0]); if (r) return r; }
  }
  return null;
}
/* ---------- 一句話裡有好幾件事：「跟、和、還有、然後…」前後是不同的事 ---------- */
const SPLIT_SEQ = /\s*[，,]?\s*(?:然後再|然後|還有|另外|再來|接著|之後再|以及|並且|順便再|順便)\s*/g;
const SPLIT_CONJ = /跟|和|與|及|還要|再/g;
/* 「跟」後面是人 → 是「跟誰一起」，不是另一件事 */
const PERSON_RE = /^(?:我的|他的|她的)?(?:指導教授|教授|老師|學長|學姐|學弟|學妹|同學|組員|隊友|朋友|男友|女友|男朋友|女朋友|另一半|老公|老婆|家人|爸媽|爸爸|媽媽|爸|媽|哥哥|姊姊|姐姐|弟弟|妹妹|阿嬤|阿公|室友|閨蜜|老闆|主管|同事|客戶|廠商|助教|醫生|大家|他們|她們|他|她|你|妳|系辦|所辦|實驗室|高中同學|大學同學|[一-龥]{1,3}(?:學長|學姐|學弟|學妹|老師|教授|同學|醫師)|[A-Za-z][A-Za-z ]{0,15}(?=[一-龥]))/;
/* 看起來像在做一件事（開頭是動作） */
const VERB_RE = /^(?:要|去|再|也|還|先|順便|記得|得)?\s*(?:買|寫|讀|唸|念|看|做|交|洗|倒|打|整理|準備|複習|預習|回|寄|跑|上|開|聯絡|練|背|煮|掃|拖|繳|領|印|改|算|吃|約|訂|修|剪|搬|收|曬|晾|摺|餵|澆|查|找|弄|處理|檢查|量|測|畫|debug|跑|K|讀完|寫完|做完|去|到|參加|報名|申請|填|簽|核銷|報帳|拿|送|接|載|陪|運動|健身|游泳|散步|睡|洗澡|充電|補|追|玩|逛|唱|喝|吹|擦|丟|換|裝|拆|架|組|焊|校正|分析|整|規劃|安排|排|思考|想|討論|開會|報告|練習|背|聽|錄|拍|剪輯|上傳|下載|下單|退|取|提款|匯款|轉帳)/i;
/* 動作開頭但其實是東西的名字（買衛生紙跟洗衣精 → 同一件事） */
const NOUNISH_RE = /^(?:洗衣精|洗衣粉|洗髮精|洗碗精|洗面乳|洗手乳|打火機|讀書會|看板|寫字板|上衣|開關|印表機|充電器|充電線|修正帶|收據|換洗衣物|吃的|喝的)/;
function splitTasks(str) {
  const out = [];
  for (const seg of str.split(/；|;|、(?![一二三四五六日天])/).flatMap(x => x.split(SPLIT_SEQ)).map(x => x.trim()).filter(Boolean)) {
    // 在「跟／和／與／及／還要／再」的地方，右邊是一個新的動作、而且不是「跟某人」，才拆開
    let start = 0, m;
    SPLIT_CONJ.lastIndex = 0;
    const cuts = [];
    while ((m = SPLIT_CONJ.exec(seg))) {
      const left = seg.slice(start, m.index).replace(/^[\s，,]+/, ""), right = seg.slice(m.index + m[0].length).replace(/^[\s，,]+/, "");
      if (!left || left.length < 2 || !right) continue;
      if (m[0] === "再" && !/[，,\s]$/.test(seg.slice(0, m.index)) && !/[了完後]$|[完好]\S{1,8}$/.test(left)) continue;   // 「再」只有在「…完再…」「…，再…」才當成下一件事
      if (/(?:跟|和|與|及)$/.test(m[0]) && PERSON_RE.test(right)) continue;
      if (NOUNISH_RE.test(right.replace(/^(?:要|去|再|也|還|先)/, ""))) continue;
      // 右邊開頭的日期、時間先拿掉再看是不是動作（「開會和三點看牙醫」）
      const core = right.replace(new RegExp(`^(?:(?:今天|明天|後天|今晚|明早|明晚|(?:這|下)?${WK}[一二三四五六日天]|早上|上午|中午|下午|晚上|傍晚)\\s*)*(?:${N}\\s*[點点:：]\\s*(?:半|${N})?\\s*分?)?\\s*(?:到|至|-|~)?\\s*(?:${N}\\s*[點点:：]\\s*(?:半|${N})?\\s*分?)?`), "");
      if (!VERB_RE.test(core)) continue;
      cuts.push([m.index, m.index + m[0].length]);
      start = m.index + m[0].length;
    }
    let last = 0;
    for (const [a, b] of cuts) { out.push(seg.slice(last, a).trim()); last = b; }
    out.push(seg.slice(last).trim());
  }
  return out.filter(x => x && x.replace(/[\s，,。]/g, "").length > 0);
}
/* 可以拆成好幾份的工作：讀完5章、寫3篇… */
const PART_RE = new RegExp(`(${N})\\s*個?\\s*(章|篇|回|份|單元|節|課|集|部分|段|個主題|題|頁)`);
const RANGE_FILLER = /[：:，,。.!！\s]|要做的事|要做|要完成|完成|的事情|的事|事情|有這些|有|之間|期間|這段時間|我|待辦|清單|計畫|計劃|安排|以下|這些|如下|幫我|排|一下|內|以內|之內|為止|要/g;
/** 回傳跟 AI 一樣格式的資料，交給同一套排程 */
function localParse(text) {
  const out = [];
  let hdr = null;
  for (const line of String(text).split(/\n/)) {
    if (!line.trim()) { hdr = null; continue; }
    const rg = detectRange(line);
    const rest = rg ? line.replace(rg.text, " ") : line;
    // 只有日期區間的一行（例如「11/1到11/7要做：」）→ 套用到下面每一行
    if (rg && !rest.replace(RANGE_FILLER, "").trim()) { hdr = rg; continue; }
    const win = rg || hdr;
    const pieces = splitTasks(rest);
    let ctx = null;      // 同一句裡前面講過的日期、截止日，後面的事情沿用（「明天開會跟寫報告」→ 兩件都是明天）
    // 「順便」「有空再」「很急」這種話說在整句：拆開後每一項都適用
    const linePri = /緊急|很急|超急|急件|asap|馬上|立刻/i.test(rest) ? 3 : /有空|順便|不急|有時間再|之後再/.test(rest) ? 0 : null;
    for (const piece of pieces) {
      const p = parseLine(piece);
      if (!p) continue;
      if (linePri != null && !p.priGiven) { p.priority = linePri; p.priGiven = true; }
      if (ctx) {
        if (!p.dateGiven && ctx.date && !p.repeat) { p.date = ctx.date; p.dateGiven = true; }
        if (!p.deadline && ctx.deadline) p.deadline = ctx.deadline;
      }
      if (p.dateGiven || p.deadline) ctx = { date: p.dateGiven ? p.date : (ctx && ctx.date), deadline: p.deadline || (ctx && ctx.deadline) };
      brainRefine(p);            // AI 小模型：修正分類、要多久、固定事件
      // 重複的事 + 區間：「11/3到11/7 每天背單字」→ 從 11/3 重複到 11/7
      if (win && p.repeat && !p.dateGiven) {
        const a = maxKey(win.start, today());
        if (p.repeat.freq === "weekly" && p.repeat.weekdays && p.repeat.weekdays.length) {
          let d = a; for (let i = 0; i < 7 && !p.repeat.weekdays.includes(parse(d).getDay()); i++) d = addDays(d, 1);
          p.date = d;
        } else p.date = a;
        p.repeat.until = win.end;
      }
      if (win && !p.repeat && !p.dateGiven) {
        p.date = null;
        p.rangeStart = win.start; p.rangeEnd = win.end;
        if (!p.deadline || p.deadline > win.end) p.deadline = win.end;
        const pm = p.title.match(PART_RE);
        if (pm) {
          const n = cnNum(pm[1]), small = /題|頁/.test(pm[2]);
          if (n >= 2 && n <= (small ? 10 : 30)) {
            p.parts = n;
            p.minutes = p.minGiven ? Math.max(15, Math.round(p.minutes / n / 5) * 5) : Math.min(p.minutes, 90);
          }
        }
      }
      delete p.dateGiven;
      out.push(p);
    }
  }
  return { tasks: out };
}

/* ---------- AI 小模型：在你的手機上訓練，看懂待辦是哪一類、要多久、是不是固定事件 ----------
 * 架構（跟 fastText 一樣的概念）：
 *   句子 → 字、兩個字的組合、英文單字 → 每個都對到一個 32 維向量 → 平均 → 三個輸出
 *   ① 分類（工作／學習／生活／其他…）② 是不是要準時出席的固定事件 ③ 大概要幾分鐘
 * 訓練資料 = 內建的上千句常見待辦 + 你自己的工作 + 你在預覽／編輯時改過的地方（權重最高）。
 * 另外有一個「個人記憶」：跟你以前改過的句子很像時，直接照你上次的改法。
 */
const BRAIN_SEED = [
  // [分類, 固定事件?, 分鐘, 說法（| 分隔；{S}=科目、{P}=對象）]
  ["學習", 1, 60, "跟{A}開會|跟{A}meeting|專題會議|專題討論|跟{A}討論實驗"],
  ["工作", 1, 120, "家教|上家教|當家教"],
  ["工作", 0, 120, "改考卷|當助教改考卷|批改作業"],
  ["學習", 0, 90, "讀{S}|念{S}|複習{S}|預習{S}|看{S}講義|讀{S}課本|整理{S}筆記|寫{S}筆記|讀{S}第三章|讀完{S}|K{S}|唸書|讀書|自習|去圖書館讀書"],
  ["學習", 0, 150, "寫{S}作業|做{S}作業|{S}作業|寫{S}習題|算{S}習題|{S} HW|做{S} homework|寫作業|趕作業|交作業前檢查|寫{S}考古題|刷{S}考古題"],
  ["學習", 0, 180, "寫{S}報告|做{S}報告|準備{S}報告|{S}期末報告|{S}期中報告|做{S}簡報|做投影片|準備投影片|寫實驗報告|寫結報|寫預報|改報告"],
  ["學習", 0, 120, "讀論文|看paper|讀paper|整理文獻|寫論文|改論文|寫proposal|寫研究計畫|跑模擬|跑{S}模擬|分析數據|整理實驗數據|畫圖|做實驗|量測|架實驗|校正感測器|處理數據|寫程式|debug|改code|寫matlab|寫python|跑CFD"],
  ["學習", 0, 240, "準備{S}考試|準備{S}期中考|準備{S}期末考|{S}考試複習|複習期中考|準備考試|準備口試|準備資格考"],
  ["學習", 0, 30, "背單字|背英文單字|練英聽|看英文影片|多益練習|托福練習|日文練習|練口說"],
  ["學習", 1, 120, "上{S}|上{S}課|{S}上課|{S}課|上課|去上課|上{S}演習課|{S}實驗課|補習|上家教|助教課|當助教"],
  ["學習", 1, 180, "{S}期中考|{S}期末考|{S}考試|{S}小考|考{S}|期中考|期末考|小考|口試|資格考"],
  ["學習", 1, 90, "書報討論|專題演講|聽演講|seminar|研討會|workshop|講座|讀書會|跟{P}討論論文|meeting with {P}"],
  ["工作", 1, 60, "開會|開組會|組會|大咪|小咪|跟{B}開會|跟{B}meeting|跟{P}討論進度|跟{P}約討論|進度報告|週會|部門會議|專案會議|和客戶開會|面試|面談|線上會議|視訊會議"],
  ["工作", 0, 20, "回信|回email|回mail|回覆{P}的信|寄信給{P}|寫email給{P}|回訊息|回{P}訊息|打電話給{P}|聯絡{P}|約{P}時間|回{P}的email|回{P}email|寫信給{P}|回{P}的line"],
  ["工作", 0, 60, "報帳|核銷|請款|填表單|申請經費|寫申請書|整理收據|跑公文|簽文件|行政工作|整理會議記錄|寫會議記錄|更新進度表|整理專案資料|寫週報|寫月報|準備會議資料|訂設備|採購儀器|請廠商報價"],
  ["工作", 0, 120, "做{P}交代的事|處理專案|寫企劃|改企劃|做簡報給{P}|整理報告給{P}|做實驗室的事|幫{P}弄資料|打工|上班|值班"],
  ["生活", 0, 20, "倒垃圾|資源回收|收衣服|曬衣服|摺衣服|洗碗|澆花|餵貓|餵狗|鏟貓砂|吃藥|寄包裹|領包裹|去郵局|去銀行|繳費|繳電話費|繳房租|繳水電費|加油|領錢|買早餐|寄履歷|印資料|影印"],
  ["生活", 0, 40, "買菜|去全聯|去超市|去家樂福|去好市多|採買|買日用品|買衛生紙|買洗衣精|洗衣服|打掃房間|整理房間|掃地|拖地|洗澡|煮晚餐|做飯|煮飯|備餐|換床單|整理衣櫃|洗車|做家事|家事|整理家裡|整理書桌|洗廁所|晾衣服"],
  ["生活", 0, 60, "運動|跑步|去健身房|重訓|游泳|打球|打羽球|打籃球|騎腳踏車|散步|瑜珈|伸展|爬山|午睡|睡覺|休息一下"],
  ["生活", 1, 60, "看醫生|看牙醫|回診|門診|看診|復健|健康檢查|打疫苗|抽血|剪頭髮|去洗牙|看眼科|看皮膚科"],
  ["其他", 0, 120, "約會|跟{F}約會|跟{F}吃飯|跟{F}聚餐|聚餐|跟{F}看電影|看電影|逛街|跟{F}逛街|唱歌|唱KTV|吃火鍋|吃燒肉|喝下午茶|跟{F}出去|陪{F}|回家吃飯|家庭聚會|慶生|生日派對|參加婚禮|喝喜酒"],
  ["其他", 0, 60, "打電動|玩遊戲|追劇|看動漫|看YouTube|滑手機|看小說|看漫畫|聽音樂|練吉他|畫畫|拍照|整理照片"],
  ["其他", 0, 480, "去旅行|出去玩|露營|去墾丁|去台中玩|回老家|搬家|參加演唱會|看展覽|逛夜市"],
  ["其他", 0, 30, "訂高鐵票|訂車票|訂機票|訂餐廳|訂飯店|買禮物|準備禮物|規劃旅行|查行程"]
];
const BRAIN_FILL = {
  A: ["老師", "教授", "指導教授", "學長", "學姐", "學弟", "學妹", "同學", "助教", "組員"],
  B: ["老闆", "主管", "同事", "客戶", "廠商", "業主", "經理", "PM"],
  S: ["熱傳", "流力", "高流", "兩相流", "高應數", "燃料電池", "熱力學", "微積分", "線代", "工數", "材料力學", "動力學", "控制", "數值方法", "英文", "統計", "物理", "化學", "電路", "程式設計"],
  P: ["老師", "教授", "學長", "學姐", "同學", "組員", "老闆", "主管", "客戶", "廠商", "助教", "指導教授"],
  F: ["朋友", "男友", "女友", "家人", "爸媽", "同學", "室友", "閨蜜"]
};
const BRAIN_NOISE_PRE = ["", "", "", "先", "要", "去", "趕快", "把"];
const BRAIN_NOISE_POST = ["", "", "", "一下", "完", "好", "的部分", "收尾"];

/* ===== AI 小模型核心（網頁和訓練程式共用同一份） ===== */
const BC_H = 16384, BC_D = 32, BC_MU = Math.log2(60), BC_SD = 1.2;
const bcRng = seed => () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };
function bcHash(s) { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return (h >>> 0) % BC_H; }
function bcNorm(s) {
  return String(s || "").toLowerCase().replace(/[０-９]/g, c => String.fromCharCode(c.charCodeAt(0) - 0xFEE0))
    .replace(/（\d+\/\d+）|\(\d+\/\d+\)/g, "").replace(/\d+/g, "#").replace(/[，,。.！!？?、；;：:「」『』（）()\[\]【】~～\-—_/]/g, " ").replace(/\s+/g, " ").trim();
}
/** 一句話 → 片段：每個字、相鄰兩個字、相鄰三個字、英文單字、開頭／結尾的字 */
function bcTokens(s) {
  const t = bcNorm(s), out = [];
  for (const w of (t.match(/[a-z#]+/g) || [])) { out.push("w:" + w); if (w.length > 4) out.push("p:" + w.slice(0, 4)); }
  const segs = t.replace(/[a-z#\s]+/g, " ").split(" ").filter(Boolean);
  for (const seg of segs) {
    for (let i = 0; i < seg.length; i++) {
      out.push("u:" + seg[i]);
      if (i + 1 < seg.length) out.push("b:" + seg.slice(i, i + 2));
      if (i + 2 < seg.length) out.push("t:" + seg.slice(i, i + 3));
    }
  }
  if (segs.length) { out.push("s:" + segs[0][0]); const l = segs[segs.length - 1]; out.push("e:" + l[l.length - 1]); }
  return out;
}
function bcFeats(s) { const f = [...new Set(bcTokens(s))].map(bcHash); return f.length ? f : [bcHash("u:?")]; }
function bcModel(names, seed) {
  const r = bcRng(seed || 7), C = names.length;
  return { names: names.slice(), W: new Float32Array(BC_H * BC_D).map(() => (r() - 0.5) * 0.2), Cw: new Float32Array(C * BC_D), Cb: new Float32Array(C),
    Ew: new Float32Array(BC_D), Eb: 0, Mw: new Float32Array(BC_D), Mb: 0 };
}
/** 新增分類（例如你自己加的「社團」）：多一個輸出 */
function bcAddNames(M, names) {
  const add = names.filter(n => !M.names.includes(n));
  if (!add.length) return M;
  const C = M.names.length + add.length, Cw = new Float32Array(C * BC_D), Cb = new Float32Array(C);
  Cw.set(M.Cw); Cb.set(M.Cb);
  for (let c = M.names.length; c < C; c++) Cb[c] = -2;      // 新分類一開始機率低，要等你的資料教它
  M.names = [...M.names, ...add]; M.Cw = Cw; M.Cb = Cb;
  return M;
}
function bcForward(M, f) {
  const D = BC_D, h = new Float32Array(D), W = M.W;
  for (const k of f) { const o = k * D; for (let j = 0; j < D; j++) h[j] += W[o + j]; }
  for (let j = 0; j < D; j++) h[j] /= f.length;
  const C = M.names.length, p = new Float32Array(C);
  let mx = -1e9;
  for (let c = 0; c < C; c++) { let z = M.Cb[c]; for (let j = 0; j < D; j++) z += M.Cw[c * D + j] * h[j]; p[c] = z; if (z > mx) mx = z; }
  let sum = 0; for (let c = 0; c < C; c++) { p[c] = Math.exp(p[c] - mx); sum += p[c]; }
  for (let c = 0; c < C; c++) p[c] /= sum;
  let ze = M.Eb, zm = M.Mb; for (let j = 0; j < D; j++) { ze += M.Ew[j] * h[j]; zm += M.Mw[j] * h[j]; }
  return { h, p, ev: 1 / (1 + Math.exp(-ze)), m: zm };
}
/** 一筆資料訓練一步：d = { f: 特徵, c: 分類編號(-1=不知道), e: 0/1/-1, m: 標準化後的分鐘(null=不知道), w: 權重 } */
function bcStep(M, d, lr) {
  const D = BC_D, o = bcForward(M, d.f), C = M.names.length, g = new Float32Array(D), w = d.w || 1;
  if (d.c >= 0) for (let c = 0; c < C; c++) {
    const gc = (o.p[c] - (c === d.c ? 1 : 0)) * w;
    for (let j = 0; j < D; j++) { g[j] += gc * M.Cw[c * D + j]; M.Cw[c * D + j] -= lr * gc * o.h[j]; }
    M.Cb[c] -= lr * gc;
  }
  if (d.e === 0 || d.e === 1) {
    const ge = (o.ev - d.e) * w * 0.7;
    for (let j = 0; j < D; j++) { g[j] += ge * M.Ew[j]; M.Ew[j] -= lr * ge * o.h[j]; }
    M.Eb -= lr * ge;
  }
  if (d.m != null) {
    const gm = Math.max(-2, Math.min(2, o.m - d.m)) * w * 0.5;
    for (let j = 0; j < D; j++) { g[j] += gm * M.Mw[j]; M.Mw[j] -= lr * gm * o.h[j]; }
    M.Mb -= lr * gm;
  }
  const inv = lr / d.f.length;
  for (const k of d.f) { const off = k * D; for (let j = 0; j < D; j++) M.W[off + j] -= inv * g[j]; }
}
const bcMin = z => Math.max(10, Math.min(480, Math.round(Math.pow(2, z * BC_SD + BC_MU) / 5) * 5));
const bcZ = m => (Math.log2(m) - BC_MU) / BC_SD;
/** 把訓練好的模型壓成小檔案（int8，每一列一個縮放值） */
function bcPack(M) {
  const D = BC_D, rows = BC_H, q = new Int8Array(rows * D), sc = new Float32Array(rows);
  for (let r = 0; r < rows; r++) {
    let mx = 0; for (let j = 0; j < D; j++) mx = Math.max(mx, Math.abs(M.W[r * D + j]));
    const s = mx / 127 || 1e-6; sc[r] = s;
    for (let j = 0; j < D; j++) q[r * D + j] = Math.round(M.W[r * D + j] / s);
  }
  const head = { names: M.names, Cw: Array.from(M.Cw), Cb: Array.from(M.Cb), Ew: Array.from(M.Ew), Eb: M.Eb, Mw: Array.from(M.Mw), Mb: M.Mb, H: BC_H, D };
  return { q, sc, head };
}
function bcUnpack(q, sc, head) {
  const D = BC_D, W = new Float32Array(BC_H * D);
  for (let r = 0; r < BC_H; r++) for (let j = 0; j < D; j++) W[r * D + j] = q[r * D + j] * sc[r];
  return { names: head.names.slice(), W, Cw: Float32Array.from(head.Cw), Cb: Float32Array.from(head.Cb), Ew: Float32Array.from(head.Ew), Eb: head.Eb, Mw: Float32Array.from(head.Mw), Mb: head.Mb };
}

const Brain = (() => {
  let base = null, baseInfo = null, loading = null;   // 預先訓練好的模型（brain-base.bin）
  let M = null, sig = "", mem = [], info = {}, trained = false;
  /** 下載預先訓練好的模型（約 0.6 MB，之後瀏覽器會快取） */
  function load() {
    if (loading) return loading;
    loading = fetch("/brain-base.bin?v=e2b8d6aa", { cache: "force-cache" }).then(r => { if (!r.ok) throw new Error("brain " + r.status); return r.arrayBuffer(); }).then(buf => {
      const dv = new DataView(buf), hl = dv.getUint32(0, true);
      const head = JSON.parse(new TextDecoder().decode(new Uint8Array(buf, 4, hl)));
      let off = 4 + hl; off += (4 - (off % 4)) % 4;
      if (head.H !== BC_H || head.D !== BC_D) throw new Error("brain size");
      const sc = new Float32Array(buf, off, BC_H); off += BC_H * 4;
      const q = new Int8Array(buf, off, BC_H * BC_D);
      base = bcUnpack(q, sc, head); baseInfo = head; trained = false;
    }).catch(e => { console.warn("brain base", e); });
    return loading;
  }
  /** 備用：還沒下載到預先訓練的模型時，用內建句子在手機上現場訓練 */
  function seedExamples(perPhrase) {
    const r = bcRng(42), out = [];
    for (const [c, e, m, list] of BRAIN_SEED) {
      for (const phrase of list.split("|")) {
        const slot = (phrase.match(/\{([SPF])\}/) || [])[1];
        const fills = slot ? BRAIN_FILL[slot] : [""];
        const n = slot ? perPhrase : Math.ceil(perPhrase / 2);
        for (let i = 0; i < n; i++) {
          const f = fills[Math.floor(r() * fills.length)];
          const x = BRAIN_NOISE_PRE[Math.floor(r() * BRAIN_NOISE_PRE.length)] + phrase.replace(/\{[SPF]\}/, f) + BRAIN_NOISE_POST[Math.floor(r() * BRAIN_NOISE_POST.length)];
          out.push({ x, c, e, m: m * (0.8 + r() * 0.4), w: 1 });
        }
      }
    }
    return out;
  }
  /** 你的資料：你改過的（權重高）＋你建立的工作 */
  function userExamples() {
    const out = [], seen = new Set();
    for (const L of (S.settings.learnLog || []).slice().reverse()) {
      const k = bcNorm(L.x); if (!k || seen.has(k)) continue; seen.add(k);
      out.push({ x: L.x, c: L.c || null, e: L.e ? 1 : 0, m: L.m || 0, p: L.p ?? null, w: L.w || 3, src: "me" });
    }
    // Gemini 在背景幫忙標註的句子（權重比你自己改的低）
    for (const L of (S.settings.gemLog || []).slice().reverse()) {
      const k = bcNorm(L.x); if (!k || seen.has(k)) continue; seen.add(k);
      out.push({ x: L.x, c: L.c || null, e: L.e ? 1 : 0, m: L.m || 0, p: L.p ?? null, w: 1.5, src: "gem" });
    }
    if (!S.sample) {
      for (const t of S.tasks.slice(-600).reverse()) {
        const k = bcNorm(t.wname || t.title); if (!k || seen.has(k)) continue; seen.add(k);
        const c = cat(t.cat);
        out.push({ x: t.wname || t.title, c: c && !c.event ? c.name : null, e: c && c.event ? 1 : 0, m: t.wid ? 0 : t.min, w: 1 });
      }
    }
    return out;
  }
  const toData = (list, names) => list.map(x => ({ f: bcFeats(x.x), c: x.c ? names.indexOf(x.c) : -1, e: x.e, m: x.m > 0 ? bcZ(x.m) : null, w: x.w }));
  const shuffle = (a, r) => { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
  function train(force) {
    const user = userExamples();
    const s = JSON.stringify([!!base, S.cats.map(c => c.name), user.length, (S.settings.learnLog || []).length, (S.settings.gemLog || []).length, user.slice(0, 3).map(u => u.x)]);
    if (trained && !force && s === sig) return;
    const t0 = performance.now(), r = bcRng(7);
    sig = s;
    const userNames = [...user.map(x => x.c).filter(Boolean), ...S.cats.filter(c => !c.event).map(c => c.name)];
    let replay;
    if (base) {
      // 從預先訓練好的模型開始，用你的資料再微調（fine-tune）
      M = { ...base, names: base.names.slice(), W: base.W.slice(), Cw: base.Cw.slice(), Cb: base.Cb.slice(), Ew: base.Ew.slice(), Mw: base.Mw.slice() };
      bcAddNames(M, userNames);
      replay = toData(seedExamples(1), M.names);                  // 少量複習內建句子，避免學了你的就忘了原本的
      const mine = toData(user, M.names);
      if (mine.length) {
        const EP = 6;
        for (let ep = 0; ep < EP; ep++) {
          const lr = 0.15 * (1 - ep / EP) + 0.02;
          const batch = shuffle([...mine, ...shuffle(replay.slice(), r).slice(0, Math.min(replay.length, mine.length * 4 + 50))], r);
          for (const d of batch) bcStep(M, d, lr);
        }
      }
    } else {
      // 備用：現場從頭訓練
      const seed = seedExamples(5);
      M = bcModel([...new Set([...seed.map(x => x.c), ...userNames])], 7);
      const data = shuffle(toData([...seed, ...user], M.names), r), EP = 10;
      for (let ep = 0; ep < EP; ep++) { const lr = 0.5 * (1 - ep / EP) + 0.02; shuffle(data, r); for (const d of data) bcStep(M, d, lr); }
    }
    mem = user.filter(u => u.src === "me" || u.src === "gem").map(u => ({ ...u, set: new Set(bcTokens(u.x)) }));
    trained = true;
    info = { pre: !!base, base: baseInfo ? baseInfo.trainedOn : 0, test: baseInfo ? baseInfo.test : null, user: user.length,
      fixes: (S.settings.learnLog || []).length, gem: (S.settings.gemLog || []).length, ms: Math.round(performance.now() - t0), cats: M.names.length };
  }
  /** 跟你以前改過的句子很像 → 照你上次的 */
  /** 先找你自己改過的（相似度 60% 以上），沒有再找 Gemini 教過的（75% 以上） */
  function recall(x) {
    const A = new Set(bcTokens(x)); if (A.size < 2) return null;
    const find = (src, th) => {
      let best = null;
      for (const m of mem) {
        if (m.src !== src) continue;
        let inter = 0; for (const t of m.set) if (A.has(t)) inter++;
        const sim = inter / Math.max(A.size, m.set.size);
        if (sim > (best ? best.sim : th)) best = { ...m, sim };
      }
      return best;
    };
    return find("me", 0.6) || find("gem", 0.75);
  }
  function predict(x) {
    train(false);
    const o = bcForward(M, bcFeats(x));
    let ci = 0; for (let c = 1; c < o.p.length; c++) if (o.p[c] > o.p[ci]) ci = c;
    const r = recall(x);
    return { cat: M.names[ci], catP: o.p[ci], ev: o.ev, min: bcMin(o.m), mem: r ? { x: r.x, c: r.c, e: r.e, m: r.m, p: r.p, sim: r.sim, src: r.src } : null };
  }
  return { load, train, predict, info: () => { train(false); return info; }, reset: () => { trained = false; } };
})();
// 小模型等畫面穩定、閒下來再下載，不拖慢開啟速度
(window.requestIdleCallback || (f => setTimeout(f, 1500)))(() => Brain.load().then(() => { if (ui.tab === "settings" && !ui.sheet && FB.loaded) renderMain(); }), { timeout: 4000 });

/** 用小模型修正內建規則的猜測（分類、要多久、固定事件） */
function brainRefine(p) {
  if (!p || !p.title) return p;
  let pr;
  const place = ((p.notes || "").match(/地點：(\S+)/) || [])[1] || "";
  try { pr = Brain.predict(place ? `${p.title} ${place}` : p.title); } catch (e) { console.warn("brain", e); return p; }
  p._brain = pr;
  const m = pr.mem;
  // 1. 個人記憶最優先：你改過很像的句子
  if (m) {
    if (m.c && S.cats.some(c => c.name === m.c && !c.event)) p.category = m.c;
    if (!p.minGiven && m.m) p.minutes = m.m;
    if (m.e && p.time && !p.vague) p.isEvent = true;
    if (!m.e && p.isEvent && m.c) p.isEvent = false;
    if (!p.priGiven && m.p != null) p.priority = m.p;
    return p;
  }
  // 2. 小模型：規則沒把握時才用
  if (pr.catP >= (p.category ? 0.8 : 0.45) && S.cats.some(c => c.name === pr.cat && !c.event)) p.category = pr.cat;
  if (!p.minGiven && !p.durRule) p.minutes = pr.min;
  if (!p.isEvent && p.time && !p.vague && pr.ev > 0.8 && !OTHER_RE.test(p.title)) p.isEvent = true;
  return p;
}
/** 記下你確認或修改後的結果，下次訓練時用 */
function brainLearn(x, catId, min, changed, pri) {
  x = String(x || "").trim(); if (!x) return;
  const c = cat(catId);
  const row = { x: x.slice(0, 60), c: c && !c.event ? c.name : "", e: c && c.event ? 1 : 0, m: Math.round(min || 0), w: changed ? 3 : 2 };
  if (pri != null) row.p = pri;
  const key = row.x.replace(/\s+/g, "");
  S.settings.learnLog = [...(S.settings.learnLog || []).filter(L => String(L.x).replace(/\s+/g, "") !== key), row].slice(-500);
}
function brainSettingsHTML() {
  let i = {};
  try { i = Brain.info(); } catch (e) { console.warn(e); }
  const pct = v => Math.round((v || 0) * 100) + "%";
  return `<section class="sec"><div class="sechead"><h2>AI 小模型</h2></div><div class="form">
    <div class="field col"><span class="lab">${i.pre ? "預先訓練好的小模型 + 你的資料微調" : "在你的手機上訓練的小模型"}<small class="sub">${i.pre ? `Claude 先用 ${i.base} 句待辦訓練好${i.test ? `（沒看過的 ${i.test.n} 句考題：分類答對 ${pct(i.test.acc)}、固定事件答對 ${pct(i.test.accE)}）` : ""}，` : "預先訓練的模型還在下載，先用內建句子現場訓練，"}再用你自己的 ${i.user || 0} 筆工作微調（其中 ${i.fixes || 0} 筆是你確認或改過的），還有 Gemini 在背景教的 ${i.gem || 0} 句。這次訓練花了 ${i.ms || 0} 毫秒。</small></span></div>
    <div class="field col"><input type="text" id="brain-try" placeholder="打一句試試看，例如：做熱傳簡報" style="border:0;background:var(--surface-2);border-radius:8px;padding:8px 10px" aria-label="測試句子">
      <div id="brain-out" class="brain-out">它會猜分類、要多久、是不是固定事件。</div></div>
    ${habitHTML()}
    <div class="field"><div class="btnrow"><button class="btn" data-act="brain-retrain">重新訓練</button>${(S.settings.learnLog || []).length ? `<button class="btn" data-act="brain-clear">清除它學到的修改</button>` : ""}</div></div>
  </div><p class="footnote">智慧排程沒有用 Gemini 時，會先用規則看日期和時間，再用這個小模型判斷分類、要多久、是不是固定事件。你在預覽或編輯時改了分類或時間長度，它會記下來，下次遇到很像的句子就照你的習慣。資料只存在你的帳號裡。</p></section>`;
}
/** 學到的時段習慣：每一類事 24 小時，顏色越深越常在那時候做 */
function habitHTML() {
  const H = S.settings.habit || {}, names = Object.keys(H).filter(n => !n.startsWith("t:") && H[n].some(v => v > 0)).sort((x, y) => (x === "_all" ? -1 : y === "_all" ? 1 : 0));
  if (!names.length) return `<div class="field col"><span class="lab">時段習慣<small class="sub">還在觀察：你打勾完成工作、自己指定時間、或沒做到被往後排時，它會記下你習慣在幾點做哪一類事，之後自動排時段會優先排進那些時間。</small></span></div>`;
  const rows = names.map(n => {
    const a = H[n], mx = Math.max(...a, 0.01), ready = !!habitOf(n);
    const cells = a.slice(6).concat(a.slice(0, 1)).map((v, i) => `<i style="opacity:${Math.max(0.06, v / mx).toFixed(2)}" title="${(i + 6) % 24}:00"></i>`).join("");
    return `<div class="hb-row"><span class="hb-n">${esc(n === "_" ? "未分類" : n === "_all" ? "整體效率" : n)}${ready ? "" : "<small>（資料還不夠）</small>"}</span><span class="hb-cells">${cells}</span></div>`;
  }).join("");
  return `<div class="field col"><span class="lab">時段習慣<small class="sub">顏色越深＝你越常在那個時間做這類事。自動排時段時會優先排進深色的時間。</small></span>
    <div class="hb">${rows}<div class="hb-row"><span class="hb-n"></span><span class="hb-axis"><b>6</b><b>12</b><b>18</b><b>24</b></span></div></div>
    <button class="btn sm" data-act="habit-clear" style="align-self:flex-start">清除時段習慣</button></div>`;
}
function brainTryText(x) {
  if (!x.trim()) return "它會猜分類、要多久、是不是固定事件。";
  const p = brainRefine(parseLine(x) || { title: x });
  const pr = p._brain || {};
  const src = pr.mem ? `跟${pr.mem.src === "gem" ? " Gemini 教過" : "你之前改過"}的「${esc(pr.mem.x)}」很像（相似度 ${Math.round(pr.mem.sim * 100)}%），照你上次的` : `模型判斷：${esc(pr.cat || "")} 信心 ${Math.round((pr.catP || 0) * 100)}%`;
  return `<b>${esc(p.title)}</b>：分類「${esc(p.category || "無")}」・${dur(p.minutes || 30)}${p.isEvent ? "・固定事件" : ""}${p.time ? `・${esc(p.time)}` : ""}<br><small>${src}；像固定事件的機率 ${Math.round((pr.ev || 0) * 100)}%</small>`;
}

/* ---------- AI 排程（Gemini） ---------- */
let aiModelPromise = null;
const AI_SDK_VERSIONS = ["12.2.1", "12.0.0", "11.10.0", "11.9.1"];
const AI_MODELS = ["gemini-3.8-flash", "gemini-3.5-flash", "gemini-3-flash", "gemini-2.5-flash"];
async function loadAISdk() {
  let lastErr;
  for (const v of AI_SDK_VERSIONS) {
    try {
      const [appMod, aiMod] = await Promise.all([
        import(`https://www.gstatic.com/firebasejs/${v}/firebase-app.js`),
        import(`https://www.gstatic.com/firebasejs/${v}/firebase-ai.js`)
      ]);
      return { appMod, aiMod };
    } catch (e) { lastErr = e; }
  }
  throw lastErr || new Error("無法載入 AI 元件");
}
/** 用使用者自己的 Gemini API 金鑰，直接呼叫 Google Gemini（不經過 Firebase AI Logic） */
let keyModelCache = "";
const AI_TIMEOUT_MS = 8000;   // AI 8 秒內沒排好，就改用內建規則（不顯示提示）
const AI_FILE_TIMEOUT_MS = 45000;   // 讀課表、PDF 比較久
const sleep = ms => new Promise(r => setTimeout(r, ms));
/** 問 Google 目前有哪些 flash 模型（新的在前，lite 放後面當備用） */
async function discoverFlashModels(key, signal) {
  const r = await fetch("https://generativelanguage.googleapis.com/v1beta/models?pageSize=200", { headers: { "x-goog-api-key": key }, signal });
  const j = await r.json().catch(() => ({}));
  const ver = n => (n.match(/gemini-(\d+(?:\.\d+)?)/) || [0, 0])[1] * 1;
  const list = (j.models || [])
    .filter(m => (m.supportedGenerationMethods || []).includes("generateContent"))
    .map(m => m.name.replace(/^models\//, ""))
    .filter(n => /^gemini-[\d.]+-flash(-lite)?(-latest)?$|^gemini-flash(-lite)?-latest$/.test(n));
  list.sort((a, b) => (/lite/.test(a) - /lite/.test(b)) || (ver(b) - ver(a)));
  return list;
}
/** 用使用者自己的 Gemini API 金鑰，直接呼叫 Google Gemini（不經過 Firebase AI Logic） */
async function geminiWithKey(prompt, key, signal, files) {
  const call = async name => {
    let r, j = {};
    try {
      r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${name}:generateContent`, {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-goog-api-key": key },
        body: JSON.stringify({ contents: [{ role: "user", parts: [{ text: prompt }, ...(files || []).map(f => ({ inlineData: { mimeType: f.mime, data: f.data } }))] }], generationConfig: { responseMimeType: "application/json", temperature: 0.2 } }),
        signal
      });
      j = await r.json().catch(() => ({}));
    } catch (e) { if (signal && signal.aborted) throw new Error("TIMEOUT"); throw new Error("Failed to fetch"); }
    if (r.ok) return { ok: true, text: ((j.candidates && j.candidates[0] && j.candidates[0].content && j.candidates[0].content.parts) || []).map(x => x.text || "").join("") };
    return { ok: false, status: r.status, err: new Error(`${r.status} ${(j.error && j.error.status) || ""} ${(j.error && j.error.message) || ""}`.trim()) };
  };
  // 這些狀況換個模型或等一下通常就好：找不到模型、太忙、暫時錯誤、單一模型額度用完
  const retryable = st => st === 404 || st === 429 || st === 500 || st === 503 || st === 504;
  const tried = new Set();
  let lastErr, discovered = null;
  const tryModel = async name => {
    if (!name || tried.has(name)) return null;
    tried.add(name);
    for (let attempt = 0; attempt < 2; attempt++) {
      const res = await call(name);
      if (res.ok) { keyModelCache = name; return res.text; }
      lastErr = res.err;
      if (!retryable(res.status)) throw lastErr;
      if (res.status === 404) return null;           // 這個模型不存在 → 換下一個
      if (signal && signal.aborted) throw new Error("TIMEOUT");
      if (attempt === 0) await sleep(1500);           // 太忙 → 等一下再試一次
    }
    return null;
  };
  for (const name of [keyModelCache, ...AI_MODELS]) {
    const t = await tryModel(name); if (t != null) return t;
  }
  if (signal && signal.aborted) throw new Error("TIMEOUT");
  discovered = await discoverFlashModels(key, signal).catch(() => []);
  for (const name of discovered.slice(0, 3)) {
    const t = await tryModel(name); if (t != null) return t;
  }
  throw lastErr;
}
async function aiGenerate(prompt, signal, files) {
  const key = (S.settings.geminiKey || "").trim(), ck = claudeKey();
  if (ck) {
    try { return await claudeWithKey(prompt, ck, signal, files); }
    catch (e) { if ((signal && signal.aborted) || !key) throw e; console.warn("claude → gemini", e); }
  }
  if (key) return geminiWithKey(prompt, key, signal, files);
  if (!FB.cfg) throw new Error("Firebase 還沒準備好");
  if (!aiModelPromise) {
    aiModelPromise = loadAISdk().then(({ appMod, aiMod }) => {
      const app = appMod.getApps().find(a => a.name === "ai") || appMod.initializeApp(FB.cfg, "ai");
      const backends = [];
      if (aiMod.GoogleAIBackend) backends.push(aiMod.getAI(app, { backend: new aiMod.GoogleAIBackend() }));
      if (aiMod.VertexAIBackend) backends.push(aiMod.getAI(app, { backend: new aiMod.VertexAIBackend() }));
      return { backends, aiMod };
    }).catch(e => { aiModelPromise = null; throw e; });
  }
  const { backends, aiMod } = await aiModelPromise;
  let lastErr;
  // 先用 Gemini Developer API；如果專案設定的是 Vertex AI，就改用 Vertex AI
  for (const ai of backends) {
    for (const name of AI_MODELS) {
      try {
        const model = aiMod.getGenerativeModel(ai, { model: name, generationConfig: { responseMimeType: "application/json", temperature: 0.2 } });
        const res = await model.generateContent(prompt);
        return res.response.text();
      } catch (e) {
        lastErr = e;
        const msg = String(e && e.message || e);
        if (/config not found/i.test(msg)) break;            // 這個提供者沒設定 → 換下一個
        if (!/not found|404|not supported|unavailable/i.test(msg)) throw e;  // 其他錯誤直接回報
      }
    }
  }
  throw lastErr;
}
/* ===================== 更聰明的智慧排程 =====================
 * 1. AI 引擎：有 Claude 金鑰用 Claude（Haiku 5.5 / Sonnet 5.5），否則 Gemini，再不然用內建規則＋小模型
 * 2. 學你實際花多久 + 拖延緩衝
 * 3. 學你什麼時候效率好、哪件事習慣在幾點做（延伸「時段習慣」）
 * 4. 截止日前留一天緩衝
 * 5. 大工作拆成步驟
 * 6. 每天早上給你今天的計畫 */
const CLAUDE_MODELS = [["claude-haiku-5-5", "Claude Haiku 5.5", "快、便宜，排程很夠用"], ["claude-sonnet-5-5", "Claude Sonnet 5.5", "更聰明，費用比較高"]];
const claudeKey = () => (S.settings.claudeKey || "").trim();
const llmKey = () => claudeKey() || (S.settings.geminiKey || "").trim();
const llmName = () => claudeKey() ? (CLAUDE_MODELS.find(m => m[0] === S.settings.claudeModel) || CLAUDE_MODELS[0])[1] : "Gemini";
async function claudeWithKey(prompt, key, signal, files) {
  const content = [];
  for (const f of files || []) {
    if (/^image\/(png|jpeg|gif|webp)$/.test(f.mime)) content.push({ type: "image", source: { type: "base64", media_type: f.mime, data: f.data } });
    else if (f.mime === "application/pdf") content.push({ type: "document", source: { type: "base64", media_type: "application/pdf", data: f.data } });
  }
  content.push({ type: "text", text: prompt + "\n\n只輸出 JSON 本身，不要加說明文字，也不要用 ``` 包起來。" });
  const r = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST", signal,
    headers: { "content-type": "application/json", "x-api-key": key, "anthropic-version": "2023-06-01", "anthropic-dangerous-direct-browser-access": "true" },
    body: JSON.stringify({ model: S.settings.claudeModel || CLAUDE_MODELS[0][0], max_tokens: 4096, messages: [{ role: "user", content }] })
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) { const e = new Error(`Claude ${r.status} ${(j.error && j.error.message) || ""}`); e.claude = r.status; throw e; }
  return (j.content || []).filter(c => c.type === "text").map(c => c.text).join("").replace(/^\s*```(?:json)?\s*|\s*```\s*$/g, "");
}

/* ---- 給 AI 的背景資料：你已經排了什麼、你的習慣（讓它看懂「那個報告」「開完會後」） ---- */
function aiContext() {
  const t0 = today(), end = addDays(t0, 7);
  const rows = S.tasks.filter(t => t.date >= t0 && t.date <= end && !t.cancelled && !t.done).sort((a, b) => a.date < b.date ? -1 : a.date > b.date ? 1 : (a.start ?? 9999) - (b.start ?? 9999)).slice(0, 40)
    .map(t => `${t.date}${t.start != null ? " " + hm(t.start) + "–" + hm(t.start + t.min) : ""} ${t.title}${isEvent(t) ? "（固定事件）" : ""}${t.deadline ? `（截止 ${t.deadline}）` : ""}`);
  const r = (S.settings.durLearn || {})._all;
  const bh = bestHours();
  return `${rows.length ? `\n使用者接下來一週已經排好的事（只是參考，不要重複加入）：\n${rows.join("\n")}\n` : ""}${r && r.n >= 5 ? `使用者實際做事通常花預估的 ${r.r} 倍時間。\n` : ""}${bh ? `使用者效率最好的時段大約是 ${bh}。\n` : ""}`;
}

/* ---- 1. 學你實際花多久 ---- */
const durKey = t => bcNorm(String(t.wname || t.title || "").replace(/（\d+\/\d+）$/, "")).slice(0, 24);
function durLearn(t, actual) {
  if (!t || isEvent(t) || !t.min || !actual) return;
  const r = Math.max(0.4, Math.min(3, actual / t.min));
  const L = S.settings.durLearn = { ...(S.settings.durLearn || {}) };
  const upd = k => { const o = L[k] || { r: 1, n: 0 }; const a = o.n < 3 ? 0.5 : 0.3; L[k] = { r: Math.round((o.r * (1 - a) + r * a) * 100) / 100, n: Math.min(99, o.n + 1), at: Date.now() }; };
  const k = durKey(t); if (k) upd("t:" + k);
  const c = cat(t.cat); upd("c:" + (c ? c.name : "_"));
  upd("_all");
  const tk = Object.keys(L).filter(x => x.startsWith("t:"));
  if (tk.length > 200) tk.sort((a, b) => (L[a].at || 0) - (L[b].at || 0)).slice(0, tk.length - 200).forEach(x => delete L[x]);
}
function durRatio(title, catId) {
  const L = S.settings.durLearn || {}, k = "t:" + durKey({ title }), c = cat(catId);
  if (L[k] && L[k].n >= 2) return L[k].r;
  const cc = L["c:" + (c ? c.name : "_")]; if (cc && cc.n >= 3) return cc.r;
  const a = L._all; if (a && a.n >= 5) return a.r;
  return 1;
}
const bufferX = () => Math.max(1, Math.min(2.5, +(S.settings.bufferX ?? 1.5) || 1));
/** 你沒自己寫要多久的事：預估 × 你實際的速度 × 拖延緩衝 */
function smartFactor(it) {
  if (it.minGiven || it.isEv || it.repeat) return 1;
  return Math.max(0.5, Math.min(3, durRatio(it.title, it.cat) * bufferX()));
}
/** 打勾時：如果是照排好的時段做的，記下實際花了多久 */
function durFromDone(t) {
  if (!t || t.start == null || t.date !== today() || isEvent(t)) return;
  const now = nowMin(), used = now - t.start;
  if (used >= t.min * 0.5 && used <= t.min * 3) durLearn(t, used);
}

/* ---- 3. 效率最好的時段 ---- */
function bestHours() {
  const a = habitOf("_all"); if (!a) return "";
  const s = S.settings, h0 = Math.floor(s.workStart / 60), h1 = Math.ceil(s.workEnd / 60);
  let best = -1, bs = -1e9;
  for (let h = h0; h + 2 <= h1; h++) { const v = a[h] + a[h + 1]; if (v > bs) { bs = v; best = h; } }
  return best >= 0 && bs > 0 ? `${pad(best)}:00–${pad(best + 2)}:00` : "";
}
const isFocus = t => (t.pri || 0) >= 2 || (t.min || 0) >= 60;

/* ---- 4. 截止日前留一天：先試著在截止日前一天以前排好 ---- */
function bestDayFit(min, limit, map, start) {
  const cap = dayCap(), skip = S.settings.skipWeekends;
  for (let d = start, i = 0; d <= limit && i < 366; d = addDays(d, 1), i++) {
    if (skip && isWeekend(d)) continue;
    const u = map[d] || 0;
    if (u === 0 || u + min <= cap) return d;
  }
  return null;
}

/* ---- 5. 大工作拆成步驟 ---- */
const STEP_TPL = [
  [/簡報|投影片|presentation|ppt/i, [["整理內容、列大綱", .25], ["做投影片", .45], ["練習講一遍", .2], ["修改", .1]]],
  [/報告|report|paper|論文|proposal|企劃|書面/i, [["找資料、讀文獻", .25], ["列大綱", .1], ["寫初稿", .4], ["修改、排版", .15], ["最後檢查", .1]]],
  [/考試|期中|期末|小考|exam|quiz|midterm|final|複習|準備考/i, [["整理範圍和重點", .15], ["讀講義、筆記", .4], ["寫考古題、練習題", .3], ["複習錯題", .15]]],
  [/作業|習題|hw|homework|assignment/i, [["看題目、找相關講義", .2], ["寫第一遍", .55], ["檢查、整理", .25]]],
  [/實驗|experiment|量測/i, [["準備器材、確認步驟", .2], ["做實驗", .55], ["整理數據", .25]]],
  [/程式|code|coding|debug|網站|app/i, [["想清楚要做什麼", .15], ["寫程式", .55], ["測試、修 bug", .3]]]
];
async function breakSteps(title, min) {
  const scale = steps => {
    const tot = steps.reduce((a, s) => a + s.m, 0) || 1;
    const out = steps.map(s => ({ t: String(s.t).slice(0, 20), m: Math.max(15, Math.round(min * s.m / tot / 15) * 15) }));
    return out.filter(s => s.t);
  };
  if (llmKey()) {
    try {
      const ctrl = new AbortController(), tm = setTimeout(() => ctrl.abort(), 30000);
      const raw = await aiGenerate(`把這件事拆成 3 到 6 個具體、可以直接開始做的步驟，照先後順序。總時間大約 ${min} 分鐘。
步驟名稱用動詞開頭、12 個字以內、繁體中文（台灣用語），不要重複事情的名稱。
輸出 JSON：{"steps":[{"title":"步驟名稱","minutes":整數}]}
事情：${title}`, ctrl.signal);
      clearTimeout(tm);
      const j = JSON.parse(String(raw).match(/\{[\s\S]*\}/)[0]);
      const st = (j.steps || []).filter(x => x && x.title).slice(0, 6).map(x => ({ t: x.title, m: +x.minutes || 30 }));
      if (st.length >= 2) return { steps: scale(st), by: llmName() };
    } catch (e) { console.warn("breakSteps", e); }
  }
  const tpl = (STEP_TPL.find(([re]) => re.test(title)) || [null, [["開始：準備、拆解", .15], ["主要部分", .6], ["收尾、檢查", .25]]])[1];
  return { steps: scale(tpl.map(([t, m]) => ({ t, m }))), by: "" };
}
/** 拆好的步驟 → 交給排程，依順序排進截止日（或那天）之前 */
function scheduleSteps(src, steps) {
  const t0 = today(), g = uid();
  const dl = src.deadline;
  // 有截止日而且天數夠：最後一天留著當緩衝
  const end = dl ? (diff(t0, dl) >= steps.length ? addDays(dl, -1) : dl) : (src.date && src.date > t0 ? src.date : addDays(t0, Math.max(1, steps.length - 1)));
  return aiSchedule(steps.map((s, i) => ({ title: `${src.title.replace(/（\d+\/\d+）$/, "")}：${s.t}`, min: s.m, pri: src.pri ?? 1, cat: src.cat, date: null, time: null, deadline: src.deadline || null, isEv: false,
    notes: src.notes || "", rangeStart: t0, rangeEnd: maxKey(end, t0), _g: g, _p: i + 1, minGiven: true, repeat: null })));
}
const cleanItem = x => { const o = { ...x }; ["window", "_src", "_pc", "_pm", "_pp", "_f", "repeat"].forEach(k => delete o[k]); return normalize(o); };

/* ---- 6. 每天早上：今天的計畫 ---- */
function maybeMorningPlan() {
  const s = S.settings, t0 = today();
  if (s.morningPlan === false || s.morningDay === t0 || !FB.loaded) return;
  if (ui.sheet) { ui.morningPending = true; return; }
  if (nowMin() > s.workEnd - 30) return;                     // 已經下班了就不打擾
  const list = S.tasks.filter(t => t.date === t0 && !t.cancelled && !t.done);
  if (!list.length) return;
  s.morningDay = t0;
  arrangeTimes(t0, "fill"); save();
  openSheet({ type: "morning" });
}
function sheetMorning() {
  const t0 = today(), all = S.tasks.filter(t => t.date === t0 && !t.cancelled).sort((a, b) => (a.start ?? 9999) - (b.start ?? 9999));
  const open = all.filter(t => !t.done), todo = open.filter(t => !isEvent(t)), evs = open.filter(isEvent);
  const mins = todo.reduce((a, t) => a + t.min, 0), extra = overflow(onDay(t0)), od = S.tasks.filter(isOverdue), bh = bestHours();
  const h = nowMin() < 720 ? "早安" : nowMin() < 1080 ? "午安" : "晚安";
  const body = `<div class="mp-hero"><b>${h}！今天有 ${todo.length} 件事${evs.length ? `、${evs.length} 個固定行程` : ""}</b><small>大約 ${dur(mins)}${bufferX() > 1 ? `（已加上 ×${bufferX()} 的緩衝）` : ""}・${hm(S.settings.workStart)}–${hm(S.settings.workEnd)}</small>
      ${bh ? `<small>${I.spark}你通常 ${bh} 效率最好，重要的事已經排在那附近</small>` : ""}</div>
    ${clockSVG(t0)}
    <div class="list mp-list">${open.map(t => `<div class="mp-row${isEvent(t) ? " ev" : ""}"><span class="mp-t num">${t.start != null ? hm(t.start) : "—"}</span><span class="mp-n">${esc(t.title)}<small>${dur(t.min)}${isEvent(t) ? "・固定" : t.pri >= 2 ? `・${PRI[t.pri]}` : ""}</small></span></div>`).join("")}</div>
    ${extra.length ? `<div class="banner"><div class="t">${I.alert}今天排不下 ${extra.length} 件</div><button class="btn" data-act="spread" data-date="${t0}">${I.wand}分到之後有空的日子</button></div>` : ""}
    ${od.length ? `<div class="banner"><div class="t">${I.alert}之前還有 ${od.length} 件沒做完</div><button class="btn" data-act="smart-overdue">${I.spark}幫我排進之後的時間</button></div>` : ""}
    <button class="btn primary block" data-act="close">開始今天</button>
    <button class="btn block" data-act="morning-replan">${I.wand}幫我重新排一次時段</button>`;
  return sheetWrap("今天的計畫", cancelBtn("關閉"), spacer, body);
}
function smartSettingsHTML() {
  const s = S.settings, L = s.durLearn || {}, a = L._all, bh = bestHours(), bx = bufferX();
  const mdl = s.claudeModel || CLAUDE_MODELS[0][0];
  return `<section class="sec"><div class="sechead"><h2>更聰明的排程</h2></div><div class="form">
    <div class="field col"><label for="cl-key">Claude API 金鑰（選填，最聰明）</label>
      <input type="password" id="cl-key" autocomplete="off" placeholder="${s.claudeKey ? "已設定（要更換請貼上新的）" : "貼上以 sk-ant- 開頭的金鑰"}" style="border:0;background:var(--surface-2);border-radius:8px;padding:8px 10px">
      <div class="seg">${CLAUDE_MODELS.map(([id, n]) => `<button class="${mdl === id ? "on" : ""}" data-act="cl-model" data-m="${id}">${n.replace("Claude ", "")}</button>`).join("")}</div>
      <div class="btnrow"><button class="btn primary" data-act="cl-key-save">儲存金鑰</button>${s.claudeKey ? `<button class="btn" data-act="cl-key-test">測試</button><button class="btn" data-act="cl-key-clear">移除</button>` : ""}</div>
      <small class="sub">${s.claudeKey ? `目前用 ${esc(llmName())} 看懂你打的字、拆步驟。` : "有金鑰時，智慧排程會用 Claude 理解你打的字，比 Gemini 和內建規則更準。"}到 console.anthropic.com 申請，按使用量付費（要先儲值）；金鑰只存在你的帳號裡。</small></div>
    <div class="field"><label for="sw-aiAuto">AI 想好就自動換成它的版本<small class="sub">先用內建的馬上排好，AI 想完自動更新；你改過就不會蓋掉</small></label><span class="switch"><input type="checkbox" id="sw-aiAuto" data-set="aiAuto"${s.aiAuto !== false ? " checked" : ""}><span></span></span></div>
    <div class="field col"><span class="lab">拖延緩衝<small class="sub">預估時間自動乘上這個倍數，比較不會排了做不完（你自己寫多久的不會變）</small></span>
      <div class="seg">${[1, 1.25, 1.5, 2].map(v => `<button class="${Math.abs(bx - v) < 0.01 ? "on" : ""}" data-act="buffer-x" data-v="${v}">×${v}</button>`).join("")}</div></div>
    <div class="field"><label for="sw-morningPlan">每天早上給我今天的計畫<small class="sub">第一次打開時整理好今天要做的事和時段</small></label><span class="switch"><input type="checkbox" id="sw-morningPlan" data-set="morningPlan"${s.morningPlan !== false ? " checked" : ""}><span></span></span></div>
    <div class="field col"><span class="lab">已經學到的</span>
      <small class="sub">實際花的時間：${a && a.n >= 5 ? `大約是預估的 ${a.r} 倍（記錄了 ${a.n} 次）` : `還在觀察（照排好的時段做完打勾，就會記下來${a ? `，已記錄 ${a.n} 次` : ""}）`}</small>
      <small class="sub">效率最好的時段：${bh || "還在觀察（打勾完成、自己指定時間都會學）"}</small>
      <small class="sub">記得的事情：${Object.keys(S.settings.habit || {}).filter(k => k.startsWith("t:")).length} 種習慣的時段、${Object.keys(L).filter(k => k.startsWith("t:")).length} 種實際長度</small>
      ${Object.keys(L).length ? `<button class="btn sm" data-act="dur-clear" style="align-self:flex-start">清除時間長度的學習</button>` : ""}</div>
  </div></section>`;
}
function aiErrorText(e) {
  const msg = String((e && (e.code ? e.code + " " : "") + (e.message || "")) || e);
  if (/^Claude /.test(msg)) {
    if (/credit balance|billing/i.test(msg)) return "Claude 帳戶的餘額不夠了，到 console.anthropic.com 的 Billing 儲值後再試。";
    if (/Claude 401|authentication|x-api-key/i.test(msg)) return "Claude API 金鑰不正確。到「設定 › 更聰明的排程」重新貼上（整串 sk-ant- 開頭的）。";
    if (/Claude 404|model/i.test(msg)) return "Claude 找不到這個模型，到「設定 › 更聰明的排程」換另一個模型試試。";
    if (/Claude 429/.test(msg)) return "Claude 用得太頻繁了，等一分鐘再試。";
    if (/Claude 5\d\d|overloaded/i.test(msg)) return "Claude 現在很忙，過一下再試。";
    return "Claude 回覆失敗：" + msg.slice(7, 120);
  }
  if (S.settings.geminiKey && /API key not valid|API_KEY_INVALID|INVALID_ARGUMENT.*key/i.test(msg))
    return "Gemini 金鑰不正確。請到「設定 › AI 排程」重新貼上金鑰（要整串複製，前後不要有空白）。";
  if (/API_KEY_SERVICE_BLOCKED|are blocked|API key not valid|API_KEY_INVALID|referer|referrer/i.test(msg))
    return "API 金鑰不允許使用 AI。要到 Google Cloud 的「憑證」頁，把「Firebase AI Logic API」加到金鑰允許的 API 清單（步驟請問 Claude）。";
  if (/SERVICE_DISABLED|has not been used|is disabled|API_NOT_ACTIVATED|not been enabled/i.test(msg))
    return "Google 那邊的 AI 服務還沒啟用完成。剛開啟的話等 5–10 分鐘再試；還是不行請把技術訊息截圖給 Claude。";
  if (/config not found/i.test(msg))
    return "Firebase AI Logic 的設定還沒生效。最快的解法：到「設定 › AI 排程」貼上你自己的 Gemini 金鑰（免費，3 分鐘就能拿到）。";
  if (/quota|429|RESOURCE_EXHAUSTED/i.test(msg)) return "AI 免費額度暫時用完了，請過幾分鐘再試。";
  if (/503|UNAVAILABLE|high demand|overloaded/i.test(msg)) return "Google 的 AI 現在使用的人太多，已經自動換過模型還是很忙，請過幾分鐘再試。";
  if (/Failed to fetch|NetworkError|Importing a module|Load failed|dynamically imported/i.test(msg)) return "連不上 AI 服務（載入失敗），請檢查網路後再試。";
  if (/JSON/i.test(msg)) return "AI 回覆的格式看不懂，請再試一次，或把內容寫得更清楚一點。";
  if (/403|PERMISSION_DENIED/i.test(msg)) return "AI 服務拒絕了這次請求（沒有權限）。請把技術訊息截圖給 Claude。";
  return "AI 排程失敗，請把技術訊息截圖給 Claude。";
}
function aiPrompt(text, hasFiles) {
  const s = S.settings, t0 = today();
  const cats = S.cats.map(c => `${c.name}${c.event ? "（固定事件）" : ""}`).join("、");
  const nextDays = [0, 1, 2, 3, 4, 5, 6, 7].map(i => { const k = addDays(t0, i); return `${k} 星期${WD[parse(k).getDay()]}`; }).join("；");
  return `你是排程助理，負責把使用者打的待辦清單整理成結構化資料。
今天是 ${t0}（星期${WD[parse(t0).getDay()]}），現在時間 ${hm(nowMin())}。
接下來幾天的日期：${nextDays}。
使用者每天的工作時段是 ${hm(s.workStart)}–${hm(s.workEnd)}${breaks().map(b => `，${b[2]} ${hm(b[0])}–${hm(b[1])}`).join("")}。
可用的分類：${cats}。
${aiContext()}
請輸出 JSON：{"tasks":[{"title":"簡短的工作名稱","minutes":預估需要的分鐘數(整數，15 的倍數，最少 15，最多 480),"minutesGiven":使用者有沒有自己說要多久(true或false),"priority":0到3的整數(0低、1中、2高、3緊急),"category":"上面其中一個分類名稱，或 null","isEvent":true或false,"date":"YYYY-MM-DD 或 null","time":"HH:MM 或 null","deadline":"YYYY-MM-DD 或 null","notes":"地點、對象以外的補充細節，沒有就空字串","repeat":null 或 {"freq":"daily|weekly|monthly","interval":整數,"weekdays":[0到6，0是星期日],"until":"YYYY-MM-DD 或 null"},"rangeStart":"YYYY-MM-DD 或 null","rangeEnd":"YYYY-MM-DD 或 null","parts":整數(預設1),"src":"這一項在使用者輸入裡對應的原文（照抄那一小段）"}]}

規則：
1. 一件事一個項目；不要加入使用者沒提到的事情。
2. isEvent=true 只用在有固定時間、要準時出席的事（上課、開會、約診、聚餐）；這種一定要有 date 和 time，沒說時間就設 false。
3. date 只有使用者明確說「哪天做」才填；「週五前」「月底前」是 deadline，不是 date。相對日期（明天、下週三）要換算成實際日期。
4. time 只有使用者明確說幾點才填（24 小時制）。
5. minutes 依照事情的份量合理估計；使用者有寫時間長度就照寫的。
6. priority：有說急、重要、快到期的給 2 或 3；一般給 1；順便、有空再做的給 0。
7. title 只留重點（最好 12 個字以內），例如「記得明天下午兩點要去學校跟教授開會討論論文進度」→ title「跟教授討論論文進度」、notes「地點：學校」。去掉「記得、我要、幫我、提醒我」這類贅字和已經拆出來的日期時間。
9. 「每天、每週三、平日、每月5號、每隔3天」這類重複的事，要填 repeat，date 填第一次的日期。
10. 只說「晚上、下班後、睡前、早上」沒說幾點時，time 依常理填（晚上 19:00、下班後 18:30、睡前 22:30、早上 09:00），isEvent=false。
8. 約會、聚餐、和朋友家人的活動、看電影、逛街等私人活動，category 用「其他」，isEvent=false（有說時間就照填 time）。
11. 使用者給了日期區間（例如「11/1 到 11/7」「這週」「下週」「未來 5 天」「這個月」）要完成的事：填 rangeStart、rangeEnd，date 留 null，deadline 填 rangeEnd，程式會自動分配到區間內有空的日子。區間單獨寫在一行（例如「11/1-11/7 要做：」）時，套用到下面每一行，直到空白行為止。重複的事如果有區間（例如「11/3 到 11/7 每天背單字」），repeat.until 填區間最後一天、date 填第一天，不用填 rangeStart。
13. 「跟、和、還有、然後、另外、以及」連接的如果是不同的動作（例如「倒垃圾跟洗衣服」「交報告還有讀論文」），要拆成不同的項目；但「跟某人」是一起做事的對象（例如「跟教授開會」「跟男友吃飯」），不要拆；同一個動作的好幾樣東西（「買衛生紙跟洗衣精」）算一項。前面說的日期（例如「明天開會跟寫報告」）後面的事也沿用。「今明兩天」是今天到明天的區間。
12. 區間內可以拆成好幾份做的事（讀完 5 章、寫 3 篇、複習 4 個單元），parts 填份數、minutes 填「每一份」要多久；不能拆的 parts 填 1。

${hasFiles ? `13. 使用者附上了檔案（圖片或 PDF），請仔細讀出裡面所有的事情，連同文字輸入一起整理：
   - 課表：每一堂課是一個項目，isEvent=true，category「學習」，repeat={"freq":"weekly","interval":1,"weekdays":[那堂課的星期]}，date 填今天以後第一次上課的日期，time 填上課開始時間，minutes 填上課長度，地點、教室、老師寫在 notes。同一門課在不同天上，可以放在同一個項目的 weekdays（時間相同時）。看得出學期結束日就填 repeat.until。
   - 行事曆、考試表、作業清單：照上面寫的日期填 date 或 deadline，考試是 isEvent=true。
   - 看不清楚的字依常理判斷，不要自己編造檔案裡沒有的事情。
` : ""}
使用者輸入（在 <<< 和 >>> 之間）：
<<<
${text}
>>>`;
}
function aiParse(raw) {
  let data;
  try { data = JSON.parse(raw); } catch (e) {
    const m = String(raw).match(/\{[\s\S]*\}/); if (!m) throw new Error("JSON parse"); data = JSON.parse(m[0]);
  }
  const arr = Array.isArray(data) ? data : (data.tasks || []);
  const okDate = d => typeof d === "string" && /^\d{4}-\d{2}-\d{2}$/.test(d) ? d : null;
  const okTime = x => typeof x === "string" && /^\d{1,2}:\d{2}$/.test(x) ? toMin(x) : null;
  const evCat = S.cats.find(c => c.event);
  // 日期區間 + 拆成幾份（有指定哪天、或是重複的事就不用）
  const rangeOf = (x, date, rp) => {
    let a = okDate(x.rangeStart), b = okDate(x.rangeEnd);
    if (date || rp || !b) return {};
    if (!a || a < today()) a = today();
    if (b < a) return {};
    return { rangeStart: a, rangeEnd: b, parts: Math.max(1, Math.min(30, Math.round(+x.parts) || 1)) };
  };
  return arr.filter(x => x && x.title).slice(0, 60).map(x => {
    let catId = "";
    if (x.category) { const c = S.cats.find(c => c.name === x.category) || S.cats.find(c => String(x.category).includes(c.name) || c.name.includes(String(x.category))); if (c) catId = c.id; }
    const time = okTime(x.time), date = okDate(x.date), isEv = !!x.isEvent && date != null && time != null;
    const cat0 = catId;
    if (isEv && evCat) catId = evCat.id;
    if (!isEv && cat(catId) && cat(catId).event) catId = "";
    let rp = null;
    if (x.repeat && typeof x.repeat === "object" && /^(daily|weekly|monthly)$/.test(x.repeat.freq)) {
      rp = { freq: x.repeat.freq, interval: Math.max(1, Math.min(30, Math.round(+x.repeat.interval) || 1)) };
      if (okDate(x.repeat.until)) rp.until = okDate(x.repeat.until);
      if (rp.freq === "weekly") rp.weekdays = (Array.isArray(x.repeat.weekdays) ? x.repeat.weekdays : []).map(Number).filter(n => n >= 0 && n <= 6);
    }
    return {
      notes: typeof x.notes === "string" ? x.notes.slice(0, 200) : "", repeat: rp,
      title: String(x.title).slice(0, 80),
      min: Math.min(480, Math.max(15, Math.round((+x.minutes || 30) / 15) * 15)),
      pri: Number.isFinite(+x.priority) && x.priority !== null && x.priority !== "" ? Math.min(3, Math.max(0, Math.round(+x.priority))) : 1,
      cat: catId, date, time, deadline: okDate(x.deadline), isEv, ...rangeOf(x, date, rp),
      src: typeof x.src === "string" ? x.src.slice(0, 120) : "", cat0, isEvRaw: !!x.isEvent,
      minGiven: x.minGiven === true || x.minutesGiven === true || (typeof x.src === "string" && /\d+(\.\d+)?\s*(個)?\s*(小時|分鐘|鐘頭|hr|hour|min)|半(個)?小時/i.test(x.src))
    };
  });
}
/** 依目前的行程，幫 AI 整理出來的工作排日期與時段（不寫入，只回傳預覽） */
function aiSchedule(items) {
  // 沒自己寫要多久的：依你實際的速度 × 拖延緩衝調整
  items = items.map(it => { const f = smartFactor(it); return f === 1 ? it : { ...it, min: Math.min(480, Math.max(15, Math.round(it.min * f / 15) * 15)), _f: f }; });
  const backup = JSON.stringify(S.tasks), t0 = today();
  const startDay = nowMin() > S.settings.workEnd - 30 ? addDays(t0, 1) : t0;
  // 可以拆的工作先拆成好幾份：「讀完5章」→ 讀完5章（1/5）…（5/5）
  const meta = {}, flat = [];
  for (const it of items) {
    const n = it.parts || 1;
    if (n > 1 && it.rangeEnd && !it.date && !it.repeat) {
      const g = uid();
      for (let i = 1; i <= n; i++) flat.push({ ...it, title: `${it.title}（${i}/${n}）`, _src: it.title, _g: g, _p: i, _n: n });
    } else flat.push(it);
  }
  const news = flat.map(it => {
    const t = {
      id: uid(), title: it.title, notes: it.notes || "", repeat: it.repeat || null, date: it.date ? maxKey(it.date, t0) : null, deadline: it.deadline,
      pri: it.pri, min: it.min, cat: it.cat, done: false, doneOn: null, resched: 0, created: Date.now(),
      start: it.time, locked: it.time != null, series: null, occ: null, detached: false
    };
    if (it.rangeEnd && !t.date) {
      const a = maxKey(it.rangeStart || t0, startDay), b = maxKey(it.rangeEnd, a);
      meta[t.id] = { a, b, g: it._g || t.id, p: it._p || 0 };
    }
    return t;
  });
  const dated = news.filter(n => n.date), undated = news.filter(n => !n.date);
  const ranged = undated.filter(n => meta[n.id]), free = undated.filter(n => !meta[n.id]);
  S.tasks.push(...dated);

  // ---- 有日期區間的：平均分配到區間內最空的日子 ----
  const okDay = d => !(S.settings.skipWeekends && isWeekend(d));
  const daysIn = (a, b) => { const out = []; for (let d = a; d <= b && out.length < 200; d = addDays(d, 1)) if (okDay(d)) out.push(d); return out.length ? out : [a]; };
  const load = loadMap(new Set());
  const groups = {};
  ranged.forEach(t => { (groups[meta[t.id].g] = groups[meta[t.id].g] || []).push(t); });
  const gl = Object.values(groups).sort((A, B) => (B[0].pri - A[0].pri) || (meta[A[0].id].b < meta[B[0].id].b ? -1 : meta[A[0].id].b > meta[B[0].id].b ? 1 : 0) || (B.length - A.length));
  const leastLoaded = seg => { let best = seg[0], bl = Infinity; for (const d of seg) { const u = load[d] || 0; if (u < bl) { bl = u; best = d; } } return best; };
  for (const g of gl) {
    g.sort((x, y) => meta[x.id].p - meta[y.id].p);
    const days = daysIn(meta[g[0].id].a, meta[g[0].id].b), D = days.length, n = g.length;
    g.forEach((t, i) => {
      // 拆開的工作：區間切成 n 段，第 i 份放在第 i 段裡最空的那天（順序不會亂）
      const seg = n === 1 ? days : days.slice(Math.floor(i * D / n), Math.max(Math.floor(i * D / n) + 1, Math.floor((i + 1) * D / n)));
      t.date = leastLoaded(seg);
      load[t.date] = (load[t.date] || 0) + t.min;
    });
  }
  S.tasks.push(...ranged);
  [...new Set(ranged.map(n => n.date))].forEach(k => arrangeTimes(k, "fill"));
  // 那天時段排不下 → 換區間內其他還有空檔的日子
  for (const g of gl) {
    g.forEach((t0r, i) => {
      const t = S.tasks.find(x => x.id === t0r.id);
      if (!t || t.start != null) return;
      const lo = i > 0 ? g[i - 1].date : meta[t.id].a, hi = i < g.length - 1 ? g[i + 1].date : meta[t.id].b;
      const home = t.date;
      const cands = daysIn(lo, hi).filter(d => d !== home).sort((x, y) => (load[x] || 0) - (load[y] || 0) || (x < y ? -1 : 1));
      for (const d of cands) {
        t.date = d; arrangeTimes(d, "fill");
        if (t.start != null) { load[home] -= t.min; load[d] = (load[d] || 0) + t.min; t0r.date = d; return; }
      }
      t.date = home;
    });
  }

  // ---- 沒有指定日期的：照優先順序、截止日排 ----
  const r = plan(free, startDay);
  free.forEach(n => { n.date = r[n.id]; if (n.date === t0 && n.start != null && n.start <= nowMin()) n.date = addDays(t0, 1); });
  S.tasks.push(...free);
  [...new Set([...dated, ...free].map(n => n.date))].forEach(k => arrangeTimes(k, "fill"));
  // 當天時段放不下的，改排到之後有空的日子
  const still = free.map(n => S.tasks.find(t => t.id === n.id)).filter(t => t && t.start == null);
  if (still.length) {
    const r2 = plan(still, addDays(startDay, 1));
    still.forEach(t => { t.date = r2[t.id]; });
    [...new Set(still.map(t => t.date))].forEach(k => arrangeTimes(k, "fill"));
  }
  const src = {}; news.forEach((n, i) => { src[n.id] = { x: flat[i]._src || flat[i].title, c: flat[i].cat, m: flat[i].min, p: flat[i].pri, f: flat[i]._f || 1 }; });
  const out = news.map(n => {
    const o = { ...S.tasks.find(t => t.id === n.id) };
    o._src = src[n.id].x; o._pc = src[n.id].c; o._pm = src[n.id].m; o._pp = src[n.id].p; o._f = src[n.id].f;
    if (meta[n.id]) { const sd = k => { const d = parse(k); return `${d.getMonth() + 1}/${d.getDate()}`; }; o.window = `${sd(meta[n.id].a)}–${sd(meta[n.id].b)}`; };
    return o;
  });
  S.tasks = JSON.parse(backup);
  return out.sort((a, b) => a.date < b.date ? -1 : a.date > b.date ? 1 : (a.start ?? 9999) - (b.start ?? 9999));
}
async function runAI() {
  const sh = ui.sheet;
  const text = (document.getElementById("ai-text") || {}).value || sh.text || "";
  const files = sh.files || [];
  if (!text.trim() && !files.length) { const f = document.getElementById("ai-text"); if (f) f.focus(); return; }
  const key = llmKey();
  if (files.length && !key) {
    sh.text = text; sh.step = "error"; sh.detail = "";
    sh.error = "讀課表、PDF 和圖片需要 AI。請先到「設定」貼上 Gemini 金鑰（免費）或 Claude 金鑰，或把附件移除、只用文字排程。";
    renderSheet(); return;
  }
  sh.text = text; sh.note = "";
  if (!files.length) {
    // 文字：馬上用規則＋AI 小模型排好；有 Gemini 金鑰的話，同時在背景請 Gemini 看一遍，學起來給之後用
    sh.engine = "local"; sh.gem = null;
    try {
      // 先挑出「改時間、取消、做完了、沒做完」這種修改指令，其他的當成新的事
      const chg = [], rest = [];
      for (const line of text.split(/\n/)) { const c = line.trim() ? parseChange(line.trim()) : null; if (c) chg.push(c); else rest.push(line); }
      const newText = rest.join("\n");
      const items = newText.trim() ? aiParse(JSON.stringify(localParse(newText))) : [];
      if (!items.length && !chg.length) throw new Error("EMPTY");
      sh.changes = planChanges(chg);
      sh.csel = new Set(sh.changes.filter(c => !c.miss).map(c => c.id));
      sh.items = items.length ? aiSchedule(items) : [];
      sh.sel = new Set(sh.items.map(x => x.id));
      sh.step = "preview";
      if (key && items.length) { sh.gem = { state: "pending" }; gemBackground(sh, newText); }
    } catch (e) {
      sh.step = "error"; sh.detail = "";
      sh.error = String(e && e.message) === "EMPTY" ? "沒有找到可以排的事情，換個寫法再試一次。" : "排程失敗：" + String((e && e.message) || e).slice(0, 160);
      console.error(e);
    }
    renderSheet(); return;
  }
  sh.engine = "ai"; sh.step = "loading"; renderSheet();
  try {
    let items = null;
    if (key) {
      const ctrl = new AbortController();
      sh.abort = () => ctrl.abort();
      sh.started = Date.now();
      const tick = setInterval(() => { const el = document.getElementById("ai-secs"); if (el && ui.sheet === sh) el.textContent = Math.floor((Date.now() - sh.started) / 1000); }, 500);
      const timer = setTimeout(() => { sh.timedOut = true; ctrl.abort(); }, files.length ? AI_FILE_TIMEOUT_MS : AI_TIMEOUT_MS);
      try {
        const raw = await Promise.race([
          aiGenerate(aiPrompt(text || "（沒有文字，請讀附件）", files.length > 0), ctrl.signal, files),
          new Promise((_, rej) => ctrl.signal.addEventListener("abort", () => rej(new Error("TIMEOUT")), { once: true }))
        ]);
        items = aiParse(raw);
        // Gemini 的結果也套用「個人記憶」：你改過很像的句子，就照你的分類
        items.forEach(it => { try { const m = Brain.predict(it.title).mem; if (m && m.c) { const c = S.cats.find(x => x.name === m.c && !x.event); if (c && !it.isEv) it.cat = c.id; } } catch (e2) {} });
      } catch (e) {
        console.error(e);
        // 有附件時不能偷偷改用內建規則（內建規則看不懂圖片），要讓使用者知道
        if (files.length) {
          const msg = String(e && e.message || e);
          const err = new Error(/TIMEOUT/.test(msg) ? "AI 讀檔案太久沒有回應。可以把課表裁切成只剩表格、或過一下再試一次。" : aiErrorText(e));
          err.user = true; throw err;
        }
        sh.note = "";
        sh.engine = "local";
      } finally { clearTimeout(timer); clearInterval(tick); sh.abort = null; }
    }
    if (!items || !items.length) { if (items && !items.length && key) sh.engine = "local"; items = aiParse(JSON.stringify(localParse(text))); }
    if (!items.length) throw new Error("EMPTY");
    sh.items = aiSchedule(items);
    sh.sel = new Set(sh.items.map(x => x.id));
    sh.step = "preview";
  } catch (e) {
    sh.step = "error";
    sh.error = e && e.user ? e.message : String(e && e.message) === "EMPTY" ? "沒有找到可以排的事情，換個寫法再試一次。" : "排程失敗：" + String((e && e.message) || e).slice(0, 160);
    sh.detail = "";
    console.error(e);
  }
  if (ui.sheet === sh) renderSheet();
}

/* ---------- Gemini 在背景學習：結果存成之後訓練用的資料庫 ---------- */
/** 把 Gemini 的判斷記下來：輸入原文經過規則整理後的名稱 → 分類、要多久、固定事件、優先順序 */
function gemRemember(items) {
  const rows = [];
  for (const it of items) {
    const p = it.src ? parseLine(it.src) : null;
    const x = ((p && p.title) || it.title || "").trim();
    if (!x) continue;
    const c = cat(it.cat0 || it.cat);
    rows.push({ x: x.slice(0, 60), c: c && !c.event ? c.name : "", e: it.isEv || it.isEvRaw ? 1 : 0, m: p && p.minGiven ? 0 : it.min, p: it.pri });
  }
  if (!rows.length) return 0;
  const keys = new Set(rows.map(r => r.x.replace(/\s+/g, "")));
  S.settings.gemLog = [...(S.settings.gemLog || []).filter(L => !keys.has(String(L.x).replace(/\s+/g, ""))), ...rows].slice(-800);
  Brain.reset(); save();
  return rows.length;
}
/** 預覽裡有幾項跟 Gemini 的判斷不一樣 */
function gemDiff(preview, gems) {
  let d = 0;
  for (const g of gems) {
    const gx = bcNorm((g.src && (parseLine(g.src) || {}).title) || g.title);
    const pv = preview.find(t => bcNorm(t._src || t.title) === gx) || preview.find(t => { const a = bcNorm(t._src || t.title); return a && gx && (a.includes(gx) || gx.includes(a)); });
    if (!pv) { d++; continue; }
    if ((pv._pc || "") !== (g.cat || "") || Math.abs((pv._pm || 0) / (pv._f || 1) - g.min) > Math.max(15, g.min * 0.25)) d++;
  }
  return d + Math.max(0, preview.filter(t => !/（\d+\/\d+）$/.test(t.title)).length - gems.length);
}
async function gemBackground(sh, text) {
  const ctrl = new AbortController(), timer = setTimeout(() => ctrl.abort(), 90000);
  try {
    const raw = await aiGenerate(aiPrompt(text, false), ctrl.signal);
    const items = aiParse(raw);
    if (!items.length) throw new Error("EMPTY");
    const n = gemRemember(items);
    if (ui.sheet === sh && sh.step === "preview") {
      sh.gem = { state: "done", n, diff: gemDiff(sh.items, items), items };
      if (S.settings.aiAuto !== false && !sh.touched && sh.gem.diff) {
        const keep = document.querySelector("#sheet .sheetbody"), y = keep ? keep.scrollTop : 0;
        sh.localItems = sh.items; sh.items = aiSchedule(items); sh.sel = new Set(sh.items.map(x => x.id)); sh.engine = "ai"; sh.gem.state = "applied";
        renderSheet(); const b2 = document.querySelector("#sheet .sheetbody"); if (b2) b2.scrollTop = y;
      } else renderSheet();
    }
  } catch (e) {
    console.warn("gemini background", e);
    if (ui.sheet === sh && sh.step === "preview") { sh.gem = { state: "fail" }; renderSheet(); }
  } finally { clearTimeout(timer); }
}
function gemBarHTML(a) {
  const g = a.gem; if (!g) return "";
  const nm = llmName();
  if (g.state === "pending") return `<div class="gem-bar"><span class="spin" aria-hidden="true"></span>${nm} 正在想…${S.settings.aiAuto !== false ? "想好會自動更新（你先改了就不會蓋掉）" : "（不用等，可以直接加入）"}</div>`;
  if (g.state === "fail") return `<div class="gem-bar muted">${nm} 這次沒有回應，先用內建的判斷。</div>`;
  if (g.state === "applied") return `<div class="gem-bar">${I.spark}已換成 ${nm} 的判斷${a.localItems ? `<button class="btn sm" data-act="ai-use-local">改回內建的</button>` : ""}</div>`;
  return g.diff ? `<div class="gem-bar">${I.spark}${nm} 看完了，有 ${g.diff} 項跟現在不一樣<button class="btn sm" data-act="ai-use-gem">改用 ${nm} 的版本</button></div>`
    : `<div class="gem-bar">${I.check}${nm} 看完了，判斷一樣</div>`;
}
/** 每天一次：挑小模型比較沒把握的工作名稱，請 Gemini 標註，加進資料庫 */
async function gemBackfill() {
  const s = S.settings, key = (s.geminiKey || "").trim();
  if (!key || !FB.loaded || S.sample || s.gemBackfillDay === today() || document.visibilityState !== "visible") return;
  s.gemBackfillDay = today(); save();
  const known = new Set([...(s.gemLog || []), ...(s.learnLog || [])].map(L => bcNorm(L.x)));
  const pool = [...new Set(S.tasks.slice(-400).map(t => (t.wname || t.title).replace(/（\d+\/\d+）$/, "").trim()))].filter(x => x && !known.has(bcNorm(x)));
  const pick = pool.map(x => { let p = 1; try { p = Brain.predict(x).catP; } catch (e) {} return { x, p }; }).sort((a, b) => a.p - b.p).slice(0, 25).map(o => o.x);
  if (pick.length < 3) return;
  const cats = S.cats.filter(c => !c.event).map(c => c.name).join("、");
  const prompt = `下面每一行是一個待辦事項的名稱。請判斷每一項：分類（只能用：${cats}；約會、聚餐、私人娛樂用「其他」）、是不是要準時出席的固定事件（上課、開會、看診、考試）、通常要花幾分鐘、優先順序 0-3（一般給 1）。
輸出 JSON：{"tasks":[{"src":"照抄那一行","title":"同 src","category":"分類","isEvent":true或false,"minutes":整數,"priority":整數}]}
${pick.join("\n")}`;
  try {
    const raw = await aiGenerate(prompt, null);
    gemRemember(aiParse(raw));
  } catch (e) { console.warn("gemini backfill", e); }
}

/* ---------- 智慧排法：一件工作拆成好幾段，分散排到截止日前 ---------- */
const WORK_CHIPS = [60, 120, 180, 240, 360, 480, 600];
const DEFAULT_EST_TYPES = [
  { n: "作業", h: 4, kw: "作業|習題|hw|homework|assignment" },
  { n: "報告", h: 8, kw: "報告|簡報|投影片|presentation|論文|paper|proposal" },
  { n: "考試準備", h: 10, kw: "考試|期中|期末|小考|準備考|複習|exam|quiz|midterm|final" },
  { n: "其他", h: 2, kw: "" }
];
const estTypes = () => (Array.isArray(S.settings.estTypes) && S.settings.estTypes.length ? S.settings.estTypes : DEFAULT_EST_TYPES);
function chunkLimits() {
  const s = S.settings;
  const mx = Math.max(15, Math.min(480, +s.chunkMax || 120));
  const mn = Math.max(5, Math.min(mx, +s.chunkMin || 30));
  return { mx, mn };
}
/** 分鐘 → 小時文字：90 → "1.5"、120 → "2" */
const hrsTxt = m => { const h = Math.round(m / 6) / 10; return Number.isInteger(h) ? String(h) : h.toFixed(1); };
const workChunks = wid => S.tasks.filter(t => t.wid === wid).sort((a, b) => a.date < b.date ? -1 : a.date > b.date ? 1 : (a.start ?? 9999) - (b.start ?? 9999));
function workProgress(wid) {
  const l = workChunks(wid);
  return { list: l, total: l.reduce((a, t) => a + t.min, 0), done: l.filter(t => t.done).reduce((a, t) => a + t.min, 0), n: l.length, nd: l.filter(t => t.done).length, name: l[0] ? l[0].wname : "", deadline: l[0] ? l[0].deadline : null };
}
function renumberWork(wid) {
  const l = workChunks(wid);
  l.forEach((t, i) => { t.title = l.length > 1 ? `${t.wname}（${i + 1}/${l.length}）` : t.wname; });
}
/** 沒做完的段落：之前的日子、或今天已經過了時段還沒打勾 */
function missedChunks(wid) {
  const t0 = today(), now = nowMin();
  return workChunks(wid).filter(t => !t.done && (t.date < t0 || (t.date === t0 && t.start != null && t.start + t.min <= now)));
}
function workLineHTML(wid) {
  const p = workProgress(wid);
  const pct = p.total ? Math.round(p.done / p.total * 100) : 0;
  return `<div class="wline"><span class="wbar" aria-hidden="true"><i style="width:${pct}%"></i></span><span>${esc(p.name)}：已完成 ${hrsTxt(p.done)}/${hrsTxt(p.total)} 小時</span></div>`;
}

/** 從哪天排到哪天：今天（太晚就明天）～截止日前一天 */
function workDays(deadline) {
  const s = S.settings, { mn } = chunkLimits(), t0 = today();
  if (!deadline || deadline < t0) return [];
  const start = nowMin() > s.workEnd - mn ? addDays(t0, 1) : t0;
  let end = addDays(deadline, -1);
  if (end < start) end = deadline;            // 截止日就是今天或明天：只能排在截止日當天
  const out = [];
  for (let d = start; d <= end && out.length < 366; d = addDays(d, 1)) if (!(s.skipWeekends && isWeekend(d))) out.push(d);
  return out;
}
/** 某一天的空檔：工作時段內，避開午休、已經有時段的事（前後留休息間隔） */
function dayFree(k, excl, extra) {
  const s = S.settings, gap = s.gap || 0;
  let from = s.workStart;
  if (k === today()) from = Math.max(from, Math.ceil((nowMin() + 5) / 5) * 5);
  const busy = [];
  for (const [a, b] of breaks()) busy.push([a, b]);
  for (const t of S.tasks) if (t.date === k && t.start != null && !t.cancelled && !excl.has(t.id)) busy.push([t.start - gap, t.start + t.min + gap]);
  for (const b of ((extra && extra[k]) || [])) busy.push([b[0] - gap, b[1] + gap]);
  busy.sort((a, b) => a[0] - b[0]);
  const free = [];
  let cur = from;
  for (const [a, b] of busy) {
    if (cur >= s.workEnd) break;
    if (a > cur) free.push([cur, Math.min(a, s.workEnd)]);
    cur = Math.max(cur, b);
  }
  if (cur < s.workEnd) free.push([cur, s.workEnd]);
  return free.map(([a, b]) => [Math.ceil(a / 5) * 5, b]).filter(([a, b]) => b - a >= 5);
}
/** 截止日前總共還有多少空檔（扣掉每天已經排的量） */
function workCapacity(deadline, excl = new Set()) {
  const { mn } = chunkLimits(), cap = dayCap(), load = loadMap(excl);
  let sum = 0;
  for (const d of workDays(deadline)) {
    const room = Math.max(0, cap - (load[d] || 0));
    const fr = dayFree(d, excl, null).reduce((a, [x, y]) => a + (y - x >= Math.min(mn, room) ? y - x : 0), 0);
    sum += Math.min(room, fr);
  }
  return sum;
}
/**
 * 把 total 分鐘拆段，平均分散到截止日前的日子，每段排進具體時段。
 * 不超過每天可用時間、不跟有時段的事重疊。排不下的不硬塞，回傳 short（還差幾分鐘）。
 */
function splitPlan(total, deadline, excl = new Set(), wid = null, habitCat = "") {
  const { mx, mn } = chunkLimits(), cap = dayCap();
  const allDays = workDays(deadline);
  // 有 3 天以上：先排在截止日前一天以前，最後一天留著當緩衝（真的排不下才用）
  const days = allDays.length >= 3 ? allDays.slice(0, -1) : allDays, D = days.length;
  total = Math.max(5, Math.round(total / 5) * 5);
  if (!D) return { chunks: [], short: total, days: 0 };
  const load = loadMap(excl), extra = {}, used = {}, chunks = [];
  if (wid) S.tasks.forEach(t => { if (t.wid === wid && !t.done && !excl.has(t.id)) used[t.date] = (used[t.date] || 0) + 1; });
  let short = 0;
  const n = Math.max(1, Math.ceil(total / mx));
  const sizes = Array(n).fill(Math.floor(total / n / 5) * 5);
  for (let rem = total - sizes[0] * n, i = 0; rem > 0; i = (i + 1) % n) { sizes[i] += 5; rem -= 5; }
  const fits = (d, size) => {
    if ((load[d] || 0) + size > cap) return null;
    const cands = [];
    for (const [a, b] of dayFree(d, excl, extra)) for (let st = a; st + size <= b && cands.length < 120; st = Math.ceil((st + 15) / 15) * 15) cands.push(st);
    return pickStart({ cat: habitCat, min: size }, cands);
  };
  const put = (d, st, size) => {
    chunks.push({ date: d, start: st, min: size });
    (extra[d] = extra[d] || []).push([st, st + size]);
    load[d] = (load[d] || 0) + size; used[d] = (used[d] || 0) + 1;
  };
  // 同一件事盡量不要排在同一天；再來挑最空的；一樣空就挑早的
  const order = list => [...list].sort((x, y) => (used[x] || 0) - (used[y] || 0) || (load[x] || 0) - (load[y] || 0) || (x < y ? -1 : 1));
  const queue = sizes.map((v, i) => ({ v, i }));
  while (queue.length) {
    const p = queue.shift();
    let seg = days;
    if (p.i != null && n > 1) {
      // 把區間切成 n 段，第 i 段只放第 i 份 → 不會全部擠在前面或最後一天
      const a = Math.floor(p.i * D / n), b = Math.max(a + 1, Math.floor((p.i + 1) * D / n));
      seg = days.slice(a, b);
    }
    let placed = false;
    for (const list of [seg, days, allDays]) {
      for (const d of order(list)) { const st = fits(d, p.v); if (st != null) { put(d, st, p.v); placed = true; break; } }
      if (placed) break;
    }
    if (placed) continue;
    // 整段放不下 → 找最大的空檔先放一部分（至少一段最短的長度），剩下的再找地方
    let best = null;
    for (const d of allDays) {
      const room = cap - (load[d] || 0);
      for (const [a, b] of dayFree(d, excl, extra)) {
        const L = Math.floor(Math.min(b - a, room, p.v) / 5) * 5;
        if (L >= Math.min(mn, p.v) && (!best || L > best.L)) best = { d, st: a, L };
      }
    }
    if (best) { put(best.d, best.st, best.L); if (p.v - best.L > 0) queue.unshift({ v: p.v - best.L, i: null }); }
    else short += p.v;
  }
  chunks.sort((a, b) => a.date < b.date ? -1 : a.date > b.date ? 1 : a.start - b.start);
  return { chunks, short, days: allDays.length };
}

/** 沒填總時數 → 估時間：自己過去的平均 > 類型預設；截止日太近就估排得下的量 */
function estTypeFor(title, catId) {
  const types = estTypes(), c = cat(catId);
  let ty = c && types.find(x => x.n === c.name);
  if (!ty) ty = types.find(x => x.kw && (() => { try { return new RegExp(x.kw, "i").test(title); } catch (e) { return title.includes(x.n); } })());
  return ty || types.find(x => x.n === "其他") || { n: "其他", h: 2 };
}
function estimateWork(title, catId, deadline) {
  const ty = estTypeFor(title, catId);
  const log = (S.settings.estLog || []).filter(x => x.n === ty.n).slice(-10);
  let m, basis;
  if (log.length) {
    const avg = log.reduce((a, x) => a + x.m, 0) / log.length;
    m = Math.max(15, Math.round(avg / 15) * 15);
    basis = `你之前做過 ${log.length} 件「${ty.n}」，實際平均花 ${dur(Math.round(avg / 5) * 5)}（預設是 ${hrsTxt(ty.h * 60)} 小時）`;
  } else {
    m = Math.max(15, Math.round(ty.h * 60 / 15) * 15);
    basis = `依「${ty.n}」的預設時數 ${hrsTxt(m)} 小時（設定裡可以改；做完記錄實際時間後會越估越準）`;
  }
  const capm = workCapacity(deadline);
  let capped = false;
  if (capm > 0 && m > capm) {
    const was = m;
    m = Math.max(Math.min(chunkLimits().mn, capm), Math.floor(capm / 15) * 15);
    capped = true;
    basis += `。不過截止日前只剩 ${hrsTxt(capm)} 小時空檔，排不下 ${hrsTxt(was)} 小時，所以先估 ${hrsTxt(m)} 小時`;
  }
  return { m, basis, type: ty.n, capped };
}
const pieceCount = m => Math.max(1, Math.ceil(m / chunkLimits().mx));

/* ---- 視窗 ---- */
function openWork(o) {
  const t0 = today();
  ui.sheet = null;
  openSheet({ type: "work", step: "input", mode: "new", name: "", total: 240, auto: false, deadline: addDays(t0, 7), cat: "", pri: 1, notes: "", done: {}, ...o });
}
function wkRead(w) {
  const $ = id => document.getElementById(id);
  if ($("wk-name")) w.name = $("wk-name").value.trim();
  if ($("wk-dl") && $("wk-dl").value) w.deadline = $("wk-dl").value;
  if ($("wk-cat")) w.cat = $("wk-cat").value;
  if ($("wk-notes")) w.notes = $("wk-notes").value;
  const pr = document.querySelector('#sheet input[name="wk-pri"]:checked'); if (pr) w.pri = +pr.value;
  const g = document.querySelector('#sheet [data-durgroup="wk"]'); if (g) w.total = readDur(g, 12000);
}
function sheetWork(w) {
  const { mx, mn } = chunkLimits();
  const durBig = (min, attrs) => durPickHTML(min, attrs, null, WORK_CHIPS, 199);
  if (w.step === "estimate") {
    const n = pieceCount(w.total);
    const body = `<div class="est-card"><div class="big">我估這件事大約要 <b>${hrsTxt(w.total)} 小時</b>，分成 <b>${n} 段</b></div>
        <div class="basis">${esc(w.est.basis)}</div></div>
      <div class="form"><div class="field col durfield" data-durgroup="wk"><span class="lab">覺得不對可以直接改</span>${durBig(w.total, 'data-dur="wk"')}</div></div>
      <button class="btn primary block" data-act="wk-plan">${I.check}確認，幫我排進行程</button>
      <button class="btn" data-act="wk-back" style="align-self:flex-start">上一步</button>`;
    return sheetWrap("估計時間", cancelBtn(), spacer, body);
  }
  if (w.step === "preview") {
    const ch = w.plan.chunks, N = ch.length, planned = ch.reduce((a, c) => a + c.min, 0);
    const pool = [...S.tasks.filter(t => !w.excl.has(t.id)), ...ch.map((c, i) => ({ id: "wkc" + i, title: `${w.name}（第 ${i + 1} 段）`, date: c.date, start: c.start, min: c.min }))];
    const doneOf = t => w.excl.has(t.id) ? Math.min(t.min, w.done[t.id] || 0) : t.min;   // 沒做完但做了一部分的，會留下「已做的時間」
    const existing = w.wid ? workChunks(w.wid).filter(t => doneOf(t) > 0) : [];
    const totalAll = existing.reduce((a, t) => a + doneOf(t), 0) + planned;
    // 預覽的編號跟套用後一樣：連同已經排好的段落一起排序
    const allSeq = [...existing.map(t => ({ date: t.date, start: t.start ?? 9999, i: -1 })), ...ch.map((c, i) => ({ date: c.date, start: c.start, i }))]
      .sort((a, b) => a.date < b.date ? -1 : a.date > b.date ? 1 : a.start - b.start);
    const label = i => allSeq.length > 1 ? `${w.name}（${allSeq.findIndex(x => x.i === i) + 1}/${allSeq.length}）` : w.name;
    const head = w.mode === "new"
      ? `<b>${esc(w.name)}</b>・共 ${hrsTxt(planned)} 小時・分成 ${N} 段・截止 ${md(w.deadline)}`
      : `<b>${esc(w.name)}</b>・${w.mode === "extra" ? "多加" : "重新安排"} ${hrsTxt(w.need)} 小時・截止 ${md(w.deadline)}<br><small>排好後整件事共 ${hrsTxt(totalAll)} 小時</small>`;
    const shortBox = w.plan.short > 0 ? `<div class="shortbox">
        <div class="t">${I.alert}截止日前的空檔不夠，還差 ${hrsTxt(w.plan.short)} 小時</div>
        <p>沒有硬塞進去。你可以：</p>
        <div class="field"><label for="wk-dl2">把截止日改到</label><input type="date" id="wk-dl2" min="${today()}" value="${w.deadline}"><button class="btn sm" data-act="wk-redl">重新計算</button></div>
        <div class="btnrow">${w.mode === "replan" ? "" : `<button class="btn sm" data-act="wk-back">改時數</button>`}<button class="btn sm" data-act="wk-recalc">我移開了別的事，重新計算</button></div>
        <p class="small">也可以先按右上角「套用」，把排得下的 ${hrsTxt(planned)} 小時排進去，之後再用「還需要更多時間」補。</p></div>` : "";
    const cards = ch.map((c, i) => {
      const cf = conflictsFor({ id: "wkc" + i, date: c.date, start: c.start, min: c.min }, pool);
      return `<div class="pv-card">
        <div class="pv-top"><span class="wk-no">${i + 1}</span><strong class="pv-name">${esc(label(i))}</strong></div>
        <div class="pv-grid">
          <label>日期<input type="date" min="${today()}" max="${w.deadline}" value="${c.date}" data-wkf="date" data-i="${i}"></label>
          <label>開始時間<input type="time" step="300" value="${hm(c.start)}" data-wkf="start" data-i="${i}"></label>
          <div class="pv-dur durfield" data-durgroup="wkc" data-i="${i}"><span>這一段</span>${durPickHTML(c.min, `data-dur="wkc" data-i="${i}"`)}</div>
        </div>
        <div class="ai-when">${rel(c.date)}　${hm(c.start)}–${hm(c.start + c.min)}${c.date > addDays(w.deadline, -1) ? `<span class="pv-win">截止日當天</span>` : ""}</div>
        ${cf.length ? `<div class="conflict">⚠ ${esc(conflictText(cf))}</div>` : ""}
        <button class="btn sm" data-act="wk-del" data-i="${i}" style="align-self:flex-start">刪掉這段</button>
      </div>`;
    }).join("");
    const body = `<div class="est-card"><div class="big" style="font-size:15px">${head}</div>
        <div class="basis">從今天排到截止日前一天，平均分散到不同天，每天不超過可用時間 ${dur(dayCap())}，也避開已經有時段的事。每一段都可以先改再套用。</div></div>
      ${shortBox}
      ${N ? cards : `<p class="footnote">截止日前沒有可以排的空檔。</p>`}
      ${w.mode === "new" ? `<button class="btn" data-act="wk-back" style="align-self:flex-start">修改內容</button>` : ""}`;
    return sheetWrap("排程預覽", cancelBtn(), `<button class="strong" data-act="wk-apply"${N ? "" : " disabled"}>套用</button>`, body);
  }
  if (w.mode === "extra") {
    const p = workProgress(w.wid);
    const body = `<div class="est-card"><div class="big">${esc(p.name)}</div>${workLineHTML(w.wid)}<div class="basis">截止 ${md(p.deadline)}。多加的時間會排進截止日前的空檔，不夠的話會提醒你。</div></div>
      <div class="form"><div class="field col durfield" data-durgroup="wk"><span class="lab">還需要多少時間</span>${durBig(w.total, 'data-dur="wk"')}</div></div>
      <button class="btn primary block" data-act="wk-plan">${I.wand}排進截止日前的空檔</button>`;
    return sheetWrap("還需要更多時間", cancelBtn(), spacer, body);
  }
  if (w.mode === "replan") {
    const miss = missedChunks(w.wid), p = workProgress(w.wid);
    const body = `<div class="est-card"><div class="big">${esc(p.name)}</div>${workLineHTML(w.wid)}<div class="basis">這些段落沒有做完。有做一部分的話填一下，只會把「剩下的時數」排進之後的空檔，一樣在截止日 ${md(p.deadline)} 前。</div></div>
      ${miss.map(t => `<div class="pv-card"><div class="pv-top"><strong class="pv-name">${esc(t.title)}</strong></div>
        <div class="ai-when">原本 ${rel(t.date)} ${t.start != null ? range(t) : ""}・${dur(t.min)}</div>
        <div class="field col durfield" data-durgroup="wkdone" data-id="${t.id}"><span class="lab">已經做了</span>${durPickHTML(w.done[t.id] || 0, `data-dur="wkdone" data-id="${t.id}"`, null, [0, 30, 60, 90])}</div></div>`).join("")}
      ${miss.length ? `<button class="btn primary block" data-act="wk-plan">${I.wand}把剩下的時數排進之後的空檔</button>` : `<p class="footnote">目前沒有沒做完的段落。</p>`}`;
    return sheetWrap("重新安排", cancelBtn(), spacer, body);
  }
  // 新增：只要名稱、總時數（可不填）、截止日
  const cats = S.cats.filter(c => !c.event);
  const body = `<div class="form">
      <div class="field"><input type="text" id="wk-name" placeholder="工作名稱，例如：熱傳報告" value="${esc(w.name)}" maxlength="60" aria-label="工作名稱"></div>
    </div>
    <section class="sec"><div class="sechead"><h2>總共要花多久</h2></div><div class="form">
      <div class="field col"><div class="seg" role="radiogroup" aria-label="總時數">
        <label><input type="radio" name="wk-auto" data-act="wk-auto" data-v="0"${w.auto ? "" : " checked"}><span>我自己填</span></label>
        <label><input type="radio" name="wk-auto" data-act="wk-auto" data-v="1"${w.auto ? " checked" : ""}><span>不確定，幫我估</span></label></div></div>
      ${w.auto ? `<div class="field"><span class="lab" style="font-weight:400;font-size:14px">下一步會依分類、你過去實際花的時間和離截止日幾天來估，估完可以改。</span></div>`
        : `<div class="field col durfield" data-durgroup="wk"><span class="lab">總時數</span>${durBig(w.total, 'data-dur="wk"')}</div>`}
    </div><p class="footnote">超過 ${dur(mx)} 會自動拆成好幾段（每段 ${dur(mn)}～${dur(mx)}，可以在「設定 › 智慧排法」改）。</p></section>
    <section class="sec"><div class="sechead"><h2>截止日</h2></div><div class="form">
      <div class="field"><label for="wk-dl">截止日</label><input type="date" id="wk-dl" min="${today()}" value="${w.deadline}"></div>
    </div><p class="footnote">會從今天排到截止日前一天，平均分散到不同天，每一段都排進具體時段。</p></section>
    <section class="sec"><div class="sechead"><h2>選填</h2></div><div class="form">
      <div class="field"><label for="wk-cat">分類</label><select id="wk-cat"><option value="">無</option>${cats.map(c => `<option value="${c.id}"${c.id === w.cat ? " selected" : ""}>${esc(c.name)}</option>`).join("")}</select></div>
      <div class="field col"><div class="seg" role="radiogroup" aria-label="優先順序">${PRI.map((p, i) => `<label><input type="radio" name="wk-pri" value="${i}"${i === w.pri ? " checked" : ""}><span>${p}</span></label>`).join("")}</div></div>
      <div class="field"><textarea id="wk-notes" rows="2" placeholder="備註（選填）" aria-label="備註">${esc(w.notes)}</textarea></div>
    </div></section>
    <button class="btn primary block" data-act="wk-next">${I.spark}${w.auto ? "幫我估時間" : "排進行程（先預覽）"}</button>`;
  return sheetWrap("智慧排法", cancelBtn(), spacer, body);
}
function wkCompute(w) {
  if (w.mode === "new") { w.excl = new Set(); w.need = w.total; }
  else if (w.mode === "extra") { w.excl = new Set(); w.need = w.total; }
  else {
    const miss = missedChunks(w.wid);
    w.excl = new Set(miss.map(t => t.id));
    w.need = miss.reduce((a, t) => a + Math.max(0, t.min - Math.min(t.min, w.done[t.id] || 0)), 0);
  }
  w.plan = w.need > 0 ? splitPlan(w.need, w.deadline, w.excl, w.wid || null, w.wid ? (workChunks(w.wid)[0] || {}).cat : w.cat) : { chunks: [], short: 0, days: 0 };
  w.step = "preview";
}
function wkApply(w) {
  snapshot();
  let wid = w.wid, base = wid ? workChunks(wid)[0] : null;
  if (w.mode === "replan") {
    for (const t of missedChunks(wid)) {
      const d = Math.min(t.min, w.done[t.id] || 0);
      if (d > 0) { t.min = d; t.done = true; t.doneOn = t.date < today() ? t.date : today(); }
      else S.tasks = S.tasks.filter(x => x.id !== t.id);
    }
  }
  if (!wid) wid = uid();
  const proto = base ? { notes: base.notes, pri: base.pri, cat: base.cat, wname: base.wname, wtype: base.wtype || "其他" }
    : { notes: w.notes || "", pri: w.pri, cat: w.cat || "", wname: w.name, wtype: w.est ? w.est.type : estTypeFor(w.name, w.cat).n };
  for (const c of w.plan.chunks) {
    S.tasks.push({ id: uid(), title: proto.wname, notes: proto.notes, date: c.date, deadline: w.deadline, pri: proto.pri, min: c.min, cat: proto.cat,
      done: false, doneOn: null, resched: 0, created: Date.now(), start: c.start, locked: false, series: null, occ: null, detached: false,
      wid, wname: proto.wname, wtype: proto.wtype });
  }
  renumberWork(wid);
  const short = w.plan.short;
  closeSheet();
  commit(`已排好「${proto.wname}」${w.plan.chunks.length} 段${short > 0 ? `，還差 ${hrsTxt(short)} 小時沒排進去` : ""}`, true);
}
/** 自動模式：沒做完的段落，直接把剩下的時數排進截止日前的空檔（不跳預覽） */
function autoReplanWork(wid) {
  const miss = missedChunks(wid);
  if (!miss.length) return { moved: 0, short: 0 };
  const p = workProgress(wid);
  const excl = new Set(miss.map(t => t.id));
  const need = miss.reduce((a, t) => a + t.min, 0);
  const plan = splitPlan(need, p.deadline || today(), excl, wid, miss[0].cat);
  const base = miss[0];
  S.tasks = S.tasks.filter(t => !excl.has(t.id));
  for (const c of plan.chunks) S.tasks.push({ ...base, id: uid(), date: c.date, start: c.start, min: c.min, locked: false, done: false, doneOn: null, resched: base.resched + 1, created: Date.now() });
  renumberWork(wid);
  return { moved: miss.length, short: plan.short, name: p.name };
}
/** 整件事都做完 → 問實際花了多久（記錄下來，之後估得更準） */
function sheetActual(a) {
  const p = workProgress(a.wid);
  const body = `<div class="est-card"><div class="big">「${esc(p.name)}」全部完成了！</div>
      <div class="basis">原本排了 ${hrsTxt(p.total)} 小時。實際總共花了多久？記下來之後，下次估「${esc((p.list[0] && p.list[0].wtype) || "其他")}」會更準。</div></div>
    <div class="form"><div class="field col durfield" data-durgroup="act"><span class="lab">實際花的時間</span>${durPickHTML(a.min ?? p.total, 'data-dur="act"', null, WORK_CHIPS, 199)}</div></div>
    <button class="btn primary block" data-act="act-save">${I.check}記錄</button>`;
  return sheetWrap("做完了", `<button data-act="close">略過</button>`, spacer, body);
}
function afterToggle(t) {
  if (!t || !t.done || !t.wid) return;
  const p = workProgress(t.wid);
  if (p.n && p.nd === p.n) setTimeout(() => { if (!ui.sheet) openSheet({ type: "actual", wid: t.wid }); }, 350);
}
function estSettingsHTML() {
  const s = S.settings, { mx, mn } = chunkLimits(), types = estTypes(), log = s.estLog || [];
  return `<section class="sec"><div class="sechead"><h2>智慧排法</h2></div><div class="form">
    <div class="field col durfield" data-durgroup="cmax"><span class="lab">每段最長</span>${durPickHTML(mx, 'data-dur="chunkMax"', null, [60, 90, 120, 150, 180, 240])}</div>
    <div class="field col durfield" data-durgroup="cmin"><span class="lab">每段最短</span>${durPickHTML(mn, 'data-dur="chunkMin"', null, [15, 30, 45, 60, 90])}</div>
  </div><p class="footnote">新增工作時選「智慧排法」，只要填總時數和截止日，超過「每段最長」就自動拆段，分散排到截止日前。</p></section>
  <section class="sec"><div class="sechead"><h2>沒填時數時的預設估計</h2></div><div class="form">
    ${types.map((ty, i) => { const L = log.filter(x => x.n === ty.n); const avg = L.length ? L.slice(-10).reduce((a, x) => a + x.m, 0) / Math.min(10, L.length) : 0;
      return `<div class="field"><span class="lab" style="flex:1">${esc(ty.n)}<small class="sub">${L.length ? `已記錄 ${L.length} 件，平均實際 ${hrsTxt(avg)} 小時，會優先用這個` : ty.kw ? `分類叫「${esc(ty.n)}」，或名稱有「${esc(ty.kw.split("|").slice(0, 3).join("、"))}」` : "其他對不到的"}</small></span>
        <span class="durpick"><input type="number" inputmode="decimal" min="0.5" max="200" step="0.5" value="${ty.h}" data-esth="${i}" aria-label="${esc(ty.n)} 預設小時"><span>小時</span></span>
        ${ty.n !== "其他" ? `<button class="x" data-act="est-del" data-i="${i}">刪除</button>` : ""}</div>`; }).join("")}
    <div class="field"><input type="text" id="est-new-n" placeholder="新增類型，例如：實驗" maxlength="10" style="flex:1;min-width:0;border:0;background:var(--surface-2);border-radius:8px;padding:8px 10px" aria-label="新類型名稱">
      <span class="durpick"><input type="number" inputmode="decimal" id="est-new-h" min="0.5" max="200" step="0.5" value="3" aria-label="小時"><span>小時</span></span>
      <button class="btn primary" data-act="est-add">新增</button></div>
  </div><p class="footnote">先看工作的分類名稱，對不到再看名稱裡的關鍵字。每件工作做完時記下實際花的時間，之後會改用你的平均，估得越來越準。</p></section>`;
}

/* ===================== 從「排程小幫手」整合過來的功能 ===================== */

/* ---------- 日期列：今天頁最上面左右滑選日期 ---------- */
function stripHTML(sel) {
  const t = today(), start = addDays(t, -3), n = Math.max(28, diff(start, sel) + 8);
  const byDay = {};
  for (const x of S.tasks) if (!x.done) (byDay[x.date] = byDay[x.date] || []).push(x);
  const dl = new Set(S.tasks.filter(x => !x.done && x.deadline).map(x => x.deadline));
  let h = `<nav class="dstrip" id="dstrip" aria-label="選日期">`;
  for (let i = 0; i < n; i++) {
    const k = addDays(start, i), d = parse(k), list = (byDay[k] || []).filter(x => !isEvent(x));
    const cls = `dp${k === t ? " today" : ""}${k === sel ? " sel" : ""}${k < t ? " past" : ""}`;
    h += `<button class="${cls}" data-act="strip-day" data-date="${k}" aria-label="${md(k)}${list.length ? `，${list.length} 項` : ""}${dl.has(k) ? "，有截止日" : ""}">
      ${dl.has(k) ? `<span class="dl" aria-hidden="true"></span>` : ""}<span class="w">${k === t ? "今天" : "週" + WD[d.getDay()]}</span><span class="n num">${d.getDate()}</span>
      <span class="c">${list.length ? `<i style="width:${Math.min(100, openMinutes(list) / Math.max(dayCap(), 1) * 100)}%"></i>` : ""}</span></button>`;
  }
  return h + `</nav>`;
}
/** 畫面換了之後，把選到的日期捲到中間（或維持使用者捲到的位置） */
function syncStrip(jump) {
  const st = document.getElementById("dstrip"); if (!st) return;
  const b = st.querySelector(".sel");
  if (!jump && ui.stripX != null) { st.scrollLeft = ui.stripX; return; }
  if (b) st.scrollLeft = b.offsetLeft - st.clientWidth / 2 + b.offsetWidth / 2;
  ui.stripX = st.scrollLeft;
}
document.addEventListener("scroll", e => { if (e.target && e.target.id === "dstrip") ui.stripX = e.target.scrollLeft; }, true);
/** 在今天頁看別天：那天的固定事件和工作 */
function dayPanelHTML(k) {
  const t = today(), list = onDay(k).filter(x => !isEvent(x)), evs = eventsOn(k), mins = openMinutes(list), cap = dayCap();
  const dls = S.tasks.filter(x => !x.done && x.deadline === k);
  const dh = `<div class="dayhead2"><div><strong>${full(k)}</strong><small>${rel(k) === md(k) ? `${diff(t, k) > 0 ? diff(t, k) + " 天後" : -diff(t, k) + " 天前"}` : rel(k)}・<span class="${mins > cap ? "over" : ""}">已排 ${dur(mins)} / ${dur(cap)}</span></small></div>
    <button class="btn sm" data-act="strip-day" data-date="${t}">回到今天</button></div>
    ${dls.length ? `<div class="duechips">${dls.map(x => `<button class="chip-due" data-act="edit" data-id="${x.id}">截止：${esc(x.wname || x.title)}</button>`).join("")}</div>` : ""}`;
  if (ui.todayMode === "timeline") return `<section class="sec main">${dh}</section>` + timelineHTML(k);
  if (ui.todayMode === "grid") return `<section class="sec main">${dh}</section>` + gridHTML(k);
  const openL = list.filter(x => !x.done);
  let h = `<section class="sec main">${dh}
    ${evs.length ? `<div class="subhead"><h3>固定事件</h3></div><div class="list">${evs.map(x => rowHTML(x)).join("")}</div>` : ""}
    ${otBannerHTML(k)}
    <div class="subhead"><h3>要做的事</h3><span class="aside">${openL.length} 項</span></div><div class="list">
    ${openL.length ? openL.map(x => rowHTML(x)).join("") : list.length ? `<div class="empty">這天的工作都做完了 🎉</div>` : `<div class="empty">這天還沒有安排。按右上角 ＋，或用「智慧排程」跟我說。</div>`}</div></section>`;
  return h + doneFolderHTML(k);
}

/* ---------- 作息設定（第一次使用時跳出來，之後在設定裡改） ---------- */
function weeklyFixed() {
  return S.series.filter(x => x.freq === "weekly" && x.start != null && (cat(x.cat) || {}).event && (!x.until || x.until >= today()));
}
function sheetSetup(st) {
  const s = S.settings, rows = weeklyFixed().slice().sort((a, b) => ((a.weekdays || [])[0] ?? 0) - ((b.weekdays || [])[0] ?? 0) || a.start - b.start);
  const wdTxt = x => (x.weekdays && x.weekdays.length ? x.weekdays : [parse(x.anchor).getDay()]).map(w => "週" + WD[w]).join("、");
  const body = `${st.first ? `<div class="est-card"><div class="big">歡迎使用排程本 👋</div><div class="basis">先告訴我你的作息，只要設定一次，之後自動排時間都會照這個走。跳過也可以，之後在「設定 › 作息設定」改。</div></div>` : ""}
    <section class="sec"><div class="sechead"><h2>每天做事的時間</h2></div><div class="form">
      <div class="field"><label for="su-ws">幾點開始做事</label><input type="time" id="su-ws" step="300" value="${hm(s.workStart)}"></div>
      <div class="field"><label for="su-we">最晚幾點收工</label><input type="time" id="su-we" step="300" value="${hm(s.workEnd)}"></div>
    </div></section>
    <section class="sec"><div class="sechead"><h2>吃飯時間（不會排工作）</h2></div><div class="form">
      <div class="field"><label for="su-l">午餐</label><span class="switch"><input type="checkbox" id="su-l"${s.breakOn ? " checked" : ""}><span></span></span></div>
      <div class="field col"><label for="su-ls" class="lab">午餐時間</label><span class="trange"><input type="time" id="su-ls" step="300" value="${hm(s.breakStart)}"><span>–</span><input type="time" id="su-le" step="300" value="${hm(s.breakEnd)}"></span></div>
      <div class="field"><label for="su-d">晚餐</label><span class="switch"><input type="checkbox" id="su-d"${s.dinnerOn ? " checked" : ""}><span></span></span></div>
      <div class="field col"><label for="su-ds" class="lab">晚餐時間</label><span class="trange"><input type="time" id="su-ds" step="300" value="${hm(s.dinnerStart)}"><span>–</span><input type="time" id="su-de" step="300" value="${hm(s.dinnerEnd)}"></span></div>
    </div></section>
    <section class="sec"><div class="sechead"><h2>每週固定的課或會議</h2></div><div class="form">
      ${rows.length ? rows.map(x => `<div class="field"><span class="lab" style="flex:1">${esc(x.title)}<small class="sub">${wdTxt(x)}　${hm(x.start)}–${hm(x.start + x.min)}</small></span><button class="x" data-act="setup-del" data-id="${x.id}">刪除</button></div>`).join("") : `<div class="field"><span class="lab" style="font-weight:400;color:var(--muted)">還沒有。用下面的欄位加，例如：週三 10:00–12:00 兩相流熱傳</span></div>`}
      <div class="field col">
        <div class="wd-pick" role="group" aria-label="星期幾">${[1, 2, 3, 4, 5, 6, 0].map(i => `<label><input type="checkbox" name="su-wd" value="${i}"${(st.wd || []).includes(i) ? " checked" : ""}><span>${WD[i]}</span></label>`).join("")}</div>
        <span class="trange"><input type="time" id="su-cs" step="300" value="${st.cs || ""}" aria-label="開始"><span>–</span><input type="time" id="su-ce" step="300" value="${st.ce || ""}" aria-label="結束"></span>
        <input type="text" id="su-ct" placeholder="名稱，例如：高等流力（課）" maxlength="30" value="${esc(st.ct || "")}" class="plain-in" aria-label="課程或會議名稱">
        <button class="btn" data-act="setup-add" style="align-self:flex-start">${I.plus}加入</button>
      </div>
    </div><p class="footnote">加進來的課會變成「固定事件」，每週自動出現，自動排程會避開。</p></section>
    <button class="btn primary block" data-act="setup-save">${st.first ? "開始使用" : "儲存"}</button>`;
  return sheetWrap("作息設定", st.first ? `<button data-act="setup-skip">先跳過</button>` : cancelBtn(), spacer, body);
}
function readSetupForm() {
  const v = id => (document.getElementById(id) || {}).value || "";
  const c = id => !!(document.getElementById(id) || {}).checked;
  const s = S.settings;
  const ws = toMin(v("su-ws")), we = toMin(v("su-we"));
  if (v("su-ws") && v("su-we") && we > ws) { s.workStart = ws; s.workEnd = we; }
  s.breakOn = c("su-l"); if (v("su-ls") && v("su-le") && toMin(v("su-le")) > toMin(v("su-ls"))) { s.breakStart = toMin(v("su-ls")); s.breakEnd = toMin(v("su-le")); }
  s.dinnerOn = c("su-d"); if (v("su-ds") && v("su-de") && toMin(v("su-de")) > toMin(v("su-ds"))) { s.dinnerStart = toMin(v("su-ds")); s.dinnerEnd = toMin(v("su-de")); }
}
function eventCatId() {
  let c = S.cats.find(x => x.event);
  if (!c) { c = { id: "cev", name: "固定事件", color: "#64748B", event: true }; S.cats.push(c); }
  return c.id;
}

/* ---------- 對話式修改：「讀高流改到週四」「取消週五的聚餐」「昨天沒做完：熱傳作業」 ---------- */
const CHG_MOVE = /^(.+?)\s*(?:改到|改成|改在|移到|挪到|換到|延到|延後到|順延到|提前到|往前到|調到)\s*(.+)$/;
const CHG_SHIFT = new RegExp(`^(.+?)\\s*(延後|往後|順延|提前|往前)\\s*(${N})\\s*(天|個?小時|分鐘)$`);
const CHG_CANCEL = /^(?:取消|刪掉|刪除|不用做|不做)\s*(.+)$|^(.+?)\s*(?:取消了?|不用做了?|不做了|不去了|刪掉|刪除)$/;
const CHG_DONE = /^(.+?)\s*(?:做完了|完成了|已經做完|已經完成|搞定了)$/;
const CHG_MISS = /^(?:(?:昨天|前天|今天|之前)?(?:沒做完|沒做|沒完成)[：:\s]*)(.+)$|^(.+?)\s*(?:沒做完|沒做|沒完成)$/;
/** 找使用者說的是哪一件事：名稱的字重疊最多、日期最近的 */
function findTaskByText(q, opts = {}) {
  let qq = String(q).replace(/^(?:這週|本週|下週|今天|明天|後天|昨天|前天)的?/, "").replace(/^的/, "").trim();
  const p = parseLine(q);
  const day = p && p.dateGiven ? p.date : null;
  const want = new Set(bcTokens((p && p.title) || qq));
  if (want.size < 1) return null;
  const t0 = today();
  let best = null;
  for (const t of S.tasks) {
    if (opts.undone && t.done) continue;
    if (!opts.past && t.date < addDays(t0, -14)) continue;
    const have = new Set(bcTokens(t.wname || t.title));
    let inter = 0; for (const w of want) if (have.has(w)) inter++;
    let sc = inter / Math.max(1, Math.min(want.size, have.size + 1));
    if (bcNorm(t.title).includes(bcNorm((p && p.title) || qq))) sc += 0.5;
    if (day && t.date === day) sc += 0.4; else if (day) sc -= 0.3;
    sc -= Math.abs(diff(t0, t.date)) * 0.004;
    if (opts.preferPast && t.date < t0) sc += 0.15;
    if (sc > (best ? best.sc : 0.42)) best = { t, sc };
  }
  return best && best.t;
}
/** 把一行字看成修改指令；不是就回傳 null */
function parseChange(line) {
  const L = line.replace(/[。！!]$/, "").trim();
  let m;
  if ((m = L.match(CHG_DONE))) { const t = findTaskByText(m[1], { undone: true, preferPast: true }); return { kind: "done", q: m[1], t }; }
  if ((m = L.match(CHG_MISS)) && !/[到在]/.test((m[1] || m[2] || "").slice(-1))) { const t = findTaskByText(m[1] || m[2], { undone: true, preferPast: true }); return { kind: "auto", q: m[1] || m[2], t }; }
  if ((m = L.match(CHG_CANCEL))) { const q = m[1] || m[2]; const t = findTaskByText(q, { undone: true }); return { kind: "delete", q, t }; }
  if ((m = L.match(CHG_SHIFT))) {
    const t = findTaskByText(m[1], { undone: true }); if (!t) return { kind: "move", q: m[1], t: null };
    const n = cnNum(m[3]) * (/提前|往前/.test(m[2]) ? -1 : 1);
    if (m[4] === "天") return { kind: "move", q: m[1], t, to: { date: addDays(t.date, n), start: t.start, keep: true } };
    const mins = /小時/.test(m[4]) ? n * 60 : n;
    return { kind: "move", q: m[1], t, to: { date: t.date, start: Math.max(0, Math.min(1435, (t.start ?? S.settings.workStart) + mins)), keep: true } };
  }
  if ((m = L.match(CHG_MOVE))) {
    const t = findTaskByText(m[1], { undone: true });
    const y = parseLine(m[2].replace(/^(?:到|在)/, "")) || {};
    const rg = detectRange(m[2]);
    const to = {};
    if (y.dateGiven) to.date = y.date; else if (rg) to.date = maxKey(rg.start, today());
    if (y.time) { to.start = toMin(y.time); if (!to.date && t) to.date = t.date; }
    if (!to.date && !y.time) return null;          // 「…改成…」後面不是日期時間 → 不是修改指令
    return { kind: "move", q: m[1], t, to };
  }
  return null;
}
/** 修改的預覽：誰從哪裡改到哪裡 */
function planChanges(changes) {
  const backup = JSON.stringify(S.tasks), out = [];
  for (const c of changes) {
    if (!c.t) { out.push({ ...c, id: uid(), miss: true }); continue; }
    const t = S.tasks.find(x => x.id === c.t.id); if (!t) continue;
    const from = { date: t.date, start: t.start };
    if (c.kind === "move") {
      if (c.to.date && c.to.date !== t.date) reschedule(t, c.to.date);
      if (c.to.start != null) { t.start = c.to.start; t.locked = true; } else if (!c.to.keep) { t.start = null; arrangeTimes(t.date, "fill"); }
    } else if (c.kind === "auto") {
      const r = plan([t], today()); reschedule(t, r[t.id]); t.start = null; t.locked = false; arrangeTimes(t.date, "fill");
      if (t.start == null) { const r2 = plan([t], addDays(t.date, 1)); reschedule(t, r2[t.id]); arrangeTimes(t.date, "fill"); }
    }
    out.push({ id: uid(), kind: c.kind, q: c.q, tid: t.id, title: t.title, from, to: { date: t.date, start: t.start } });
  }
  S.tasks = JSON.parse(backup);
  return out;
}
const whenTxt = x => `${rel(x.date)}${x.start != null ? " " + hm(x.start) : ""}`;
function changesHTML(a) {
  if (!a.changes || !a.changes.length) return "";
  return `<div class="sechead"><h2>要修改的</h2></div>${a.changes.map(c => {
    if (c.miss) return `<div class="pv-card chg miss"><div class="pv-top"><strong class="pv-name">找不到「${esc(c.q)}」</strong></div><div class="ai-when">換個說法，或直接點那件工作修改。</div></div>`;
    const on = a.csel.has(c.id);
    const what = c.kind === "delete" ? "刪除" : c.kind === "done" ? "標記為完成" : `${whenTxt(c.from)} → <b>${whenTxt(c.to)}</b>`;
    return `<div class="pv-card chg${on ? "" : " off"}"><span class="badge">變動</span><div class="pv-top">
      <button class="chk${on ? " on" : ""}" data-act="chg-pick" data-id="${c.id}" aria-label="${on ? "不要" : "要"}修改「${esc(c.title)}」">${I.check}</button>
      <strong class="pv-name">${esc(c.title)}</strong></div><div class="ai-when">${what}</div></div>`;
  }).join("")}`;
}
function applyChanges(a) {
  for (const c of a.changes || []) {
    if (c.miss || !a.csel.has(c.id)) continue;
    const t = task(c.tid); if (!t) continue;
    if (c.kind === "delete") { S.tasks = S.tasks.filter(x => x.id !== t.id); continue; }
    if (c.kind === "done") { t.done = true; t.doneOn = t.date < today() ? t.date : today(); continue; }
    if (c.to.date !== t.date) reschedule(t, c.to.date);
    t.start = c.to.start; t.locked = c.to.start != null && (c.kind === "move");
    if (t.start != null) habitLearnTask(t, t.start + t.min / 2, 1);
  }
}

/* ---------- 智慧排程的快速句型 ---------- */
const STARTERS = [   // | 是游標要停的位置
  ["某天某時要做的事", "明天下午 3 點|"],
  ["有截止日的作業", "週五前要交|，大概 3 小時"],
  ["一段時間內做完", "今明兩天要把|做完"],
  ["時間改了", "|改到 "],
  ["沒做完", "昨天沒做完：|"],
  ["取消", "取消|"]
];
function startersHTML() {
  return `<div class="starters">${STARTERS.map(([n, v], i) => `<button type="button" class="chip" data-act="ai-starter" data-i="${i}">${n}</button>`).join("")}</div>`;
}

/* ---------- 怎麼用 ---------- */
function sheetHelp() {
  const body = `<ol class="steps">
    <li><b>按「智慧排程」，用一般說話的方式打要做的事。</b>例如「明天下午兩點跟教授開會」「週五前交熱傳報告，大概 3 小時」「今明兩天要把作業寫完跟讀兩篇 paper」。一行一件，或用「跟、還有、然後」連起來都可以。</li>
    <li><b>時間改了也直接說。</b>「讀高流改到週四晚上 8 點」「熱傳報告延後 2 天」「取消週五的聚餐」「昨天沒做完：兩相流作業」。黃色的是要修改的地方，確認了才會改。</li>
    <li><b>只知道截止日和大概要多久的大工作</b>，按右上角 ＋ 選「智慧排法」，會拆成好幾段分散到截止日前。</li>
    <li><b>做完按圓圈打勾。</b>前幾天沒做完的會出現在「之前沒完成的」，可以一鍵往後排。</li>
    <li><b>最上面的日期可以左右滑</b>，點一天就看那天的安排；紅點是截止日。</li>
    <li><b>它會學你的習慣</b>：你改過的分類和時間長度、習慣在幾點做哪類事，下次就照你的方式排。</li>
  </ol>
  <p class="footnote">設定 › 作息設定 可以改工作時段、吃飯時間和每週固定的課。</p>
  <button class="btn primary block" data-act="help-back">知道了</button>`;
  return sheetWrap("怎麼用", spacer, spacer, body);
}

/* ===================== 取消、加班、滑動手勢 ===================== */

/** 取消一件事（保留紀錄、可以復原）；排程時當作不存在 */
function cancelTask(t) {
  if (!t) return;
  snapshot();
  t.cancelled = true; t.done = true; t.doneOn = null;
  if (t.wid) renumberWork(t.wid);
  commit(`已取消「${t.title}」`, true);
}
/** 這件事變長了：固定在原本的開始時間，後面沒固定時間的事往後排 */
function growTask(t, add, overtime) {
  t.min = Math.min(16 * 60, t.min + add);
  if (overtime) markOT(t, add);
  if (t.start != null) {
    t.locked = true;
    const end = t.start + t.min;
    S.tasks.forEach(x => { if (x.date === t.date && x.id !== t.id && !x.done && !x.locked && x.start != null && x.start < end + (S.settings.gap || 0) && x.start + x.min > t.start) x.start = null; });
    S.tasks.forEach(x => { if (x.date === t.date && x.id !== t.id && !x.done && !x.locked && x.start != null && x.start >= t.start) x.start = null; });
    arrangeTimes(t.date, "fill");
  }
}
/* ---- 加班：只有那天的工作超過工作時間，才問要不要加班（被動選項） ---- */
/** 超過 24:00 顯示成「隔天 01:30」 */
const hmx = m => m >= 1440 ? `隔天 ${hm(m - 1440)}` : hm(m);
function overloadInfo(k) {
  if (k < today()) return null;
  arrangeTimes(k, "fill");
  const s = S.settings;
  const list = sortTasks(S.tasks.filter(t => t.date === k && !t.done && !t.cancelled && !isEvent(t) && t.start == null));
  if (!list.length) return null;
  const need = list.reduce((a, t) => a + t.min, 0);
  // 從收工時間開始，找沒有被佔用的空檔一件一件放（過了半夜就接到隔天，避開隔天已經排好的事）
  const k1 = addDays(k, 1), busy = [];
  for (const t of S.tasks) if (t.start != null && !t.cancelled && (t.date === k || t.date === k1)) { const o = t.date === k ? 0 : 1440; busy.push([o + t.start, o + t.start + t.min]); }
  busy.sort((a, b) => a[0] - b[0]);
  let cur = s.workEnd;
  if (k === today()) cur = Math.max(cur, Math.ceil(nowMin() / 5) * 5);
  const place = [];
  for (const t of list) {
    let moved = true;
    while (moved) { moved = false; for (const [a, b] of busy) if (cur < b && cur + t.min > a) { cur = b; moved = true; } }
    place.push(cur); busy.push([cur, cur + t.min]); cur += t.min + (s.gap || 0);
  }
  const until = place.length ? place[place.length - 1] + list[list.length - 1].min : cur;
  return { list, need, start: place[0], place, until };
}
function otBannerHTML(k) {
  const o = overloadInfo(k); if (!o) return "";
  return `<div class="otbanner"><div class="t">${I.clock}這天排的工作超過工作時間 ${hm(S.settings.workEnd)}，還有 ${o.list.length} 項（${dur(o.need)}）排不下</div>
    <div class="small">${o.list.slice(0, 3).map(t => esc(t.title)).join("、")}${o.list.length > 3 ? ` 等 ${o.list.length} 項` : ""}</div>
    <div class="btnrow"><button class="btn ot" data-act="ot-accept" data-date="${k}">加班做完（到 ${hmx(o.until)}）</button><button class="btn" data-act="ot-spread" data-date="${k}">${I.cal}改到其他天</button></div></div>`;
}
/* ---- 加班視窗 ---- */
function sheetOT(o) {
  const t = task(o.id); if (!t) return "";
  const s = S.settings, end = t.start != null ? t.start + t.min : null;
  const opts = [15, 30, 60, 90, 120];
  const body = `<div class="taskhead"><strong>${esc(t.title)}</strong><div class="meta"><span>${t.start != null ? `原訂 ${range(t)}` : `原訂 ${dur(t.min)}`}</span>${t.ot ? `<span class="otb">已加班 ${dur(t.ot)}</span>` : ""}</div></div>
    <section class="sec"><div class="sechead"><h2>要加班多久</h2></div><div class="form">
      <div class="ot-grid">${opts.map(m => `<button class="btn" data-act="ot-add" data-id="${t.id}" data-min="${m}">+${dur(m)}${end != null ? `<small>到 ${hmx(end + m)}</small>` : ""}</button>`).join("")}</div>
      <div class="field col durfield" data-durgroup="ot"><span class="lab">自己設定</span>${durPickHTML(o.min || 45, 'data-dur="ot"', null, [])}</div>
      <button class="btn primary" data-act="ot-add" data-id="${t.id}" data-custom="1" style="align-self:flex-start">${I.plus}加班這麼久</button>
    </div><p class="footnote">加班會讓這件事超出原本排的時間${end != null && end + 30 > s.workEnd ? `，也可以超過收工時間 ${hm(s.workEnd)}` : ""}。後面沒有固定時間的工作會自動往後排；排不下的會出現在「排不下」清單。加班時數會記在統計裡。</p></section>`;
  return sheetWrap("加班", cancelBtn(), spacer, body);
}

/* ---- 滑動手勢可以做的事 ---- */
const SWIPE_ACTIONS = {
  done:      { n: "完成",       c: "#34c759", ic: "check", ok: t => !isEvent(t) },
  cancel:    { n: "取消",       c: "#ff3b30", ic: "x" },
  autolater: { n: "往後排",     c: "#5856d6", ic: "redo", out: true },
  later1d:   { n: "延後一天",   c: "#ff9500", ic: "arrow", out: true },
  today:     { n: "移到今天",   c: "#007aff", ic: "sun", out: true, ok: t => t.date !== today() },
  extend15:  { n: "+15 分",     c: "#30b0c7", ic: "clock" },
  extend30:  { n: "+30 分",     c: "#32ade6", ic: "clock" },
  urgent:    { n: "更緊急",     c: "#ff2d55", ic: "alert", ok: t => !isEvent(t) && t.pri < 3 },
  calmer:    { n: "不急",       c: "#8e8e93", ic: "alert", ok: t => !isEvent(t) && t.pri > 0 },
  edit:      { n: "編輯",       c: "#636366", ic: "pencil" },
  remove:    { n: "刪除",       c: "#d70015", ic: "trash", out: true },
  none:      { n: "（不用）" }
};
function swipeList(side) {
  const a = S.settings[side === "R" ? "swipeR" : "swipeL"] || [];
  return a.filter(k => k && k !== "none" && SWIPE_ACTIONS[k]);
}
function runSwipe(k, t) {
  if (!t) return;
  const A = SWIPE_ACTIONS[k]; if (!A || (A.ok && !A.ok(t))) return;
  if (k === "done") { toggle(t); commit(t.done ? "做得好！" : ""); if (t.done) popCheck(t.id); afterToggle(t); return; }
  if (k === "cancel") return t.cancelled ? (toggle(t), commit("已恢復")) : cancelTask(t);
  if (k === "edit") return openSheet({ type: "edit", id: t.id });
  snapshot();
  if (k === "autolater") {
    if (t.start != null) habitLearnTask(t, t.start + t.min / 2, -0.7);
    const r = plan([t], t.date >= today() ? addDays(t.date, 1) : today()); reschedule(t, r[t.id]); t.start = null; t.locked = false; arrangeTimes(t.date, "fill");
    return commit(`「${t.title}」排到 ${rel(t.date)}${t.start != null ? " " + hm(t.start) : ""}`, true);
  }
  if (k === "later1d") { reschedule(t, addDays(maxKey(t.date, addDays(today(), -1)), 1)); arrangeTimes(t.date, "fill"); return commit(`已延後到 ${rel(t.date)}`, true); }
  if (k === "today") { reschedule(t, today()); arrangeTimes(today(), "fill"); return commit("已移到今天", true); }
  if (k === "extend15" || k === "extend30") { growTask(t, k === "extend15" ? 15 : 30, false); return commit(`「${t.title}」延長到 ${dur(t.min)}`, true); }
  if (k === "urgent" || k === "calmer") { t.pri = Math.max(0, Math.min(3, t.pri + (k === "urgent" ? 1 : -1))); return commit(`優先順序改成「${PRI[t.pri]}」`, true); }
  if (k === "remove") { S.tasks = S.tasks.filter(x => x.id !== t.id); if (t.wid) renumberWork(t.wid); return commit(`已刪除「${t.title}」`, true); }
}

/* ---- 手勢本體：像 iPhone 的郵件，往左往右滑出按鈕，滑到底直接執行 ---- */
const SW = { row: null, open: null };
const BTN_W = 74;
function swUnder(row) {
  const list = row.parentElement; if (!list) return null;
  let u = list.querySelector(":scope > .sw-under");
  if (!u) { u = document.createElement("div"); u.className = "sw-under"; list.appendChild(u); }
  const t = task(row.dataset.id);
  // 第一個動作永遠在最外側（滑到底執行的那個）：右滑在最左邊、左滑在最右邊
  const btns = side => { const l = swipeList(side).filter(k => !SWIPE_ACTIONS[k].ok || SWIPE_ACTIONS[k].ok(t)); return (side === "L" ? l.reverse() : l).map(k => {
    const A = SWIPE_ACTIONS[k], label = k === "cancel" && t.cancelled ? "恢復" : k === "done" && t.done ? "未完成" : A.n;
    return `<button data-act="swipe-act" data-a="${k}" data-id="${t.id}" style="--sc:${A.c}"><span>${I[A.ic] || ""}</span>${label}</button>`;
  }).join(""); };
  u.innerHTML = `<div class="swl">${btns("R")}</div><div class="swr">${btns("L")}</div>`;
  u.style.top = row.offsetTop + "px"; u.style.height = row.offsetHeight + "px";
  u.hidden = false;
  return u;
}
function swClose(animate = true) {
  const r = SW.open; SW.open = null;
  if (!r) return;
  r.style.transition = animate ? "transform .5s var(--ios-ease)" : "";
  r.style.transform = "";
  const u = r.parentElement && r.parentElement.querySelector(":scope > .sw-under");
  setTimeout(() => { r.classList.remove("swiping"); if (u && !SW.open) u.hidden = true; }, animate ? 500 : 0);
}
function swSet(row, x) {
  row.style.transform = x ? `translate3d(${x}px,0,0)` : "";
  const u = row.parentElement.querySelector(":scope > .sw-under"); if (!u) return;
  const w = SW.w || row.offsetWidth, nL = u.querySelectorAll(".swl button").length, nR = u.querySelectorAll(".swr button").length;
  u.classList.toggle("show-l", x > 0); u.classList.toggle("show-r", x < 0);
  u.classList.toggle("full", (x > 0 && nL && x > w * 0.55) || (x < 0 && nR && -x > w * 0.55));
  u.style.setProperty("--reveal", Math.abs(x) + "px");
}
document.addEventListener("pointerdown", e => {
  const row = e.target.closest && e.target.closest("#view .list > .row[data-id]");
  if (SW.open && (!row || row !== SW.open) && !e.target.closest(".sw-under")) { swClose(); }
  if (!row || e.button > 0) return;
  if (e.target.closest("button, input, select, a") ) return;
  const base = SW.open === row ? (parseFloat((row.style.transform.match(/translate3d\((-?[\d.]+)px/) || [0, 0])[1]) || 0) : 0;
  SW.w = 0; SW.row = row; SW.x0 = e.clientX; SW.y0 = e.clientY; SW.base = base; SW.dir = null; SW.t0 = performance.now(); SW.lastX = e.clientX; SW.v = 0;
});
document.addEventListener("pointermove", e => {
  if (!SW.row) return;
  const dx = e.clientX - SW.x0, dy = e.clientY - SW.y0;
  if (!SW.dir) {
    if (Math.abs(dx) > 8 && Math.abs(dx) > Math.abs(dy) * 1.2) {
      SW.dir = "h"; swUnder(SW.row); SW.row.classList.add("swiping"); SW.row.style.transition = "none";
      try { SW.row.setPointerCapture(e.pointerId); } catch (err) {}
    } else if (Math.abs(dy) > 10) { SW.row = null; return; }
    else return;
  }
  const u = SW.row.parentElement.querySelector(":scope > .sw-under");
  const nL = u ? u.querySelectorAll(".swl button").length : 0, nR = u ? u.querySelectorAll(".swr button").length : 0;
  let x = SW.base + dx;
  if ((x > 0 && !nL) || (x < 0 && !nR)) x = x / 6;               // 那一邊沒設定動作 → 拉不動
  const w = SW.w || (SW.w = SW.row.offsetWidth);
  if (Math.abs(x) > w * 0.8) x = Math.sign(x) * (w * 0.8 + (Math.abs(x) - w * 0.8) / 4);   // 橡皮筋
  const now = performance.now(); SW.v = (e.clientX - SW.lastX) / Math.max(1, now - SW.t0); SW.lastX = e.clientX; SW.t0 = now;
  SW.x = x;
  // 跟著螢幕更新率畫（ProMotion 120Hz 的手機每秒 120 次），一幀只畫一次
  if (!SW.raf) SW.raf = requestAnimationFrame(() => { SW.raf = 0; if (SW.row) swSet(SW.row, SW.x); });
});
function swEnd() {
  const row = SW.row; SW.row = null;
  if (SW.raf) { cancelAnimationFrame(SW.raf); SW.raf = 0; }
  if (!row || SW.dir !== "h") return;
  SW.justSwiped = Date.now();
  const x = SW.x || 0, w = row.offsetWidth, u = row.parentElement.querySelector(":scope > .sw-under");
  const side = x > 0 ? "l" : "r", btns = u ? [...u.querySelectorAll(`.sw${side} button`)] : [];
  row.style.transition = "transform .5s var(--ios-ease)";
  if (btns.length && (Math.abs(x) > w * 0.55 || (Math.abs(SW.v) > 1.1 && Math.abs(x) > 60 && Math.sign(SW.v) === Math.sign(x)))) {
    // 滑到底 → 執行第一個動作
    const b = side === "l" ? btns[0] : btns[btns.length - 1];
    const k = b.dataset.a, t = task(b.dataset.id), A = SWIPE_ACTIONS[k];
    if (A.out) { row.style.transform = `translate3d(${Math.sign(x) * w * 1.05}px,0,0)`; row.classList.add("sw-out"); setTimeout(() => runSwipe(k, t), 380); }
    else { swSet(row, 0); setTimeout(() => runSwipe(k, t), 180); }
    SW.open = null; return;
  }
  if (btns.length && Math.abs(x) > 44) { const open = Math.sign(x) * btns.length * BTN_W; swSet(row, open); SW.open = row; return; }
  SW.open = row; swClose();
}
document.addEventListener("pointerup", swEnd);
document.addEventListener("pointercancel", swEnd);
// 剛滑完的那一下不要當成點擊
document.addEventListener("click", e => { if (SW.justSwiped && Date.now() - SW.justSwiped < 350 && !e.target.closest(".sw-under")) { e.stopPropagation(); e.preventDefault(); } }, true);

function swipeSettingsHTML() {
  const s = S.settings;
  const opt = (cur, allowNone) => Object.entries(SWIPE_ACTIONS).filter(([k]) => allowNone || k !== "none").map(([k, A]) => `<option value="${k}"${k === cur ? " selected" : ""}>${A.n}</option>`).join("");
  const R = s.swipeR || [], L = s.swipeL || [];
  const pv = (list, cls) => `<span class="swpv ${cls}">${list.filter(k => k && k !== "none").map(k => `<i style="background:${SWIPE_ACTIONS[k].c}">${SWIPE_ACTIONS[k].n}</i>`).join("")}</span>`;
  return `<section class="sec"><div class="sechead"><h2>左右滑動</h2></div><div class="form">
    <div class="field col"><span class="lab">往右滑 →</span>${pv(R, "r")}</div>
    <div class="field"><label for="sw-r0">滑到底直接做</label><select id="sw-r0" data-swipe="R0">${opt(R[0] || "none", true)}</select></div>
    <div class="field"><label for="sw-r1">第二個按鈕</label><select id="sw-r1" data-swipe="R1">${opt(R[1] || "none", true)}</select></div>
    <div class="field col"><span class="lab">← 往左滑</span>${pv(L, "l")}</div>
    <div class="field"><label for="sw-l0">滑到底直接做</label><select id="sw-l0" data-swipe="L0">${opt(L[0] || "none", true)}</select></div>
    <div class="field"><label for="sw-l1">第二個按鈕</label><select id="sw-l1" data-swipe="L1">${opt(L[1] || "none", true)}</select></div>
  </div><p class="footnote">在清單上把工作往左或往右滑：滑一點會出現按鈕，滑到底直接執行第一個。可以選：完成、取消、往後排、延後一天、移到今天、延長 15／30 分、更緊急、不急、編輯、刪除。（加班不在這裡：只有那天排的工作超過工作時間時，才會問你要不要加班。）</p></section>`;
}

/* ---------- 底部卡片：往下拉可以關掉（像 iPhone） ---------- */
const SD = { on: false };
document.addEventListener("pointerdown", e => {
  const head = e.target.closest && e.target.closest("#sheet .sheethead");
  if (!head || e.target.closest("button")) return;
  const sh = document.querySelector("#sheet .sheet"); if (!sh) return;
  Object.assign(SD, { on: true, y0: e.clientY, sh, dy: 0, t: performance.now(), v: 0, ly: e.clientY });
  sh.style.transition = "none";
});
document.addEventListener("pointermove", e => {
  if (!SD.on) return;
  const dy = Math.max(0, e.clientY - SD.y0), now = performance.now();
  SD.v = (e.clientY - SD.ly) / Math.max(1, now - SD.t); SD.t = now; SD.ly = e.clientY;
  SD.dy = dy < 0 ? 0 : dy;
  if (!SD.raf) SD.raf = requestAnimationFrame(() => {
    SD.raf = 0; if (!SD.on) return;
    SD.sh.style.transform = `translate3d(0,${SD.dy}px,0)`;
    const sc = document.querySelector("#sheet .scrim"); if (sc) sc.style.opacity = String(Math.max(0.2, 1 - SD.dy / 500));
  });
});
function sdEnd() {
  if (!SD.on) return; SD.on = false;
  const sh = SD.sh;
  if (SD.dy > 120 || (SD.v > 0.7 && SD.dy > 30)) { ui.dragY = SD.dy; closeSheet(); return; }
  sh.style.transition = "transform .4s var(--ios-ease)"; sh.style.transform = "";
  const sc = document.querySelector("#sheet .scrim"); if (sc) sc.style.opacity = "";
}
document.addEventListener("pointerup", sdEnd); document.addEventListener("pointercancel", sdEnd);

/* ===================== 共享行程 ===================== */
/* 我的分享 → shares/{id}（只有我能寫）；朋友用連結或 Gmail 名單看。 */
const shareCfg = () => S.settings.share || {};
const shareRef = id => FB.db.collection("shares").doc(id);
const shareURL = id => `${location.origin}/#share=${id}`;
function randId(n = 20) { const a = "abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789"; let s = ""; const r = new Uint8Array(n); (crypto.getRandomValues ? crypto.getRandomValues(r) : r.forEach((_, i) => { r[i] = Math.random() * 256; })); for (const x of r) s += a[x % a.length]; return s; }
let shareT = 0;
/** 把接下來幾天的行程寫到分享文件（每次存檔後 1.5 秒） */
function publishShare(now) {
  const c = shareCfg(); if (!c.on || !c.id || !FB.user || !FB.loaded) return;
  clearTimeout(shareT);
  shareT = setTimeout(() => {
    const t0 = today(), from = addDays(t0, -1), to = addDays(t0, Math.max(1, +c.range || 14));
    const items = S.tasks.filter(t => t.date >= from && t.date <= to && !(t.cancelled && !isEvent(t)))
      .map(t => { const k = cat(t.cat); const o = { d: t.date, m: t.min }; if (t.start != null) o.s = t.start; if (c.detail !== "busy") o.t = t.title; if (k) o.c = k.color; if (isEvent(t)) o.ev = 1; if (t.done && !t.cancelled) o.ok = 1; if (t.cancelled) o.x = 1; return o; });
    const doc = { owner: FB.user.uid, name: c.name || (FB.user.displayName || "朋友"), mode: c.mode === "emails" ? "emails" : "link",
      emails: (c.emails || []).map(e => String(e).trim().toLowerCase()).filter(Boolean), detail: c.detail || "title", range: +c.range || 14,
      workStart: S.settings.workStart, workEnd: S.settings.workEnd, items, updated: Date.now(), ...(S.settings.myAvatar ? { avatar: S.settings.myAvatar } : {}) };
    shareRef(c.id).set(doc).catch(e => toast("分享更新失敗：" + fbError(e)));
  }, now ? 0 : 1500);
}
/* ---- 看朋友的行程 ---- */
const friendCache = {};
let friendUnsub = null;            // 舊程式相容用（現在每個朋友各有一個監聽）
const friendSubs = {};
/** 開始即時接收某位朋友的分享行程（已經在接收就不重複） */
function watchFriend(id) {
  if (!id || friendSubs[id] || !FB.db) return;
  friendCache[id] = friendCache[id] || { loading: true };
  friendSubs[id] = shareRef(id).onSnapshot(snap => {
    friendCache[id] = snap.exists ? { data: snap.data() } : { missing: true };
    const f = (S.settings.follows || []).find(x => x.id === id);
    if (f && snap.exists && f.name !== snap.data().name) { f.name = snap.data().name; save(); }
    if (ui.tab === "share" && !ui.sheet) renderMain();
  }, err => {
    friendCache[id] = { denied: /permission/i.test(String(err && (err.code || err.message))), error: fbError(err) };
    delete friendSubs[id];
    if (ui.tab === "share" && !ui.sheet) renderMain();
  });
}
function unwatchFriend(id) { if (friendSubs[id]) { friendSubs[id](); delete friendSubs[id]; } }
const personName = f => (f && (f.alias || f.name)) || "朋友";
const DEFAULT_PCOLORS = ["#FF9500", "#34C759", "#AF52DE", "#FF2D55", "#5AC8FA", "#FFCC00", "#A2845E", "#30B0C7"];
const personColor = (f, i) => (f && f.color) || DEFAULT_PCOLORS[(i || 0) % DEFAULT_PCOLORS.length];
const myColor = () => S.settings.myColor || "#2F7CF6";
function parseShareId(text) {
  const m = String(text || "").match(/share=([A-Za-z0-9]{12,40})/) || String(text || "").trim().match(/^([A-Za-z0-9]{12,40})$/);
  return m ? m[1] : null;
}
function followShare(id, name) {
  if (!id) return false;
  if (shareCfg().id === id) { toast("這是你自己的分享連結"); return false; }
  const list = [...(S.settings.follows || [])];
  if (!list.some(x => x.id === id)) { list.push({ id, name: name || "朋友", added: Date.now() }); S.settings.follows = list; save(); }
  return true;
}
/** 兩個人都有空的時間（工作時段內、至少 30 分鐘） */
function commonFree(k, fItems, fd) {
  const s = S.settings, start = Math.max(s.workStart, fd.workStart ?? s.workStart), end = Math.min(s.workEnd, fd.workEnd ?? s.workEnd);
  const busy = [];
  for (const [a, b] of breaks()) busy.push([a, b]);
  for (const t of S.tasks) if (t.date === k && t.start != null && !t.cancelled && !(t.done && !isEvent(t))) busy.push([t.start, t.start + t.min]);
  for (const x of fItems) if (x.d === k && x.s != null && !x.x && !x.ok) busy.push([x.s, x.s + x.m]);
  busy.sort((a, b) => a[0] - b[0]);
  let cur = k === today() ? Math.max(start, Math.ceil(nowMin() / 15) * 15) : start;
  const out = [];
  for (const [a, b] of busy) { if (a > cur && a - cur >= 30) out.push([cur, Math.min(a, end)]); cur = Math.max(cur, b); if (cur >= end) break; }
  if (end - cur >= 30) out.push([cur, end]);
  return out.filter(([a, b]) => b - a >= 30).slice(0, 8);
}
/** 大家的行程：我和每位朋友的行程放在同一張時間表，用顏色分 */
function viewShareAll() {
  const follows = S.settings.follows || [];
  follows.forEach(f => watchFriend(f.id));
  const t0 = today(), sel = ui.allDay && ui.allDay >= t0 ? ui.allDay : t0;
  const hide = new Set(S.settings.shareHide || []);
  const people = [{ id: "me", name: "我", color: myColor() }, ...follows.map((f, i) => ({ id: f.id, name: personName(f), color: personColor(f, i), f }))];
  let h = `<div class="ctrl"><div class="legend">${people.map(p => { const st = p.id === "me" ? null : friendCache[p.f.id] || {}; const bad = st && (st.denied || st.missing || st.error);
    return `<button class="lg${hide.has(p.id) ? " off" : ""}" data-act="share-toggle" data-pid="${esc(p.id)}" aria-pressed="${!hide.has(p.id)}">${avHTML(p.id, p.name, p.color, "lav")}${esc(p.name)}${bad ? " ⚠" : ""}</button>`; }).join("")}</div>`;
  let strip = `<nav class="dstrip" aria-label="選日期">`;
  for (let i = 0; i < 14; i++) {
    const k = addDays(t0, i);
    strip += `<button class="dp${k === t0 ? " today" : ""}${k === sel ? " sel" : ""}" data-act="all-day" data-date="${k}"><span class="w">${k === t0 ? "今天" : "週" + WD[parse(k).getDay()]}</span><span class="n num">${parse(k).getDate()}</span><span class="c"></span></button>`;
  }
  h += strip + `</nav></div>`;
  const blocks = [], untimed = [];
  if (!hide.has("me")) for (const t of S.tasks) {
    if (t.date !== sel || t.cancelled) continue;
    const o = { who: "me", name: "我", color: myColor(), t: t.title, s: t.start, m: t.min, done: t.done && !isEvent(t), ev: isEvent(t) };
    (t.start != null ? blocks : untimed).push(o);
  }
  people.slice(1).forEach(p => {
    if (hide.has(p.id)) return;
    const st = friendCache[p.f.id]; if (!st || !st.data) return;
    for (const x of st.data.items || []) {
      if (x.d !== sel || x.x) continue;
      const o = { who: p.id, name: p.name, color: p.color, t: x.t || "忙碌", s: x.s, m: x.m, done: !!x.ok, ev: !!x.ev };
      (x.s != null ? blocks : untimed).push(o);
    }
  });
  blocks.sort((a, b) => a.s - b.s || (a.who === "me" ? -1 : 1));
  const S0 = Math.min(S.settings.workStart, ...blocks.map(b => b.s)), E0 = Math.max(S.settings.workEnd, ...blocks.map(b => b.s + b.m));
  const first = Math.max(0, Math.floor(S0 / 60)), last = Math.min(24, Math.ceil(E0 / 60));
  const PX = 1.05, y = m => (m - first * 60) * PX;
  { let group = [], end = -1;
    const flush = () => { const cols = Math.max(1, ...group.map(g => g.col + 1)); group.forEach(g => { g.cols = cols; }); group = []; };
    for (const b of blocks) { if (b.s >= end && group.length) flush(); const used = new Set(group.filter(g => g.s + g.m > b.s).map(g => g.col)); let col = 0; while (used.has(col)) col++; b.col = col; group.push(b); end = Math.max(end, b.s + b.m); }
    if (group.length) flush(); }
  h += `<section class="sec"><div class="sechead"><h2>${full(sel)}</h2><span class="aside">${people.filter(p => !hide.has(p.id)).length} 人</span></div>`;
  if (!blocks.length && !untimed.length) h += `<div class="empty">這天大家都沒有排時間。</div>`;
  else {
    h += `<div class="tl alltl" style="height:${y(last * 60) + 12}px">`;
    for (let hr = first; hr <= last; hr++) h += `<div class="hr" style="top:${y(hr * 60)}px"><span>${pad(hr)}:00</span></div>`;
    for (const b of blocks) {
      const hgt = Math.max(b.m * PX - 2, 24), pos = b.cols > 1 ? `left:calc(58px + (100% - 64px) * ${b.col} / ${b.cols});right:auto;width:calc((100% - 64px) / ${b.cols} - 4px);` : "";
      h += `<div class="pblk${b.done ? " done" : ""}${b.ev ? " ev" : ""}${hgt < 40 ? " one" : ""}" style="--pc:${b.color};top:${y(b.s) + 1}px;height:${hgt}px;${pos}"><b>${esc(b.t)}</b><small>${esc(b.name)}・${hm(b.s)}–${hm(b.s + b.m)}</small></div>`;
    }
    h += `</div>`;
    if (untimed.length) h += `<div class="untimed"><div class="t">沒有固定時間</div>${untimed.map(u => `<div class="u"><span><i class="pdot" style="background:${u.color}"></i>${esc(u.t)}<small>${esc(u.name)}・${dur(u.m)}</small></span></div>`).join("")}</div>`;
  }
  h += `</section>`;
  const vis = people.slice(1).filter(p => !hide.has(p.id) && friendCache[p.f.id] && friendCache[p.f.id].data);
  if (vis.length) {
    let free = null;
    for (const p of vis) { const fr = commonFree(sel, friendCache[p.f.id].data.items || [], friendCache[p.f.id].data); free = free ? intersect(free, fr) : fr; }
    free = (free || []).filter(([a, b]) => b - a >= 30);
    h += `<section class="sec"><div class="sechead"><h2>大家都有空的時間</h2></div><div class="list">${free.length ? free.map(([a, b]) => `<div class="row"><div class="rbody"><div class="rtitle">${hm(a)}–${hm(b)}</div><div class="meta"><span>${dur(b - a)}</span><span>${vis.map(p => esc(p.name)).join("、")}和你</span></div></div><button class="btn sm" data-act="friend-meet" data-date="${sel}" data-s="${a}" data-e="${Math.min(b, a + 60)}" data-name="${esc(vis.map(p => p.name).join("、"))}" style="align-self:center">約這個時間</button></div>`).join("") : `<div class="empty">這天工作時段內沒有大家都有空的時間。</div>`}</div></section>`;
  }
  return h;
}
function intersect(A, B) {
  const out = [];
  for (const [a1, b1] of A) for (const [a2, b2] of B) { const a = Math.max(a1, a2), b = Math.min(b1, b2); if (b > a) out.push([a, b]); }
  return out.sort((x, y) => x[0] - y[0]);
}
/** 設定某個人的名稱、顏色 */
/* ---- 頭貼：自己的會分享給朋友；朋友的可以自己換一張（只有你看得到） ---- */
function personAvatar(pid) {
  if (pid === "me") return S.settings.myAvatar || "";
  const f = (S.settings.follows || []).find(x => x.id === pid); if (!f) return "";
  if (f.avatar) return f.avatar;
  const st = friendCache[f.id]; return (st && st.data && st.data.avatar) || "";
}
/** 圓形頭貼：有照片用照片，沒有就用名字第一個字＋顏色 */
function avHTML(pid, name, color, cls = "av") {
  const img = personAvatar(pid);
  const safe = /^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/.test(img) ? img : "";
  return `<span class="${cls}${safe ? " pic" : ""}" style="background-color:${color}${safe ? `;background-image:url('${safe}')` : ""}" aria-hidden="true">${safe ? "" : esc((name || "?")[0])}</span>`;
}
/** 把照片裁成正方形、縮小（約 10KB），存在帳號裡 */
function shrinkImage(file, size = 160) {
  return new Promise((res, rej) => {
    const url = URL.createObjectURL(file), img = new Image();
    img.onload = () => {
      const c = document.createElement("canvas"); c.width = c.height = size;
      const s0 = Math.min(img.naturalWidth, img.naturalHeight), sx = (img.naturalWidth - s0) / 2, sy = (img.naturalHeight - s0) / 2;
      c.getContext("2d").drawImage(img, sx, sy, s0, s0, 0, 0, size, size);
      URL.revokeObjectURL(url);
      res(c.toDataURL("image/jpeg", 0.82));
    };
    img.onerror = () => { URL.revokeObjectURL(url); rej(new Error("讀不到這張圖片")); };
    img.src = url;
  });
}
function sheetPerson(o) {
  const me = o.pid === "me";
  const fi = (S.settings.follows || []).findIndex(x => x.id === o.pid), f = me ? null : S.settings.follows[fi];
  if (!me && !f) return "";
  const cur = me ? myColor() : personColor(f, fi);
  const cols = [...new Set([...DEFAULT_PCOLORS, ...PALETTE, "#2F7CF6"])];
  const nm = me ? ((FB.user && FB.user.displayName) || "我") : personName(f);
  const curAv = o.avatar !== undefined ? o.avatar : personAvatar(o.pid);
  const ownAv = !me && !f.avatar && friendCache[f.id] && friendCache[f.id].data && friendCache[f.id].data.avatar;
  const body = `<div class="avedit">
      <span class="av big${curAv ? " pic" : ""}" id="ps-av" style="background-color:${cur}${curAv ? `;background-image:url('${curAv}')` : ""}">${curAv ? "" : esc(nm[0])}</span>
      <div class="avbtns"><label class="btn sm">換頭貼<input type="file" id="ps-avatar" accept="image/*" hidden></label>
        ${curAv && !(ownAv && o.avatar === undefined) ? `<button class="btn sm" data-act="ps-av-clear">移除</button>` : ""}</div>
      <small>${me ? "你的頭貼會跟著行程一起分享給朋友。" : ownAv && o.avatar === undefined ? "這是對方自己設定的頭貼；你也可以換一張只有你看得到的。" : "換的頭貼只有你看得到。"}</small>
    </div>
    <div class="form">
      ${me ? "" : `<div class="field col"><span class="lab">顯示的名字</span><input type="text" class="plain-in" id="ps-name" maxlength="16" value="${esc(f.alias || "")}" placeholder="${esc(f.name || "朋友")}"><small style="color:var(--muted);font-size:12px">只會改你這邊看到的名字。對方自己設定的名字：${esc(f.name || "（沒有）")}</small></div>`}
      <div class="field col"><span class="lab">${me ? "你自己的顏色" : "顏色"}</span><div class="swatches big">${cols.map(c => `<label><input type="radio" name="ps-color" value="${c}"${c.toLowerCase() === cur.toLowerCase() ? " checked" : ""}><span style="background:${c}"></span></label>`).join("")}
        <label class="custom"><input type="color" id="ps-custom" value="${cur}"><span>自訂</span></label></div></div>
    </div>
    <div class="pprev" style="--pc:${cur}"><b>${me ? "我的行程" : esc(personName(f)) + " 的行程"}</b><small>在「大家的行程」會用這個顏色</small></div>
    <button class="btn primary block" data-act="person-save" data-pid="${esc(o.pid)}">儲存</button>
    ${me ? "" : `<button class="opt" data-act="share-view" data-sid="${esc(f.id)}"><span class="main">只看${esc(personName(f))}的行程<small>還有你們兩個人都有空的時間</small></span></button>
    <button class="opt" data-act="share-unfollow" data-sid="${esc(f.id)}"><span class="main" style="color:var(--danger)">不再追蹤</span></button>`}`;
  return sheetWrap(me ? "我" : personName(f), cancelBtn(), spacer, body);
}
function viewShare() {
  if (ui.shareView) return viewFriend(ui.shareView);
  const c = shareCfg(), follows = S.settings.follows || [];
  const sub = ui.shareSub || (follows.length ? "all" : "people");
  let h = head("共享", sub === "all" ? "我和朋友的行程放在一起，用顏色分" : "分享自己的行程、管理追蹤的人");
  h += `<div class="seg"><button class="${sub === "all" ? "on" : ""}" data-act="share-sub" data-sub="all">大家的行程</button><button class="${sub === "people" ? "on" : ""}" data-act="share-sub" data-sub="people">分享設定</button></div>`;
  if (sub === "all") return h + (follows.length ? viewShareAll() : `<div class="empty">還沒有追蹤任何人。到「分享設定」貼上朋友的分享連結，或請朋友傳連結給你。</div>`);
  h += `<section class="sec"><div class="sechead"><h2>我的行程</h2>${c.on ? `<span class="aside">分享中</span>` : ""}</div><div class="form">`;
  if (!c.on) {
    h += `<div class="field col"><span class="lab">把你的行程分享出去<small class="sub">對方打開連結（用 Google 登入）就能看到你接下來幾天的安排，你改了行程會自動更新。可以只讓指定的 Gmail 看，也可以只顯示「忙碌」不顯示內容。</small></span>
      <button class="btn primary" data-act="share-on" style="align-self:flex-start">${I.plus}開始分享</button></div>`;
  } else {
    const url = shareURL(c.id);
    h += `<div class="field col"><span class="lab">分享連結</span><div class="sharelink"><input type="text" readonly value="${esc(url)}" id="share-url" aria-label="分享連結"></div>
        <div class="btnrow"><button class="btn primary" data-act="share-send">${I.arrow}傳給朋友</button><button class="btn" data-act="share-copy">複製連結</button></div></div>
      <div class="field col"><span class="lab">顯示的名字</span><input type="text" class="plain-in" id="share-name" data-share="name" value="${esc(c.name || (FB.user && FB.user.displayName) || "")}" maxlength="20"></div>
      <div class="field col"><span class="lab">誰可以看</span><div class="seg" role="radiogroup">
        <label><input type="radio" name="share-mode" data-share="mode" value="link"${c.mode !== "emails" ? " checked" : ""}><span>有連結的人</span></label>
        <label><input type="radio" name="share-mode" data-share="mode" value="emails"${c.mode === "emails" ? " checked" : ""}><span>只有指定的 Gmail</span></label></div>
        ${c.mode === "emails" ? `<textarea class="plain-in" id="share-emails" data-share="emails" rows="3" placeholder="一行一個 Gmail，例如：friend@gmail.com">${esc((c.emails || []).join("\n"))}</textarea>` : ""}</div>
      <div class="field col"><span class="lab">顯示內容</span><div class="seg" role="radiogroup">
        <label><input type="radio" name="share-detail" data-share="detail" value="title"${c.detail !== "busy" ? " checked" : ""}><span>工作名稱</span></label>
        <label><input type="radio" name="share-detail" data-share="detail" value="busy"${c.detail === "busy" ? " checked" : ""}><span>只顯示「忙碌」</span></label></div></div>
      <div class="field col"><span class="lab">分享多久的行程</span><div class="seg" role="radiogroup">
        ${[7, 14, 30].map(n => `<label><input type="radio" name="share-range" data-share="range" value="${n}"${(+c.range || 14) === n ? " checked" : ""}><span>${n} 天</span></label>`).join("")}</div></div>
      <button class="opt" data-act="share-off"><span class="main" style="color:var(--danger)">停止分享<small>連結會失效，朋友就看不到了</small></span></button>`;
  }
  h += `</div><p class="footnote">${c.on ? "你的行程有變動時，分享的內容會自動更新。備註、地點不會分享出去。" : "不分享也可以看朋友分享給你的行程。"}</p></section>`;
  h += `<section class="sec"><div class="sechead"><h2>追蹤的人</h2></div><div class="list">
    <button class="frow" data-act="person" data-pid="me">${avHTML("me", "我", myColor())}<span class="fn">我<small>點一下換頭貼、顏色</small></span><span class="chev" aria-hidden="true">›</span></button>
    ${follows.length ? follows.map((f, i) => `<button class="frow" data-act="person" data-pid="${esc(f.id)}">${avHTML(f.id, personName(f), personColor(f, i))}<span class="fn">${esc(personName(f))}${f.alias && f.name && f.alias !== f.name ? `<small>對方的名字：${esc(f.name)}</small>` : `<small>點一下改名字、頭貼、顏色</small>`}</span><span class="chev" aria-hidden="true">›</span></button>`).join("")
      : `<div class="empty">還沒有。請朋友在排程本的「共享」頁按「開始分享」，把連結傳給你，打開就會自動加進來。</div>`}
  </div>
  <div class="form" style="margin-top:10px"><div class="field col"><span class="lab">貼上朋友的分享連結</span><input type="text" class="plain-in" id="share-add" placeholder="https://…/#share=…" autocomplete="off">
    <button class="btn" data-act="share-add" style="align-self:flex-start">${I.plus}加入</button></div></div></section>`;
  return h;
}
function viewFriend(id) {
  const f = (S.settings.follows || []).find(x => x.id === id) || { id, name: "朋友" };
  const st = friendCache[id] || { loading: true };
  watchFriend(id);
  const fi = (S.settings.follows || []).findIndex(x => x.id === id), pc = personColor(f, fi);
  let h = `<header class="pagehead has-back"><div><h1>${avHTML(id, personName(f), pc, "hav")}${esc(f.alias || (st.data && st.data.name) || f.name)}</h1><div class="sub">${st.data ? `更新於 ${new Date(st.data.updated).toLocaleString("zh-TW", { month: "numeric", day: "numeric", hour: "2-digit", minute: "2-digit" })}` : ""}</div></div>
    <div class="headbtns"><button class="backbtn" data-act="share-back" aria-label="返回共享">${I.left}共享</button></div></header>`;
  if (st.loading) return h + `<div class="gate"><div class="spinner" aria-hidden="true"></div><p>讀取中…</p></div>`;
  if (st.missing) return h + `<div class="empty">對方已經停止分享，或連結打錯了。</div><button class="btn" data-act="share-unfollow" data-sid="${esc(id)}">從清單移除</button>`;
  if (st.denied || st.error) return h + `<div class="gate-err">${st.denied ? "看不到這份行程：可能對方已經停止分享，或只開放給指定的 Gmail。可以請對方在「共享 › 誰可以看」加上你的 Gmail：" + esc((FB.user && FB.user.email) || "") : esc(st.error)}</div><button class="btn" data-act="share-unfollow" data-sid="${esc(id)}" style="margin-top:10px">從清單移除</button>`;
  const d = st.data, items = d.items || [];
  const t0 = today(), sel = ui.friendDay && ui.friendDay >= t0 ? ui.friendDay : t0;
  let strip = `<nav class="dstrip" aria-label="選日期">`;
  for (let i = 0; i < Math.min(30, d.range || 14); i++) {
    const k = addDays(t0, i), n = items.filter(x => x.d === k && !x.x).length;
    strip += `<button class="dp${k === t0 ? " today" : ""}${k === sel ? " sel" : ""}" data-act="friend-day" data-date="${k}"><span class="w">${k === t0 ? "今天" : "週" + WD[parse(k).getDay()]}</span><span class="n num">${parse(k).getDate()}</span><span class="c">${n ? `<i style="width:${Math.min(100, n * 20)}%"></i>` : ""}</span></button>`;
  }
  strip += `</nav>`;
  const list = items.filter(x => x.d === sel).sort((a, b) => (a.s ?? 9999) - (b.s ?? 9999));
  const free = commonFree(sel, items, d);
  h += strip;
  h += `<section class="sec"><div class="sechead"><h2>${full(sel)}</h2><span class="aside">${list.length} 項</span></div><div class="list">
    ${list.length ? list.map(x => `<div class="row frow2${x.x ? " cancelled" : ""}${x.ok ? " done" : ""}"><span class="evbar" style="--c:${pc}"></span><div class="rbody"><div class="rtitle">${esc(x.t || "忙碌")}</div><div class="meta"><span class="time">${x.s != null ? `${hm(x.s)}–${hm(x.s + x.m)}` : `沒有固定時間・${dur(x.m)}`}</span>${x.ev ? "<span>固定事件</span>" : ""}${x.x ? `<span class="cxl">已取消</span>` : ""}${x.ok ? "<span>已完成</span>" : ""}</div></div></div>`).join("")
      : `<div class="empty">這天沒有安排。</div>`}</div></section>`;
  h += `<section class="sec"><div class="sechead"><h2>你們都有空的時間</h2></div><div class="list">
    ${free.length ? free.map(([a, b]) => `<div class="row"><div class="rbody"><div class="rtitle">${hm(a)}–${hm(b)}</div><div class="meta"><span>${dur(b - a)}</span></div></div><button class="btn sm" data-act="friend-meet" data-date="${sel}" data-s="${a}" data-e="${Math.min(b, a + 60)}" data-name="${esc(d.name)}" style="align-self:center">約這個時間</button></div>`).join("")
      : `<div class="empty">這天在工作時段內沒有共同的空檔。</div>`}</div>
    <p class="footnote">只看雙方工作時段內、至少 30 分鐘的空檔；吃飯時間和固定事件都會避開。${d.detail === "busy" ? "對方只分享「忙碌」，看不到內容。" : ""}</p></section>
    <button class="opt" data-act="share-unfollow" data-sid="${esc(id)}"><span class="main" style="color:var(--danger)">不再追蹤${esc(d.name)}</span></button>`;
  return h;
}
/** 打開分享連結（#share=...）：登入後自動加進朋友清單並打開 */
function checkShareHash() {
  const id = parseShareId(location.hash) || (() => { try { return sessionStorage.getItem("planflow-pending-share"); } catch (e) { return null; } })();
  if (!id) return;
  if (!FB.loaded) { try { sessionStorage.setItem("planflow-pending-share", id); } catch (e) {} return; }
  try { sessionStorage.removeItem("planflow-pending-share"); } catch (e) {}
  if (location.hash) history.replaceState(null, "", location.pathname + location.search);
  if (followShare(id)) { ui.tab = "share"; ui.shareView = id; renderMain(); animateView("enter-right"); }
}
window.addEventListener("hashchange", checkShareHash);

/* ===================== 備忘錄：每天一頁，可以打字、錄音 ===================== */
S.memos = {};                                   // { "YYYY-MM-DD": { text, clips: [...] } }
const memoRef = k => userRef().collection("memos").doc(k);
const audioRef = id => userRef().collection("memoAudio").doc(id);
const SEG_SEC = window.__pfSegSec || 600;                            // 錄音不限長度：每 10 分鐘切一段先存上去（中途關掉也不會全部不見）
const PART = 700000;                            // 每一份最多 70 萬字元（Firestore 一份文件上限 1MB）
function subscribeMemos() {
  FB.unsub.push(userRef().collection("memos").onSnapshot(qs => {
    if (qs.metadata && qs.metadata.fromCache && !qs.size && Object.keys(S.memos || {}).length) return;   // 本機快取還是空的 → 先用暫存
    const m = {};
    qs.forEach(d => { const x = d.data() || {}; m[d.id] = { text: x.text || "", clips: Array.isArray(x.clips) ? x.clips : [], updated: x.updated || 0 }; });
    // 還沒存上去的那幾天，以手機上的為準（不要被雲端舊的蓋掉）
    for (const k in memoUI.pending) if (S.memos[k]) m[k] = S.memos[k];
    S.memos = m; saveSnap();
    if (ui.tab === "memo" && !ui.sheet && !memoUI.typing && !memoUI.rec) renderMain();
  }, () => {}));
}
const memoUI = { dirty: null, typing: false, rec: null, dict: null, t: 0, playing: null, pending: {}, ver: {} };
function memoOf(k) { return S.memos[k] || (S.memos[k] = { text: "", clips: [] }); }
function saveMemo(k, now) {
  memoUI.dirty = k; memoUI.pending[k] = true;
  const v = memoUI.ver[k] = (memoUI.ver[k] || 0) + 1;
  clearTimeout(memoUI.t);
  memoUI.t = setTimeout(() => {
    const m = memoOf(k);
    m.updated = Date.now();
    memoRef(k).set({ date: k, text: m.text, clips: m.clips, updated: m.updated })
      .then(() => { if (memoUI.ver[k] === v) { delete memoUI.pending[k]; if (memoUI.dirty === k) memoUI.dirty = null; } const st = document.getElementById("memo-st"); if (st) st.textContent = "已儲存"; })
      .catch(e => toast("備忘錄存檔失敗：" + fbError(e)));
  }, now ? 0 : 700);
  const st = document.getElementById("memo-st"); if (st) st.textContent = "儲存中…";
}
function viewMemo() {
  const t0 = today(), sel = ui.memoDate || t0, m = memoOf(sel);
  let h = head("備忘錄", sel === t0 ? `今天・${full(t0)}` : full(sel));
  // 日期列：最近 21 天，有內容的有點點
  let strip = `<nav class="dstrip" id="dstrip-memo" aria-label="選日期">`;
  for (let i = -20; i <= 0; i++) {
    const k = addDays(t0, i), x = S.memos[k], has = x && (x.text.trim() || x.clips.length);
    strip += `<button class="dp${k === t0 ? " today" : ""}${k === sel ? " sel" : ""}" data-act="memo-day" data-date="${k}"><span class="w">${k === t0 ? "今天" : "週" + WD[parse(k).getDay()]}</span><span class="n num">${parse(k).getDate()}</span><span class="c">${has ? `<i style="width:100%"></i>` : ""}</span></button>`;
  }
  h += strip + `</nav>`;
  const rec = memoUI.rec;
  h = h.replace(`<nav class="dstrip" id="dstrip-memo"`, `<div class="ctrl memo-ctrl"><nav class="dstrip" id="dstrip-memo"`);
  h += `<section class="sec memo-sec"><div class="sechead"><h2>${sel === t0 ? "今天的備忘錄" : md(sel) + " 的備忘錄"}</h2><span class="aside" id="memo-st">${memoUI.dirty === sel ? "儲存中…" : m.updated ? "已儲存" : ""}</span></div>
    <div class="memo-card">
      <textarea id="memo-text" class="memo-text" placeholder="${FB.preview ? "正在連上雲端…" : "今天想記下什麼？打字或錄音都可以。"}" data-date="${sel}"${FB.preview ? " readonly" : ""}>${esc(m.text)}</textarea>
      ${rec ? `<div class="recbar"><span class="dot"></span><b id="rec-time">0:00</b><span class="meter"><i id="rec-level"></i></span><small id="rec-live">錄音中…</small><button class="btn sm stop" data-act="memo-stop">${I.check}完成</button></div>` : ""}
      <div class="memo-tools">
        <button class="mbtn rec${rec ? " on" : ""}" data-act="${rec ? "memo-stop" : "memo-rec"}"><span class="ic">${rec ? "■" : "●"}</span>${rec ? "停止" : "錄音"}</button>
        <button class="mbtn" data-act="memo-todo"><span class="ic">${I.wand}</span>轉成待辦</button>
      </div>
    </div></section></div>`;
  if (m.clips.length) {
    h += `<section class="sec"><div class="sechead"><h2>錄音</h2><span class="aside">${m.clips.length} 段</span></div><div class="list">
      ${m.clips.map(c => `<div class="clip" data-cid="${c.id}">
        <div class="ctop"><button class="play${memoUI.playing === c.id ? " on" : ""}" data-act="clip-play" data-cid="${c.id}" aria-label="播放">${memoUI.playing === c.id ? "❚❚" : "▶"}</button>
          <span class="cinfo"><b>${new Date(c.created).toLocaleTimeString("zh-TW", { hour: "2-digit", minute: "2-digit" })}</b><small>${fmtDur(c.dur)}・${(c.size || 0) >= 1048576 ? ((c.size / 1048576).toFixed(1) + " MB") : Math.round((c.size || 0) / 1024) + " KB"}${c.live && !(memoUI.rec && memoUI.rec.id === c.id) ? "・錄到一半中斷，前面的有存到" : c.live ? "・錄音中，已先存前面" : ""}</small></span>
          <button class="x" data-act="clip-del" data-cid="${c.id}">刪除</button></div>
      </div>`).join("")}</div>
      <p class="footnote">錄音存在你的帳號裡，手機和電腦都聽得到。</p></section>`;
  }
  const past = Object.keys(S.memos).filter(k => k !== sel && (S.memos[k].text.trim() || S.memos[k].clips.length)).sort().reverse().slice(0, 30);
  if (past.length) h += `<section class="sec"><div class="sechead"><h2>之前的備忘錄</h2></div><div class="list">${past.map(k => { const x = S.memos[k];
    return `<button class="frow" data-act="memo-day" data-date="${k}"><span class="av memo" aria-hidden="true">${parse(k).getDate()}</span><span class="fn">${md(k)}<small>${esc((x.text.trim().split("\n")[0] || "").slice(0, 40)) || "（只有錄音）"}${x.clips.length ? `・${x.clips.length} 段錄音` : ""}</small></span><span class="chev" aria-hidden="true">›</span></button>`; }).join("")}</div></section>`;
  return h;
}
/* ---- 錄音 ---- */
function pickMime() {
  const c = ["audio/webm;codecs=opus", "audio/mp4", "audio/webm", "audio/ogg;codecs=opus"];
  if (!window.MediaRecorder) return null;
  for (const m of c) { try { if (MediaRecorder.isTypeSupported(m)) return m; } catch (e) {} }
  return "";
}
async function startRec() {
  if (memoUI.rec) return;
  const mime = pickMime();
  if (mime === null || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) { toast("這個瀏覽器不能錄音"); return; }
  let stream;
  try { stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } }); }
  catch (e) { toast(/NotAllowed|Permission/i.test(e && e.name) ? "沒有麥克風權限：到手機設定允許排程本使用麥克風" : "打不開麥克風"); return; }
  const k = ui.memoDate || today();
  const rec = memoUI.rec = { stream, mime, k, id: uid() + uid(), start: Date.now(), segs: [], q: Promise.resolve(), text: "", prevText: "", stopping: false };
  startSeg(rec);
  // 錄音時讓螢幕不要自己關掉（螢幕一關，手機可能會停止錄音）
  try { if (navigator.wakeLock) navigator.wakeLock.request("screen").then(l => { rec.lock = l; }).catch(() => {}); } catch (e) {}
  // 計時、每 10 分鐘換一段（用 setInterval，切到背景也照跑）
  rec.iv = setInterval(() => {
    if (memoUI.rec !== rec) return;
    const sec = (Date.now() - rec.start) / 1000;
    const tm = document.getElementById("rec-time"); if (tm) tm.textContent = fmtDur(sec);
    if (!rec.stopping && rec.cur && (Date.now() - rec.cur.t0) / 1000 >= SEG_SEC) { const old = rec.cur; startSeg(rec); try { old.mr.stop(); } catch (e) {} }
  }, 500);
  // 音量條
  try {
    const AC = window.AudioContext || window.webkitAudioContext, ac = new AC(), an = ac.createAnalyser();
    ac.createMediaStreamSource(stream).connect(an); an.fftSize = 256; const buf = new Uint8Array(an.frequencyBinCount);
    rec.ac = ac;
    const tick = () => {
      if (memoUI.rec !== rec) return;
      an.getByteTimeDomainData(buf); let mx = 0; for (const v of buf) mx = Math.max(mx, Math.abs(v - 128));
      const lv = document.getElementById("rec-level"); if (lv) lv.style.transform = `scaleX(${Math.min(1, mx / 64).toFixed(2)})`;
      requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  } catch (e) {}
  renderMain();
}
const fmtDur = sec => { sec = Math.max(0, Math.round(sec)); const h = Math.floor(sec / 3600), m = Math.floor(sec % 3600 / 60), s2 = String(sec % 60).padStart(2, "0"); return h ? `${h}:${String(m).padStart(2, "0")}:${s2}` : `${m}:${s2}`; };
/** 開一段新的錄音（每段都是完整、可以單獨播放的檔案） */
function startSeg(rec) {
  const mr = new MediaRecorder(rec.stream, rec.mime ? { mimeType: rec.mime, audioBitsPerSecond: 32000 } : undefined);
  const seg = rec.cur = { mr, chunks: [], t0: Date.now() };
  mr.ondataavailable = e => { if (e.data && e.data.size) seg.chunks.push(e.data); };
  mr.onstop = () => { seg.t1 = Date.now(); rec.q = rec.q.then(() => saveSeg(rec, seg)).catch(e => toast("錄音存檔失敗：" + fbError(e))); if (rec.stopping && rec.cur === seg) rec.q = rec.q.then(() => finishRec(rec)); };
  mr.start(1000);
}
/** 一段錄完：上傳，然後更新備忘錄裡這段錄音的資料 */
async function saveSeg(rec, seg) {
  const type = ((seg.mr.mimeType || rec.mime || "audio/webm").split(";")[0]) || "audio/webm";
  const blob = new Blob(seg.chunks, { type });
  if (!blob.size) return;
  const j = rec.segs.length, key = `${rec.id}_${j}`;
  const b64 = await new Promise(r => { const fr = new FileReader(); fr.onload = () => r(String(fr.result).split(",")[1] || ""); fr.readAsDataURL(blob); });
  const n = Math.max(1, Math.ceil(b64.length / PART));
  for (let i = 0; i < n; i++) await audioRef(`${key}_${i}`).set({ data: b64.slice(i * PART, (i + 1) * PART), i, n, mime: type });
  memoUI.blobs = memoUI.blobs || {}; memoUI.blobs[key] = blob;
  rec.segs.push({ n, dur: Math.max(1, Math.round((seg.t1 - seg.t0) / 1000)), size: blob.size });
  const m = memoOf(rec.k);
  const clip = { id: rec.id, mime: type, created: rec.start, segs: rec.segs.slice(), dur: rec.segs.reduce((a, x) => a + x.dur, 0), size: rec.segs.reduce((a, x) => a + x.size, 0), live: !rec.stopping };
  const i0 = m.clips.findIndex(x => x.id === rec.id);
  m.clips = i0 < 0 ? [...m.clips, clip] : m.clips.map(x => x.id === rec.id ? { ...x, ...clip } : x);
  saveMemo(rec.k, true);
}
function stopRec() {
  const rec = memoUI.rec; if (!rec || rec.stopping) return;
  rec.stopping = true;
  try { rec.cur.mr.state !== "inactive" ? rec.cur.mr.stop() : (rec.q = rec.q.then(() => finishRec(rec))); } catch (e) { rec.q = rec.q.then(() => finishRec(rec)); }
  clearInterval(rec.iv);
  rec.stream.getTracks().forEach(t => t.stop());
  try { rec.ac && rec.ac.close(); } catch (e) {}
  try { rec.lock && rec.lock.release(); } catch (e) {}
  memoUI.rec = null;
  renderMain();
  if (rec.segs.length || (Date.now() - rec.cur.t0) > 60000) toast("錄音存檔中…");
}
async function finishRec(rec) {
  const m = memoOf(rec.k), c = m.clips.find(x => x.id === rec.id);
  if (!c) { if (ui.tab === "memo") renderMain(); return; }
  c.live = false;
  saveMemo(rec.k, true);
  if (ui.tab === "memo" && !memoUI.typing) renderMain();
  toast("錄音存好了");
}
/** 一段錄音可能有好幾個小段（舊版錄音只有一段） */
const clipSegList = c => c.segs ? c.segs.map((x, j) => ({ key: `${c.id}_${j}`, n: x.n })) : [{ key: c.id, n: c.parts || 1 }];
async function segBlob(c, j) {
  memoUI.blobs = memoUI.blobs || {};
  const sg = clipSegList(c)[j]; if (!sg) throw new Error("找不到錄音檔");
  if (memoUI.blobs[sg.key]) return memoUI.blobs[sg.key];
  if (!c.segs && memoUI.blobs[c.id]) return memoUI.blobs[c.id];
  let b64 = "";
  for (let i = 0; i < sg.n; i++) {
    const d = await audioRef(`${sg.key}_${i}`).get();
    if (!d.exists) throw new Error("找不到錄音檔");
    b64 += d.data().data || "";
  }
  const bin = atob(b64), u8 = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
  return (memoUI.blobs[sg.key] = new Blob([u8], { type: c.mime || "audio/webm" }));
}
const clipBlob = c => segBlob(c, 0);
let memoAudio = null;
async function playClip(k, cid) {
  const c = memoOf(k).clips.find(x => x.id === cid); if (!c) return;
  if (memoUI.playing === cid && memoAudio) { memoAudio.pause(); memoAudio = null; memoUI.playing = null; renderMain(); return; }
  if (memoAudio) { memoAudio.pause(); memoAudio = null; }
  const total = clipSegList(c).length;
  const playSeg = async j => {
    const blob = await segBlob(c, j);
    if (memoUI.playing !== cid && j > 0) return;            // 中途按了暫停
    const a = memoAudio = new Audio(URL.createObjectURL(blob));
    a.onended = () => { if (memoAudio !== a) return; if (j + 1 < total) playSeg(j + 1).catch(e => toast("播放失敗：" + (e.message || e))); else { memoAudio = null; memoUI.playing = null; if (ui.tab === "memo") renderMain(); } };
    if (j + 1 < total) segBlob(c, j + 1).catch(() => {});     // 先把下一段載好，接起來比較順
    await a.play();
  };
  try { memoUI.playing = cid; await playSeg(0); renderMain(); }
  catch (e) { memoUI.playing = null; toast("播放失敗：" + (e.message || e)); renderMain(); }
}

/* ---------- 時間到了還沒做完：詢問 ---------- */
const dueSnooze = {};
function dueTasks() {
  const t0 = today(), now = nowMin(), ts = Date.now();
  return S.tasks.filter(t => t.date === t0 && !t.done && !isEvent(t) && t.start != null && t.start + t.min <= now && !(dueSnooze[t.id] > ts))
    .sort((a, b) => a.start - b.start);
}
function checkDue() {
  checkNotify();
  if (!FB.loaded || S.settings.reflowMode !== "ask" || ui.sheet || document.visibilityState !== "visible") return;
  const list = dueTasks();
  if (list.length) openSheet({ type: "due", ids: list.map(t => t.id) });
}

/* ---------- 外觀風格：iOS 6 擬物 / 液態玻璃 ---------- */
const SKIN_CACHE = "planflow-skin";
function applySkin(sk) {
  const v = sk === "glass" || sk === "oldschool" ? sk : "ios6";
  document.documentElement.dataset.skin = v;
  try { localStorage.setItem(SKIN_CACHE, v); } catch (e) {}
}
try { applySkin(localStorage.getItem(SKIN_CACHE) || "ios6"); } catch (e) { applySkin("ios6"); }

/* ---------- 背景照片（存在自己帳號，手機電腦同步；本機也留一份加快顯示） ---------- */
const BG_CACHE = "planflow-bg";
let bgData = "";
function applyBg(data, dim) {
  bgData = data || "";
  const el = document.getElementById("bgphoto");
  const shade = dim ? "linear-gradient(rgba(0,0,0,.28), rgba(0,0,0,.28)), " : "";
  if (el) el.style.backgroundImage = bgData ? `${shade}url("${bgData}")` : "";
  document.documentElement.classList.toggle("has-photo", !!bgData);
  applyTone(bgData, dim);
}
/** 量照片的亮度：亮的背景用黑字、暗的背景用白字 */
let toneJob = 0;
function applyTone(data, dim) {
  const root = document.documentElement, job = ++toneJob;
  if (!data) { root.classList.remove("bg-dark", "bg-light"); return; }
  const img = new Image();
  img.onload = () => {
    if (job !== toneJob) return;
    try {
      const W = 40, H = Math.max(1, Math.round(40 * img.height / img.width));
      const c = document.createElement("canvas"); c.width = W; c.height = H;
      const g = c.getContext("2d"); g.drawImage(img, 0, 0, W, H);
      const px = g.getImageData(0, 0, W, H).data;
      const lin = v => { v /= 255; return v <= 0.04045 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); };
      let sum = 0, n = 0;
      for (let i = 0; i < px.length; i += 4) { sum += 0.2126 * lin(px[i]) + 0.7152 * lin(px[i + 1]) + 0.0722 * lin(px[i + 2]); n++; }
      let L = sum / n;
      if (dim) L *= 0.72;                                   // 「照片調暗」會蓋一層 28% 黑色
      // 白字對比 (1.05)/(L+.05)、黑字對比 (L+.05)/(.05)，哪個大用哪個
      const dark = (1.05 / (L + 0.05)) >= ((L + 0.05) / 0.05);
      root.classList.toggle("bg-dark", dark); root.classList.toggle("bg-light", !dark);
      root.dataset.bgL = L.toFixed(3);
    } catch (e) { root.classList.add("bg-dark"); root.classList.remove("bg-light"); }
  };
  img.src = data;
}
try { const c = localStorage.getItem(BG_CACHE); if (c) applyBg(c, true); } catch (e) {}
function bgRef() { return userRef().collection("assets").doc("background"); }
function subscribeBg() {
  FB.unsub.push(bgRef().onSnapshot(snap => {
    const d = snap.exists ? (snap.data() || {}) : {};
    applyBg(d.data || "", d.dim !== false);
    try { if (d.data) localStorage.setItem(BG_CACHE, d.data); else localStorage.removeItem(BG_CACHE); } catch (e) {}
    if (ui.tab === "settings" && !ui.sheet) renderMain();
  }, () => {}));
}
/** 把照片縮小壓縮（長邊 1400px、JPEG），避免太大 */
function shrinkImage(file, max = 1400, limit = 700000) {
  return new Promise((resolve, reject) => {
    const fr = new FileReader();
    fr.onerror = () => reject(new Error("讀不到照片"));
    fr.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error("這個檔案不是可以用的照片"));
      img.onload = () => {
        const r = Math.min(1, max / Math.max(img.width, img.height));
        const c = document.createElement("canvas");
        c.width = Math.round(img.width * r); c.height = Math.round(img.height * r);
        c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
        let q = 0.78, out = c.toDataURL("image/jpeg", q);
        while (out.length > limit && q > 0.4) { q -= 0.1; out = c.toDataURL("image/jpeg", q); }
        resolve(out);
      };
      img.src = fr.result;
    };
    fr.readAsDataURL(file);
  });
}
document.getElementById("bg-file").addEventListener("change", async e => {
  const f = e.target.files && e.target.files[0];
  e.target.value = "";
  if (!f) return;
  try {
    toast("正在處理照片…");
    const data = await shrinkImage(f);
    applyBg(data, S.settings.bgDim !== false);
    try { localStorage.setItem(BG_CACHE, data); } catch (e2) {}
    if (FB.user) await bgRef().set({ data, dim: S.settings.bgDim !== false, updated: Date.now() });
    toast("已換上新的背景");
    renderMain();
  } catch (err) { toast(err.message || "照片處理失敗"); }
});

document.addEventListener("input", e => { if (ui.sheet && ui.sheet.type === "ai" && e.target.closest && e.target.closest("#sheet .pv-card")) ui.sheet.touched = true; }, true);
document.addEventListener("change", e => { if (ui.sheet && ui.sheet.type === "ai" && e.target.closest && e.target.closest("#sheet .pv-card")) ui.sheet.touched = true; }, true);
document.addEventListener("input", e => {
  if (e.target.id === "memo-text") {
    const ta = e.target, k = ta.dataset.date;
    memoOf(k).text = ta.value; memoUI.typing = true; saveMemo(k);
    ta.style.height = "auto"; ta.style.height = Math.max(180, ta.scrollHeight + 2) + "px";
    clearTimeout(memoUI.tt); memoUI.tt = setTimeout(() => { memoUI.typing = false; }, 1500);
    return;
  }
  if (e.target.id === "brain-try") { const o = document.getElementById("brain-out"); if (o) o.innerHTML = brainTryText(e.target.value); }
});
/* ---------- 通知 ---------- */
const NOTE_KEY = "planflow-notified";
const notifySupported = () => "Notification" in window && "serviceWorker" in navigator;
const isStandalone = () => (window.matchMedia && matchMedia("(display-mode: standalone)").matches) || navigator.standalone === true;
const isIOS = () => /iPhone|iPad|iPod/.test(navigator.userAgent) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
function notePerm() { return notifySupported() ? Notification.permission : "unsupported"; }
let noted = {};
try { noted = JSON.parse(localStorage.getItem(NOTE_KEY) || "{}") || {}; } catch (e) { noted = {}; }
function markNoted(k) {
  noted[k] = today();
  if (FB.user && !/^test|^welcome/.test(k)) userRef().collection("meta").doc("pushlog").set({ sent: { [k]: today() } }, { merge: true }).catch(() => {});
  const t0 = today(); for (const x in noted) if (noted[x] < addDays(t0, -2)) delete noted[x];
  try { localStorage.setItem(NOTE_KEY, JSON.stringify(noted)); } catch (e) {}
}
async function notify(title, body, tag) {
  if (notePerm() !== "granted") return false;
  const opt = { body, tag, icon: "/icon-192.png", badge: "/icon-192.png", renotify: false, data: { tag } };
  try {
    const reg = await navigator.serviceWorker.getRegistration() || await navigator.serviceWorker.ready;
    if (reg && reg.showNotification) { await reg.showNotification(title, opt); return true; }
  } catch (e) { console.warn("notify", e); }
  try { new Notification(title, opt); return true; } catch (e) { return false; }
}
/** 每 30 秒看一次：快開始的工作、今天截止的、時間到還沒做完的 */
function checkNotify() {
  const s = S.settings;
  if (!FB.loaded || !s.notifyOn || notePerm() !== "granted") return;
  const t0 = today(), now = nowMin(), lead = Math.max(0, +s.notifyLead || 0);
  for (const t of S.tasks) {
    if (t.date !== t0 || t.done || t.start == null) continue;
    const k = `s@${t.id}@${t0}@${t.start}`;
    if (noted[k]) continue;
    // 提前 N 分鐘到開始後 5 分鐘之內才通知（太晚打開 App 就不補發）
    if (now >= t.start - lead && now <= t.start + 5) {
      const left = t.start - now;
      const head = left > 0 ? `${left} 分鐘後` : "現在開始";
      const c = cat(t.cat);
      notify(`${head}：${t.title}`, `${range(t)}${c ? ` · ${c.name}` : ""}${t.notes ? `\n${t.notes.split("\n")[0]}` : ""}`, k);
      markNoted(k);
    }
  }
  if (s.notifyDeadline && now >= s.workStart && !noted[`dl@${t0}`]) {
    const due0 = S.tasks.filter(t => !t.done && t.deadline === t0), due1 = S.tasks.filter(t => !t.done && t.deadline === addDays(t0, 1));
    if (due0.length || due1.length) {
      const parts = [];
      if (due0.length) parts.push(`今天截止：${due0.map(t => t.title).slice(0, 4).join("、")}${due0.length > 4 ? ` 等 ${due0.length} 項` : ""}`);
      if (due1.length) parts.push(`明天截止：${due1.map(t => t.title).slice(0, 4).join("、")}${due1.length > 4 ? ` 等 ${due1.length} 項` : ""}`);
      notify("截止日提醒", parts.join("\n"), `dl@${t0}`);
    }
    markNoted(`dl@${t0}`);
  }
  if (s.notifyDue && document.visibilityState !== "visible") {
    for (const t of S.tasks) {
      if (t.date !== t0 || t.done || isEvent(t) || t.start == null) continue;
      const end = t.start + t.min, k = `e@${t.id}@${t0}@${end}`;
      if (noted[k] || now < end || now > end + 30) continue;
      notify(`時間到了：${t.title}`, "做完了嗎？打開排程本可以打勾，或往後重新安排。", k);
      markNoted(k);
    }
  }
}
/** 匯出成 .ics，加進 iPhone / Google 行事曆，用行事曆的提醒（App 沒開也會響） */
function exportICS() {
  const t0 = today(), end = addDays(t0, 14), lead = Math.max(0, +S.settings.notifyLead || 0);
  const list = S.tasks.filter(t => !t.done && t.start != null && t.date >= t0 && t.date <= end);
  if (!list.length) { toast("接下來 14 天沒有排好時段的工作"); return; }
  const pad = n => String(n).padStart(2, "0");
  const dt = (k, m) => `${k.replace(/-/g, "")}T${pad(Math.floor(m / 60))}${pad(m % 60)}00`;
  const escI = x => String(x || "").replace(/\\/g, "\\\\").replace(/;/g, "\\;").replace(/,/g, "\\,").replace(/\n/g, "\\n");
  const stamp = new Date().toISOString().replace(/[-:]/g, "").replace(/\.\d+/, "");
  const lines = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//PlanFlow//ZH-TW", "CALSCALE:GREGORIAN", "X-WR-CALNAME:排程本"];
  for (const t of list) {
    const c = cat(t.cat);
    lines.push("BEGIN:VEVENT", `UID:${t.id}-${t.date}@planflow`, `DTSTAMP:${stamp}`, `DTSTART:${dt(t.date, t.start)}`, `DTEND:${dt(t.date, Math.min(t.start + t.min, 1439))}`,
      `SUMMARY:${escI(t.title)}`, ...(t.notes || c ? [`DESCRIPTION:${escI([c && c.name, t.notes].filter(Boolean).join("\n"))}`] : []),
      "BEGIN:VALARM", "ACTION:DISPLAY", `DESCRIPTION:${escI(t.title)}`, `TRIGGER:-PT${lead}M`, "END:VALARM", "END:VEVENT");
  }
  lines.push("END:VCALENDAR");
  const blob = new Blob([lines.join("\r\n")], { type: "text/calendar;charset=utf-8" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob); a.download = `planflow-${t0}.ics`;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 30000);
  toast(`已匯出 ${list.length} 項，打開檔案就能加入行事曆`);
}
/* ---------- 背景推播：App 關掉也收得到（GitHub 上的推播程式每 5 分鐘送一次） ---------- */
const PUSH_KEY = "planflow-push-pk";
let pushState = { status: "unknown" };
const pushSupported = () => "serviceWorker" in navigator && "PushManager" in window && "Notification" in window;
function b64uToU8(str) { let s = str.replace(/-/g, "+").replace(/_/g, "/"); while (s.length % 4) s += "="; const r = atob(s); return Uint8Array.from(r, c => c.charCodeAt(0)); }
async function hashId(str) {
  try { const b = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(str)); return [...new Uint8Array(b)].slice(0, 12).map(x => x.toString(16).padStart(2, "0")).join(""); }
  catch (e) { let h = 0; for (const ch of str) h = (h * 31 + ch.charCodeAt(0)) >>> 0; return "p" + h.toString(16); }
}
/** 向手機訂閱推播，把訂閱資料存到自己的帳號（推播程式會讀） */
async function ensurePush() {
  if (!pushSupported()) { pushState = { status: "unsupported" }; return false; }
  if (!FB.user || Notification.permission !== "granted" || !S.settings.notifyOn) { pushState = { status: "off" }; return false; }
  try {
    const cfg = await FB.db.collection("config").doc("push").get();
    const pk = cfg.exists && cfg.data().publicKey;
    if (!pk) { pushState = { status: "server-missing" }; return false; }
    const reg = await navigator.serviceWorker.ready;
    let sub = await reg.pushManager.getSubscription();
    let stored = ""; try { stored = localStorage.getItem(PUSH_KEY) || ""; } catch (e) {}
    if (sub && stored && stored !== pk) { await sub.unsubscribe().catch(() => {}); sub = null; }   // 推播金鑰換了 → 重新訂閱
    if (!sub) sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64uToU8(pk) });
    const j = sub.toJSON();
    await userRef().collection("push").doc(await hashId(j.endpoint)).set({ endpoint: j.endpoint, keys: j.keys, ua: navigator.userAgent.slice(0, 140), pk, updated: Date.now() });
    try { localStorage.setItem(PUSH_KEY, pk); } catch (e) {}
    if (!S.settings.pushOn) { S.settings.pushOn = true; save(); }
    pushState = { status: "on" };
    return true;
  } catch (e) {
    console.warn("push", e);
    pushState = { status: "error", msg: String((e && e.message) || e).slice(0, 120) };
    return false;
  }
}
/** 跟推播程式共用「送過哪些通知」，同一則不會收到兩次 */
function subscribePushlog() {
  FB.unsub.push(userRef().collection("meta").doc("pushlog").onSnapshot(snap => {
    const sent = (snap.exists && snap.data().sent) || {};
    let ch = false; for (const k in sent) if (!noted[k]) { noted[k] = sent[k]; ch = true; }
    if (ch) { try { localStorage.setItem(NOTE_KEY, JSON.stringify(noted)); } catch (e) {} }
  }, () => {}));
}
function pushStatusHTML() {
  const st = pushState.status;
  if (st === "on") return `<div class="field col"><span class="lab">背景推播：已開啟 ✓<small class="sub">App 關掉、手機鎖定也會收到。推播每 5 分鐘檢查一次，有時會晚幾分鐘；要分秒不差請用「匯出到行事曆」。</small></span></div>`;
  if (st === "server-missing") return `<div class="field col"><span class="lab">背景推播：還沒準備好<small class="sub">GitHub 上的「Push Notifications」排程還沒跑過。照教學新增 push.yml，到 Actions 按一次 Run workflow，再回來按下面的按鈕。</small></span><button class="btn sm" data-act="push-on" style="align-self:flex-start">啟用背景推播</button></div>`;
  if (st === "error") return `<div class="field col"><span class="lab">背景推播沒有開成功<small class="sub">${esc(pushState.msg || "")}</small></span><button class="btn sm" data-act="push-on" style="align-self:flex-start">再試一次</button></div>`;
  if (st === "unsupported") return `<div class="field col"><span class="lab">這裡不支援背景推播<small class="sub">iPhone 要從主畫面的排程本打開（iOS 16.4 以上）。</small></span></div>`;
  return `<div class="field col"><span class="lab">背景推播（App 關掉也收得到）</span><button class="btn sm" data-act="push-on" style="align-self:flex-start">啟用背景推播</button></div>`;
}
/* ===================== Gmail：有加星號的信 → 待辦 ===================== */
// 只要求「讀取」權限（不會改信、不會寄信）。Google 的授權一小時就過期，過期再按一次連結就好。
const GMAIL_SCOPE = "https://www.googleapis.com/auth/gmail.readonly";
const GMAIL_TOKEN = "planflow-gmail", GMAIL_PENDING = "planflow-gmail-pending";
const gmailUI = { busy: false, checked: false, last: null };
function gmailToken() {
  try { const x = JSON.parse(localStorage.getItem(GMAIL_TOKEN) || "null"); if (x && x.t && x.exp > Date.now() + 30000 && (!FB.user || x.uid === FB.user.uid)) return x.t; } catch (e) {}
  return null;
}
function gmailExpMin() { try { const x = JSON.parse(localStorage.getItem(GMAIL_TOKEN) || "null"); return x ? Math.round((x.exp - Date.now()) / 60000) : 0; } catch (e) { return 0; } }
/** 跳到 Google 授權（同一個帳號），回來後自動檢查星號信件 */
function connectGmail() {
  if (!FB.user) { toast("請先登入"); return; }
  try { localStorage.setItem(GMAIL_PENDING, String(Date.now())); } catch (e) {}
  const provider = new firebase.auth.GoogleAuthProvider();
  provider.addScope(GMAIL_SCOPE);
  provider.setCustomParameters({ login_hint: FB.user.email || "" });
  FB.user.reauthenticateWithRedirect(provider).catch(err => { try { localStorage.removeItem(GMAIL_PENDING); } catch (e) {} toast("連結 Gmail 失敗：" + fbError(err)); });
}
/** 從 Google 授權回來：把讀信用的 token 記在這支手機（一小時） */
function gmailFromRedirect(res) {
  let pending = 0; try { pending = +localStorage.getItem(GMAIL_PENDING) || 0; localStorage.removeItem(GMAIL_PENDING); } catch (e) {}
  if (!pending || Date.now() - pending > 15 * 60000) return;
  const tok = res && res.credential && res.credential.accessToken;
  if (!tok) { toast("Gmail 沒有連結成功，再試一次"); return; }
  try { localStorage.setItem(GMAIL_TOKEN, JSON.stringify({ t: tok, exp: Date.now() + 55 * 60000, uid: res.user && res.user.uid })); } catch (e) {}
  gmailUI.afterLoad = "manual";
}
setInterval(() => { if (FB.loaded && S.settings.gmailAuto && !ui.sheet && document.visibilityState === "visible" && gmailToken()) checkGmail(false); }, 10 * 60000);
document.addEventListener("visibilitychange", () => { if (document.visibilityState === "visible" && FB.loaded && S.settings.gmailAuto && !ui.sheet && gmailToken() && Date.now() - (gmailUI.last || 0) > 5 * 60000) checkGmail(false); });
function disconnectGmail() { try { localStorage.removeItem(GMAIL_TOKEN); } catch (e) {} S.settings.gmailAuto = false; commit("已中斷 Gmail 連結"); }
async function gmailFetch(path, tok) {
  const r = await fetch("https://gmail.googleapis.com/gmail/v1/users/me/" + path, { headers: { Authorization: "Bearer " + tok } });
  if (r.status === 401) { try { localStorage.removeItem(GMAIL_TOKEN); } catch (e) {} const er = new Error("授權過期了"); er.expired = true; throw er; }
  if (r.status === 403) { const j = await r.json().catch(() => ({})); const msg = (j.error && j.error.message) || ""; const er = new Error(/has not been used|disabled/i.test(msg) ? "Gmail API 還沒在 Google Cloud 啟用（設定步驟見說明）" : /insufficient|scope/i.test(msg) ? "沒有讀信的權限，請重新連結並勾選允許讀取 Gmail" : "Gmail 拒絕存取：" + msg); throw er; }
  if (!r.ok) throw new Error("Gmail 讀取失敗（" + r.status + "）");
  return r.json();
}
const hdr = (m, n) => ((m.payload && m.payload.headers) || []).find(h => h.name.toLowerCase() === n.toLowerCase())?.value || "";
/** 要抓哪些信：有星號的（可關），加上最近 14 天內容有關鍵字的（不含自己寄出的） */
const gmKws = () => (S.settings.gmailKw || []).map(k => String(k).trim()).filter(Boolean);
function gmailQuery() {
  const parts = [];
  if (S.settings.gmailStar !== false) parts.push("is:starred");
  const kw = gmKws();
  if (kw.length) parts.push(`newer_than:14d -in:sent -in:chats (${kw.map(k => `"${k.replace(/"/g, "")}"`).join(" OR ")})`);
  return parts.map(x => `(${x})`).join(" OR ");
}
/** 讀符合條件、還沒加進待辦的信 */
async function fetchStarred(tok) {
  const seen = new Set(S.settings.gmailSeen || []);
  const q = gmailQuery(); if (!q) return [];
  const list = await gmailFetch("messages?q=" + encodeURIComponent(q) + "&maxResults=30", tok);
  const ids = (list.messages || []).filter(m => !seen.has(m.id)).slice(0, 20);
  const out = [];
  for (const m of ids) {
    const d = await gmailFetch(`messages/${m.id}?format=metadata&metadataHeaders=Subject&metadataHeaders=From&metadataHeaders=Date`, tok);
    const from = hdr(d, "From"), name = (from.match(/^\s*"?([^"<]+?)"?\s*</) || [])[1] || from.replace(/<.*>/, "").trim() || from;
    const subject = (hdr(d, "Subject") || "（沒有主旨）").trim();
    const snippet = (d.snippet || "").replace(/&#39;/g, "'").replace(/&quot;/g, '"').replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").trim();
    const hay = (subject + " " + snippet).toLowerCase(), kw = gmKws().find(k => hay.includes(k.toLowerCase()));
    const why = (d.labelIds || []).includes("STARRED") ? "⭐ 有星號" : kw ? `關鍵字「${kw}」` : "關鍵字";
    out.push({ id: m.id, th: d.threadId || m.threadId, subject, from: name.trim(), when: +d.internalDate || Date.now(), snippet, why });
  }
  return out;
}
/** 檢查星號信件；manual = 使用者自己按的（沒授權就去連結、沒新信也告訴他） */
async function checkGmail(manual) {
  if (gmailUI.busy) return;
  const tok = gmailToken();
  if (!tok) { if (manual) connectGmail(); return; }
  gmailUI.busy = true; if (manual) toast("正在檢查信件…");
  try {
    const items = await fetchStarred(tok);
    gmailUI.last = Date.now();
    if (items.length && S.settings.gmailAutoAdd) autoAddMails(items);
    else if (items.length) { if (ui.sheet && ui.sheet.type !== "ai") { gmailUI.busy = false; return; } openSheet({ type: "gmail", items, pick: Object.fromEntries(items.map(x => [x.id, true])), when: "today" }); }
    else if (manual) toast("沒有新的信要加");
  } catch (e) {
    if (e.expired) { if (manual) connectGmail(); else toast("Gmail 授權過期了，到「設定 › Gmail」再按一次連結"); }
    else toast(e.message || "Gmail 讀取失敗");
  }
  gmailUI.busy = false;
  if (ui.tab === "settings" && !ui.sheet) renderMain();
}
const mailLink = x => `https://mail.google.com/mail/u/0/#all/${x.th || x.id}`;
function sheetGmail(o) {
  const n = o.items.filter(x => o.pick[x.id]).length;
  const fmt = ms => { const d = new Date(ms); return `${d.getMonth() + 1}/${d.getDate()} ${pad(d.getHours())}:${pad(d.getMinutes())}`; };
  const body = `<p class="footnote" style="margin:0">有星號或符合關鍵字、還沒加過的信。改一下標題，勾選要加入的。</p>
    <div class="list">${o.items.map(x => `<div class="row gm${o.pick[x.id] ? "" : " off"}">
      <button class="chk${o.pick[x.id] ? " on" : ""}" data-act="gm-pick" data-mid="${x.id}" aria-label="${o.pick[x.id] ? "不要" : "要"}加入">${I.check}</button>
      <div class="rbody" style="cursor:default"><input class="plain-in gm-title" data-mid="${x.id}" value="${esc(x.subject)}" aria-label="待辦標題">
        <div class="meta">${x.why ? `<span class="gmwhy">${esc(x.why)}</span>` : ""}<span>✉ ${esc(x.from)}</span><span>${fmt(x.when)}</span><a href="${mailLink(x)}" target="_blank" rel="noopener">打開信件</a></div>
        ${x.snippet ? `<div class="rnote">${esc(x.snippet)}</div>` : ""}</div></div>`).join("")}</div>
    <div class="form"><div class="field col"><span class="lab">排在</span><div class="seg">${[["today", "今天"], ["tomorrow", "明天"], ["free", "之後有空"]].map(([k, l]) => `<button class="${o.when === k ? "on" : ""}" data-act="gm-when" data-w="${k}">${l}</button>`).join("")}</div></div></div>
    <button class="btn primary block" data-act="gm-add"${n ? "" : " disabled"}>${I.plus}加入待辦（${n} 封）</button>
    <button class="btn block" data-act="gm-ai"${n ? "" : " disabled"}>${I.spark}交給智慧排程整理（會看懂信裡的日期、截止日）</button>
    <button class="opt" data-act="gm-skip"><span class="main">這些都不要加<small>之後不會再問這幾封</small></span></button>`;
  return sheetWrap("從 Email 加入", cancelBtn("稍後"), spacer, body);
}
function gmReadTitles(o) { document.querySelectorAll("#sheet .gm-title").forEach(i => { const x = o.items.find(y => y.id === i.dataset.mid); if (x) x.subject = i.value.trim() || x.subject; }); }
function gmMarkSeen(ids) { S.settings.gmailSeen = [...new Set([...(S.settings.gmailSeen || []), ...ids])].slice(-400); }
function gmailAdd(o) {
  gmReadTitles(o);
  const pick = o.items.filter(x => o.pick[x.id]);
  const catId = (S.cats.find(c => !c.event && c.name === "工作") || S.cats.find(c => !c.event) || {}).id || "";
  const t0 = today(), ids = [];
  let date = o.when === "tomorrow" ? addDays(t0, 1) : t0;
  for (const x of pick) {
    const id = uid(); ids.push(id);
    S.tasks.push(normalize({ id, title: x.subject, notes: `✉ ${x.from}${x.snippet ? "\n" + x.snippet : ""}\n${mailLink(x)}`, date, deadline: null, pri: 1, min: 30, cat: catId,
      done: false, doneOn: null, resched: 0, created: Date.now(), start: null, locked: false, series: null, occ: null, detached: false }));
  }
  gmMarkSeen(o.items.map(x => x.id));
  if (o.when === "free") { closeSheet(); commit(); openBulk(ids, t0, false); return; }
  arrangeTimes(date, "fill");
  markFresh(ids); closeSheet(); commit(`已加入 ${ids.length} 件待辦`, true);
}
/** 不用問：每封信用智慧輸入看懂日期、時間、要多久，直接加成待辦／事件 */
function autoAddMails(items) {
  snapshot();
  const catId = (S.cats.find(c => !c.event && c.name === "工作") || S.cats.find(c => !c.event) || {}).id || "";
  const added = [];
  for (const x of items) {
    let it = null;
    try {
      // 只看主旨：信的內文常有很多不相干的日期，看主旨比較準
      const parsed = aiParse(JSON.stringify(localParse(x.subject.slice(0, 80))));
      if (parsed.length) it = aiSchedule([{ ...parsed[0], title: x.subject.slice(0, 60), parts: 1, rangeStart: null, rangeEnd: null, repeat: null }])[0];
    } catch (e) {}
    const notes = `✉ ${x.from}（${x.why}）${x.snippet ? "\n" + x.snippet : ""}\n${mailLink(x)}`;
    const t = it ? { ...it, notes } : { id: uid(), title: x.subject.slice(0, 60), notes, date: today(), deadline: null, pri: 1, min: 30, cat: catId, done: false, doneOn: null, resched: 0, created: Date.now(), start: null, locked: false, series: null, occ: null, detached: false };
    delete t.window; delete t._src; delete t._pc; delete t._pm; delete t._pp; delete t.repeat; delete t._g; delete t._p; delete t._n;
    S.tasks.push(normalize(t)); added.push(t);
  }
  gmMarkSeen(items.map(x => x.id));
  [...new Set(added.map(x => x.date))].forEach(k => arrangeTimes(k, "fill"));
  markFresh(added.map(x => x.id));
  commit(`從 Email 加入 ${added.length} 件：${added.slice(0, 2).map(x => x.title).join("、")}${added.length > 2 ? "…" : ""}`, true);
  if (S.settings.notifyOn && document.visibilityState !== "visible") notify("從 Email 加入了新的待辦", added.map(x => x.title).join("\n"), "gm@" + Date.now());
}
function gmailToAI(o) {
  gmReadTitles(o);
  const pick = o.items.filter(x => o.pick[x.id]);
  gmMarkSeen(o.items.map(x => x.id)); save();
  const text = pick.map(x => `${x.subject}（${x.from}：${x.snippet.slice(0, 80)}）`).join("\n");
  ui.sheet = null; openSheet({ type: "ai", step: "input", text });
}
function gmailSectionHTML() {
  const tok = gmailToken(), s = S.settings, kw = gmKws();
  const sw = (k, label, sub, def) => `<div class="field"><label for="gm-${k}">${label}${sub ? `<small style="display:block;font-weight:400;color:var(--muted);font-size:12px">${sub}</small>` : ""}</label><span class="switch"><input type="checkbox" id="gm-${k}" data-set="${k}"${(def ? s[k] !== false : s[k]) ? " checked" : ""}><span></span></span></div>`;
  return `<section class="sec"><div class="sechead"><h2>Gmail</h2><span class="aside">${tok ? `已連結・${gmailExpMin()} 分鐘後要重新連結` : "未連結"}</span></div><div class="form">
    <button class="opt" data-act="gm-check"><span class="main">${tok ? "現在檢查信件" : "連結 Gmail"}<small>${tok ? "把有星號或符合關鍵字的信加進待辦" : "只會讀信（不會修改、刪除或寄信）"}</small></span></button>
    ${sw("gmailAuto", "自動從 Email 加入事件", "打開 App 時、開著時每 10 分鐘檢查一次")}
    ${sw("gmailAutoAdd", "直接加入，不用先問我", "會看懂信裡的日期和時間；加錯了可以按「復原」")}
    ${sw("gmailStar", "有星號的信", "", true)}
    <div class="field col"><span class="lab">關鍵字<small style="display:block;font-weight:400;color:var(--muted);font-size:12px">最近 14 天收到、主旨或內容有這些字的信（自己寄出的不算）</small></span>
      <div class="kwchips">${kw.map(k => `<span class="kwchip">${esc(k)}<button data-act="gm-kw-del" data-kw="${esc(k)}" aria-label="移除關鍵字 ${esc(k)}">${I.x}</button></span>`).join("") || `<small style="color:var(--muted)">還沒有關鍵字</small>`}</div>
      <div class="kwadd"><input type="text" id="gm-kw" class="plain-in" maxlength="30" placeholder="例如：開會、截止、deadline"><button class="btn sm" data-act="gm-kw-add">${I.plus}加入</button></div></div>
    ${tok ? `<button class="opt" data-act="gm-off"><span class="main" style="color:var(--danger)">中斷連結</span></button>` : ""}
  </div><p class="footnote">在 Gmail 幫信加上星號，或信裡有你設定的關鍵字，排程本就會把它加成待辦（或先問你）；加過的信不會再處理。Google 的授權每小時會過期，過期後打開 App 會提醒你按一下重新連結。</p></section>`;
}
function notifySectionHTML() {
  const s = S.settings, perm = notePerm();
  const sw = (k, label) => `<div class="field"><label for="sw-${k}">${label}</label><span class="switch"><input type="checkbox" id="sw-${k}" data-set="${k}"${s[k] ? " checked" : ""}><span></span></span></div>`;
  let status, note;
  if (perm === "unsupported") {
    status = `<div class="field col"><span class="lab"><span class="nt-ic">${I.bell}</span> 這個瀏覽器不能直接通知</span></div>`;
    note = isIOS() && !isStandalone() ? "iPhone 要先在 Safari 按「分享 › 加入主畫面」，從主畫面的排程本打開，才會出現開啟通知的按鈕（需要 iOS 16.4 以上）。" : "可以改用下面的「匯出到行事曆」，用行事曆的提醒。";
  } else if (perm === "denied") {
    status = `<div class="field col"><span class="lab"><span class="nt-ic">${I.bell}</span> 通知被關掉了</span></div>`;
    note = isIOS() ? "到 iPhone「設定 › 通知 › 排程本」把「允許通知」打開，再回來這裡。" : "到瀏覽器的網站設定，把這個網站的通知改成「允許」。";
  } else if (perm !== "granted" || !s.notifyOn) {
    status = `<button class="btn primary block" data-act="notify-on"><span class="nt-ic">${I.bell}</span>開啟通知</button>`;
    note = "開啟後，工作開始前、截止日當天、時間到了還沒做完都會通知你。";
  } else {
    status = `${sw("notifyOn", "通知")}
      <div class="field"><label for="set-lead">開始前幾分鐘提醒</label><span class="durpick"><input type="number" inputmode="numeric" id="set-lead" min="0" max="240" step="5" value="${s.notifyLead}" data-setnum="notifyLead"><span>分鐘</span></span></div>
      ${sw("notifyDeadline", "截止日當天和前一天提醒")}
      ${sw("notifyDue", "時間到了還沒做完提醒")}
      ${pushStatusHTML()}
      <button class="opt" data-act="notify-test"><span class="main">傳送測試通知</span></button>`;
    note = pushState.status === "on" ? "App 開著時會馬上通知；關掉時由背景推播送出。" : "沒有開背景推播時，排程本要在背景還開著才會送出通知（iPhone 把它滑掉關閉後就收不到）。";
  }
  return `<section class="sec"><div class="sechead"><h2>通知</h2></div><div class="form">
    ${status}
    <button class="opt" data-act="notify-ics"><span class="main">匯出到行事曆（含提醒）<small>接下來 14 天排好時段的工作，加進 iPhone 或 Google 行事曆，App 沒開也會準時響</small></span></button>
  </div><p class="footnote">${note}</p></section>`;
}

/* ---------- 智慧排程的附件（課表、PDF、截圖） ---------- */
const AI_FILE_MAX = 4;
function fileAsDataURL(f) {
  return new Promise((res, rej) => { const fr = new FileReader(); fr.onerror = () => rej(new Error("讀不到檔案")); fr.onload = () => res(fr.result); fr.readAsDataURL(f); });
}
document.getElementById("ai-file").addEventListener("change", async e => {
  const sh = ui.sheet, list = [...(e.target.files || [])];
  e.target.value = "";
  if (!sh || sh.type !== "ai" || !list.length) return;
  { const f = document.getElementById("ai-text"); if (f) sh.text = f.value; }
  sh.files = sh.files || [];
  for (const f of list) {
    if (sh.files.length >= AI_FILE_MAX) { toast(`最多 ${AI_FILE_MAX} 個檔案`); break; }
    try {
      const isPdf = f.type === "application/pdf" || /\.pdf$/i.test(f.name);
      if (isPdf) {
        if (f.size > 12 * 1024 * 1024) { toast("PDF 太大了（上限 12 MB），可以只截課表那一頁的圖"); continue; }
        const url = await fileAsDataURL(f);
        sh.files.push({ name: f.name, mime: "application/pdf", data: url.split(",")[1], thumb: "" });
      } else if (/^image\//.test(f.type) || /\.(jpe?g|png|heic|heif|webp|gif)$/i.test(f.name)) {
        toast("正在處理圖片…");
        const url = await shrinkImage(f, 2000, 1500000);
        sh.files.push({ name: f.name, mime: "image/jpeg", data: url.split(",")[1], thumb: url });
      } else toast("只能放圖片或 PDF");
    } catch (err) { toast(err.message || "檔案處理失敗"); }
  }
  if (ui.sheet === sh) renderSheet();
});
function aiFilesHTML(a) {
  const fs = a.files || [];
  return `<div class="ai-files">
    ${fs.map((f, i) => `<div class="ai-file">${f.thumb ? `<img src="${f.thumb}" alt="">` : `<span class="pdf">PDF</span>`}<span class="nm">${esc(f.name)}</span><button class="x" data-act="ai-file-del" data-i="${i}" aria-label="移除 ${esc(f.name)}">×</button></div>`).join("")}
    <div class="btnrow">${fs.length < AI_FILE_MAX ? `<button class="btn ai-attach" data-act="ai-attach">${I.clip}放入課表、PDF 或圖片</button>` : ""}<button class="btn ai-attach" data-act="gm-check">✉ 從 Email 加入</button></div>
  </div>`;
}

/* ---------- 衝突偵測 ---------- */
/** 跟 item 時間重疊的行程（同一天、有時段、還沒完成） */
function conflictsFor(item, pool) {
  if (!item || item.start == null || item.done) return [];
  const a1 = item.start, a2 = item.start + item.min;
  return (pool || S.tasks).filter(t => t.id !== item.id && t.date === item.date && !t.done && t.start != null
    && t.start < a2 && a1 < t.start + t.min);
}
function conflictText(list) {
  const t = list[0];
  return `和「${t.title} ${range(t)}」時間重疊${list.length > 1 ? `等 ${list.length} 項` : ""}`;
}
/** 找某天最早可以放進 min 分鐘的空檔（避開所有有時段的行程、午休、休息間隔） */
function findSlot(k, min, excludeIds, extraBusy) {
  const s = S.settings, t0 = today();
  if (k < t0) return null;
  const busy = [];
  for (const [a, b] of breaks()) busy.push([a, b, 0]);
  for (const t of [...S.tasks, ...(extraBusy || [])]) {
    if (t.date !== k || t.done || t.start == null || (excludeIds && excludeIds.has(t.id))) continue;
    busy.push([t.start, t.start + t.min, s.gap]);
  }
  let st = s.workStart;
  if (k === t0) st = Math.max(st, Math.ceil(nowMin() / 5) * 5);
  while (st + min <= s.workEnd) {
    const e = st + min;
    const c = busy.find(b => st < b[1] + b[2] && b[0] < e + b[2]);
    if (!c) return st;
    st = Math.ceil((c[1] + c[2]) / 5) * 5;
  }
  return null;
}
/** 從 k 開始往後找（最多 14 天），回傳 {date, start} */
function nearestFree(k, min, excludeIds, extraBusy) {
  let d = maxKey(k, today());
  for (let i = 0; i < 14; i++) {
    if (!(S.settings.skipWeekends && isWeekend(d))) {
      const st = findSlot(d, min, excludeIds, extraBusy);
      if (st != null) return { date: d, start: st };
    }
    d = addDays(d, 1);
  }
  return null;
}

/* ---------- 自訂時間長度：小時＋分鐘，另外有常用快捷 ---------- */
const DUR_CHIPS = [15, 30, 45, 60, 90, 120, 180];
/** attrs：放在兩個輸入框上的 data 屬性（例如 'data-aif="dur" data-id="x"'），hiddenId：同步一個隱藏欄位給舊程式讀 */
function durPickHTML(min, attrs, hiddenId, chips = DUR_CHIPS, maxH = 23) {
  const h = Math.floor(min / 60), m = min % 60;
  return `<span class="durpick">
      <input type="number" inputmode="numeric" min="0" max="${maxH}" value="${h}" ${attrs} data-part="h" aria-label="小時"><span>小時</span>
      <input type="number" inputmode="numeric" min="0" max="59" step="5" value="${m}" ${attrs} data-part="m" aria-label="分鐘"><span>分</span>
      ${hiddenId ? `<input type="hidden" id="${hiddenId}" value="${min}">` : ""}
    </span>
    <span class="chips">${chips.map(c => `<button type="button" class="chip${c === min ? " on" : ""}" data-act="dur-chip" data-min="${c}">${dur(c)}</button>`).join("")}</span>`;
}
/** 讀同一組 durpick 的分鐘數 */
function readDur(container, max = 24 * 60 - 5) {
  const h = +(container.querySelector('[data-part="h"]') || {}).value || 0;
  const m = +(container.querySelector('[data-part="m"]') || {}).value || 0;
  return Math.max(container.dataset.durgroup === "wkdone" ? 0 : 5, Math.min(max, Math.round(h * 60 + m)));
}

/* ---------- Rendering helpers ---------- */
/** 清單上直接顯示完整的備註（不用點進去看） */
const noteHTML = t => {
  const n = (t.notes || "").trim();
  return n ? `<div class="rnote">${esc(n).replace(/https?:\/\/[^\s<]+/g, u => `<a href="${u}" target="_blank" rel="noopener">${/mail\.google\.com/.test(u) ? "打開信件" : u.length > 40 ? u.slice(0, 38) + "…" : u}</a>`)}</div>` : "";
};
function eventRowHTML(t, opts = {}) {
  const c = cat(t.cat);
  const meta = [];
  if (opts.date) meta.push(`<span>${I.cal}${rel(t.date)}</span>`);
  meta.push(`<span class="time">${t.start != null ? range(t) : "未指定時間"}</span>`);
  if (t.cancelled) meta.unshift(`<span class="cxl">已取消</span>`);
  if (t.ot) meta.push(`<span class="otb">加班 +${dur(t.ot)}</span>`);
  if (t.series) meta.push(`<span title="重複">${I.repeat}</span>`);
  { const cf = conflictsFor(t); if (cf.length) meta.push(`<span class="red">⚠ ${esc(conflictText(cf))}</span>`); }
  return `<div class="row event${t.cancelled ? " cancelled" : ""}" data-id="${t.id}">
    <span class="evbar" style="--c:${c ? c.color : "var(--muted)"}" aria-hidden="true"></span>
    <div class="rbody" data-act="edit" data-id="${t.id}"><div class="rtitle">${esc(t.title)}</div><div class="meta">${meta.join("")}</div>${noteHTML(t)}</div>
    ${t.cancelled ? `<button class="mv" data-act="toggle" data-id="${t.id}" aria-label="恢復「${esc(t.title)}」" title="恢復">${I.redo}</button>` : `<button class="xbtn" data-act="cancel" data-id="${t.id}" aria-label="取消「${esc(t.title)}」" title="取消這件事">${I.x}</button>`}
  </div>`;
}
function rowHTML(t, opts = {}) {
  if (isEvent(t)) return eventRowHTML(t, opts);
  const c = cat(t.cat);
  const meta = [];
  if (!opts.date && t.start != null) meta.push(`<span class="time">${t.locked ? I.pin : ""}${range(t)}</span>`);
  if (opts.date) meta.push(`<span>${I.cal}${rel(t.date)}</span>`);
  if (isOverdue(t)) meta.push(`<span class="red">逾期 ${diff(t.date, today())} 天</span>`);
  meta.push(`<span>${I.clock}${dur(t.min)}</span>`);
  if (t.deadline) meta.push(`<span class="${pastDeadline(t) ? "red" : ""}">${I.flag}截止 ${short(t.deadline)}</span>`);
  if (t.series) meta.push(`<span title="重複工作">${I.repeat}</span>`);
  if (!opts.date && !t.done && t.start != null) { const cf = conflictsFor(t); if (cf.length) meta.push(`<span class="red" title="${esc(conflictText(cf))}">⚠ 時間重疊</span>`); }
  if (t.resched) meta.push(`<span class="${t.resched >= 3 ? "orange" : ""}" title="已延後 ${t.resched} 次">${I.redo}${t.resched}</span>`);
  if (t.ot) meta.push(`<span class="otb">加班 +${dur(t.ot)}</span>`);
  if (t.cancelled) meta.unshift(`<span class="cxl">已取消</span>`);
  const pri = !t.done && t.pri >= 2 ? `<span class="pri p${t.pri}">${PRI[t.pri]}</span>` : "";
  const mv = t.done ? "" : opts.review ? `<button class="mv" data-act="miss-later" data-id="${t.id}" aria-label="「${esc(t.title)}」沒做完，排到之後" title="沒做完，往後排">${I.redo}</button>` : `<button class="mv" data-act="move" data-id="${t.id}" aria-label="重新規劃「${esc(t.title)}」">${I.move}</button>`;
  const cx = t.done ? "" : `<button class="xbtn" data-act="cancel" data-id="${t.id}" aria-label="取消「${esc(t.title)}」" title="取消這件事">${I.x}</button>`;
  return `<div class="row${t.done ? " done" : ""}${t.cancelled ? " cancelled" : ""}" data-id="${t.id}"${opts.drag ? ' draggable="true"' : ""}>
    <button class="chk" style="--c:${c ? c.color : "var(--muted)"}" data-act="toggle" data-id="${t.id}" aria-label="${t.cancelled ? "恢復這件事" : t.done ? "標記為未完成" : "標記為完成"}">${t.cancelled ? I.x : I.check}</button>
    <div class="rbody" data-act="edit" data-id="${t.id}"><div class="rtitle">${esc(t.title)}</div><div class="meta">${meta.join("")}</div>${noteHTML(t)}${t.wid ? workLineHTML(t.wid) : ""}</div>
    ${pri}${mv}${cx}
  </div>`;
}
const head = (title, sub, addDate, extra = "") => `<header class="pagehead"><div><h1>${title}</h1>${sub ? `<div class="sub">${sub}</div>` : ""}</div><div class="headbtns">${extra}${addDate !== undefined ? `<button class="iconbtn" data-act="new" data-date="${addDate}" aria-label="新增工作">${I.plus}</button>` : ""}</div></header>`;

/* ---------- Timeline ---------- */
function timelineHTML(k) {
  if (k >= today()) { arrangeTimes(k, "fill"); save(); }
  const s = S.settings, list = S.tasks.filter(t => t.date === k);
  const timed = list.filter(t => t.start != null).sort((a, b) => a.start - b.start);
  const untimed = sortTasks(list.filter(t => t.start == null && !t.done && !isEvent(t)));
  const planned = timed.filter(t => !t.done).reduce((a, t) => a + t.min, 0);
  const avail = availMin();
  const first = Math.max(0, Math.floor(Math.min(s.workStart, ...timed.map(t => t.start)) / 60) - 1);
  const last = Math.min(24, Math.ceil(Math.max(s.workEnd, ...timed.map(t => t.start + t.min)) / 60) + 1);
  const PX = 1.3, y = m => (m - first * 60) * PX;
  const past = k < today();

  let h = `<div class="tlcard"><div class="hrs">${I.clock.replace("<svg", '<svg style="width:16px;height:16px;align-self:center"')}${hm(s.workStart)}–${hm(s.workEnd)}${breaks().length ? `<small>${breaks().map(b => `${b[2]} ${hm(b[0])}–${hm(b[1])}`).join("、")}</small>` : ""}</div>
    <div class="small${planned > avail ? " over" : ""}">已排 ${dur(planned)}・可用 ${dur(avail)}</div>
    ${past ? `<div class="small">過去的日子不會自動排時段。</div>` : `<div class="btnrow"><button class="btn primary" data-act="replan" data-date="${k}">${I.wand}${k === today() ? "從現在重新安排" : "重新安排時段"}</button><button class="btn" data-act="new" data-date="${k}">${I.plus}新增</button></div>
    <div class="small">有 ${I.pin.replace("<svg", '<svg style="width:11px;height:11px;vertical-align:-1px"')} 的是自己指定時間的工作，重新安排時不會移動。</div>`}</div>`;
  if (untimed.length) {
    h += `<div class="untimed"><div class="t">${I.alert}工作時段內排不下 ${untimed.length} 項</div>
      ${untimed.map(t => `<div class="u"><span>${esc(t.title)}<small>${dur(t.min)}・優先 ${PRI[t.pri]}</small></span><button class="btn sm" data-act="move" data-id="${t.id}">改日期</button></div>`).join("")}
      ${past ? "" : `<div class="btnrow"><button class="btn ot" data-act="ot-accept" data-date="${k}">加班做完</button><button class="btn" data-act="spread-untimed" data-date="${k}">${I.cal}全部移到之後有空的日子</button></div>`}</div>`;
  }
  h += `<div class="tl" style="height:${y(last * 60) + 12}px">`;
  h += `<div class="work" style="top:${y(s.workStart)}px;height:${(s.workEnd - s.workStart) * PX}px"></div>`;
  for (const [a, b, n] of breaks()) h += `<div class="brk" style="top:${y(a)}px;height:${(b - a) * PX}px">${n}</div>`;
  for (let hr = first; hr <= last; hr++) h += `<div class="hr" style="top:${y(hr * 60)}px"><span>${pad(hr)}:00</span></div>`;
  // 重疊的行程並排顯示：同一群互相重疊的，平分寬度
  const lay = {};
  { let group = [], groupEnd = -1;
    const flush = () => { const cols = Math.max(1, ...group.map(g => lay[g.id].col + 1)); group.forEach(g => { lay[g.id].cols = cols; }); group = []; };
    for (const t of timed) {
      if (t.start >= groupEnd && group.length) flush();
      const used = new Set(group.filter(g => g.start + g.min > t.start).map(g => lay[g.id].col));
      let col = 0; while (used.has(col)) col++;
      lay[t.id] = { col, cols: 1 };
      group.push(t); groupEnd = Math.max(groupEnd, t.start + t.min);
    }
    if (group.length) flush();
  }
  for (const t of timed) {
    const c = cat(t.cat), hgt = Math.max(t.min * PX - 2, 26);
    const ev = isEvent(t), L = lay[t.id], clash = !t.done && conflictsFor(t).length > 0;
    const pos = L.cols > 1 ? `left:calc(58px + (100% - 64px) * ${L.col} / ${L.cols});right:auto;width:calc((100% - 64px) / ${L.cols} - 4px);` : "";
    h += `<div class="blk${t.done ? " done" : ""}${t.cancelled ? " cancelled" : ""}${t.ot ? " ot" : ""}${ev ? " ev" : ""}${clash ? " clash" : ""}" style="--c:${c ? c.color : "var(--muted)"};top:${y(t.start) + 1}px;height:${hgt}px;${pos}" data-act="edit" data-id="${t.id}"${clash ? ` title="${esc(conflictText(conflictsFor(t)))}"` : ""}>
      ${ev ? "" : `<button class="chk" data-act="toggle" data-id="${t.id}" aria-label="${t.done ? "標記為未完成" : "標記為完成"}" style="${t.done ? "background:var(--ok);border-color:var(--ok);color:#fff" : ""}">${I.check}</button>`}
      <div class="bb"><span class="bt">${t.locked && !ev ? I.pin : ""}${esc(t.title)}</span>${hgt > 40 ? `<span class="br">${ev ? "固定事件・" : ""}${range(t)}</span>` : ""}</div>
      ${!t.done && !ev && t.pri >= 2 ? `<span class="pri p${t.pri}" style="margin-top:0">${PRI[t.pri]}</span>` : ""}</div>`;
  }
  if (k === today()) { const m = nowMin(); if (m >= first * 60 && m <= last * 60) h += `<div class="now" style="top:${y(m)}px"></div>`; }
  h += `</div>`;
  const clashes = timed.filter(t => !t.done && conflictsFor(t).length);
  if (clashes.length) h = h.replace('<div class="tl"', `<div class="untimed"><div class="t">${I.alert}有 ${clashes.length} 項行程時間重疊（紅框）</div><div class="small" style="font-size:12px;color:var(--muted)">點紅框的項目可以修改時間，或按「重新安排時段」讓沒指定時間的工作自動避開。</div></div><div class="tl"`);
  return h;
}

/* ---------- Views ---------- */
function viewToday() {
  const t = today();
  const overdue = sortTasks(S.tasks.filter(isOverdue));
  const todays = onDay(t).filter(x => !isEvent(x));
  const events = eventsOn(t);
  const evMin = eventMinutes(events);
  const done = todays.filter(x => x.done).length;
  const mins = openMinutes(todays);
  const cap = dayCap();
  const pct = todays.length ? done / todays.length : 0;
  const over = mins > cap;
  const extra = overflow(onDay(t));
  const end = addDays(t, 8);
  const seenSeries = new Set();
  const upcoming = S.tasks.filter(x => !x.done && !isEvent(x) && x.date > t && x.date < end).sort((a, b) => a.date < b.date ? -1 : a.date > b.date ? 1 : b.pri - a.pri)
    .filter(x => !x.series || (!seenSeries.has(x.series) && seenSeries.add(x.series)));
  const C = 150.8;

  if (ui.todayMode === "timeline") ui.todayMode = "grid";      // 舊的「時間表」併進「時間」
  const sel = ui.todaySel && (ui.todayMode === "week" || ui.todaySel >= addDays(t, -3)) ? ui.todaySel : t;
  let h = head(sel === t ? "今天" : rel(sel) === md(sel) ? md(sel) : rel(sel), full(sel), sel, `<button class="aibtn" data-act="ai-open">${I.spark}智慧排程</button>`);
  h += todayCtrlHTML(sel);
  { const dd = ddayList().slice(0, 6); if (dd.length) h += `<div class="ddrow">${dd.map(x => `<button class="ddchip" style="--c:${catColor(x)}" data-act="edit" data-id="${x.id}"><b>${ddayTxt(x.date)}</b>${esc(x.title)}</button>`).join("")}</div>`; }
  if (ui.todayMode === "week") return h + weekGridHTML(sel);
  if (sel !== t) return h + dayPanelHTML(sel);
  if (ui.todayMode === "timeline") return h + timelineHTML(t);
  if (ui.todayMode === "grid" && sel === t) return h + gridHTML(t) + wrapBtnHTML();
  const sumHTML = `<div class="sumhead">
    <div class="ring"><svg viewBox="0 0 56 56"><circle class="track" cx="28" cy="28" r="24" fill="none" stroke-width="7"/><circle class="bar" cx="28" cy="28" r="24" fill="none" stroke-width="7" stroke-linecap="round" stroke-dasharray="${C}" stroke-dashoffset="${C * (1 - pct)}"/></svg><span class="num">${Math.round(pct * 100)}%</span></div>
    <div class="info"><div class="big">完成 <span class="num">${done} / ${todays.length}</span> 項</div>
      <div class="meter${over ? " over" : ""}"><i style="width:${Math.min(100, mins / Math.max(cap, 1) * 100)}%"></i></div>
      <div class="small${over ? " over" : ""}">剩餘 ${dur(mins)} / ${dur(cap)}・${hm(S.settings.workStart)}–${hm(S.settings.workEnd)}${over ? "（排太滿了）" : ""}</div></div>
  </div>`;
  if (S.sample && !ui.dismissNote) h += `<div class="note"><span>目前是範例工作，讓你先試用功能。可以到「設定」清除，開始放自己的工作。</span><button data-act="note-x">知道了</button></div>`;

  if (overdue.length) {
    const folded = S.settings.reviewSkip === t;
    h += `<section class="sec"><div class="sechead"><h2>之前沒完成的</h2><span class="aside">${dur(openMinutes(overdue))}</span></div><div class="list">
      <div class="banner"><div class="t">${I.alert}前幾天有 ${overdue.length} 項還沒打勾，做完了嗎？</div>
      ${folded ? `<div class="btnrow"><button class="btn" data-act="review-open">展開</button><button class="btn primary" data-act="smart-overdue">${I.spark}幫我排進之後的時間</button></div>` : `<p class="small" style="margin:0">做完按圓圈打勾；沒做完按 ⟳ 自動排到之後的空檔；不做了按 ✕ 取消。也可以左右滑動。</p>
      <div class="btnrow"><button class="btn primary" data-act="smart-overdue">${I.spark}全部排進之後的時間</button><button class="btn" data-act="overdue-all-done">${I.check}這些都做完了</button><button class="btn" data-act="review-skip">先不管</button></div>`}</div>
      ${folded ? "" : overdue.map(x => rowHTML(x, { date: true, review: true })).join("")}</div></section>`;
  }
  const openT = todays.filter(x => !x.done);
  // 進度、固定事件、加班提示、要做的事 → 放在同一張卡片裡
  h += `<section class="sec main">${sumHTML}
    ${events.length ? `<div class="subhead"><h3>固定事件</h3><span class="aside">${dur(evMin)}</span></div><div class="list">${events.map(x => rowHTML(x)).join("")}</div>` : ""}
    ${otBannerHTML(t)}
    <div class="subhead"><h3>要做的事</h3><span class="aside">${openT.length} 項</span></div><div class="list">
    ${openT.length ? openT.map(x => rowHTML(x)).join("") : todays.length ? `<div class="empty">今天的工作都做完了 🎉</div>` : `<div class="empty">今天沒有排定工作，按右上角 ＋ 新增。</div>`}
    ${extra.length ? `<button class="linkbtn" data-act="spread" data-date="${t}">${I.wand}今天排太滿了，把 ${extra.length} 項分散到之後</button>` : ""}
  </div></section>`;
  if (upcoming.length) h += `<section class="sec"><div class="sechead"><h2>接下來 7 天</h2></div><div class="list">${upcoming.map(x => rowHTML(x, { date: true })).join("")}</div></section>`;
  h += doneFolderHTML(t);
  return h + wrapBtnHTML();
}
const wrapBtnHTML = () => S.tasks.some(x => x.date === today() && !isEvent(x)) && nowMin() >= S.settings.workEnd - 120 ? `<button class="btn block wrapbtn" data-act="wrap-open">${S.settings.wrapDay === today() ? "再看一次今天的回顧" : "🌙 結束今天：回顧、把剩下的移到明天"}</button>` : "";
/* ---- 已完成資料夾：放在最下面，顯示完成數量，點開才看得到做完的事 ---- */
function doneOnDay(k) { return sortTasks(S.tasks.filter(x => x.date === k && x.done && (!isEvent(x) || x.cancelled))); }
function doneFolderHTML(k) {
  const list = doneOnDay(k), open = ui.doneOpen === k;
  const all = S.tasks.filter(x => x.done && !isEvent(x)).length;
  if (!list.length && !all) return "";
  return `<section class="sec donefold${open ? " open" : ""}">
    <button class="folder" data-act="done-fold" data-date="${k}" aria-expanded="${open}"><span class="fic">${I.folder}</span><span class="fn">已完成<small>${k === today() ? "今天" : md(k)}做完的事</small></span><span class="cnt num">${list.length}</span><span class="chev" aria-hidden="true">›</span></button>
    ${open ? `<div class="list">${list.length ? list.map(x => rowHTML(x)).join("") : `<div class="empty">這天還沒有完成的事。</div>`}
      <button class="linkbtn" data-act="done-all">${I.cal}看全部已完成（${all}）</button></div>` : ""}
  </section>`;
}
function sheetDoneAll() {
  const list = S.tasks.filter(x => x.done && !isEvent(x)), key = x => x.doneOn || x.date;
  const by = {};
  for (const x of list) (by[key(x)] = by[key(x)] || []).push(x);
  const days = Object.keys(by).sort().reverse().slice(0, 60);
  const body = days.length ? days.map(k => `<section class="sec"><div class="sechead"><h2>${k === today() ? "今天" : full(k)}</h2><span class="aside">${by[k].length} 項</span></div><div class="list">${sortTasks(by[k]).map(x => rowHTML(x)).join("")}</div></section>`).join("")
    : `<div class="empty">還沒有完成的事。</div>`;
  return sheetWrap(`已完成（${list.length}）`, cancelBtn("關閉"), spacer, body + `<p class="footnote">按綠色的勾可以改回沒做完。設定 › 資料 可以清除 30 天前完成的工作。</p>`);
}

const calSeg = () => `<div class="seg" role="tablist"><button class="${ui.calMode === "week" ? "on" : ""}" data-act="cal-mode" data-mode="week">週</button><button class="${ui.calMode === "month" ? "on" : ""}" data-act="cal-mode" data-mode="month">月</button><button class="${ui.calMode === "stats" ? "on" : ""}" data-act="cal-mode" data-mode="stats">統計</button></div>`;
function viewCalendar() {
  if (ui.calMode === "stats") return viewStats(true);
  const t = today(), cap = dayCap();
  const byDay = {};
  for (const x of S.tasks) (byDay[x.date] = byDay[x.date] || []).push(x);
  if (ui.calMode === "month") {
    return head("行事曆", "", maxKey(ui.sel, t)) + `<div class="ctrl cal pctrl">${calSeg()}<button class="btn sm" data-act="pcal-today">今天</button></div>` + pcalHTML();
  }
  let title;
  let grid = "";
  if (false) {
    const a = parse(ui.anchor);
    title = `${a.getFullYear()}年${a.getMonth() + 1}月`;
    const first = new Date(a.getFullYear(), a.getMonth(), 1);
    const days = new Date(a.getFullYear(), a.getMonth() + 1, 0).getDate();
    const cells = [];
    for (let i = 0; i < first.getDay(); i++) cells.push(null);
    for (let i = 1; i <= days; i++) cells.push(key(new Date(a.getFullYear(), a.getMonth(), i)));
    while (cells.length % 7) cells.push(null);
    grid = `<div class="calcard"><div class="wdays">${WD.map(w => `<div>${w}</div>`).join("")}</div><div class="grid">${cells.map(k => {
      if (!k) return "<div></div>";
      const list = (byDay[k] || []).filter(x => !isEvent(x)), open = list.filter(x => !x.done);
      const warn = openMinutes(list) > cap || open.some(isOverdue);
      const dots = list.length && !open.length ? I.check : open.slice(0, 3).map(x => `<i style="background:${(cat(x.cat) || {}).color || "var(--muted)"}"></i>`).join("");
      return `<button class="cell${k === t ? " today" : ""}${k === ui.sel ? " sel" : ""}${warn ? " warn" : ""}" data-act="cal-day" data-date="${k}" data-drop="${k}" aria-label="${md(k)}，${open.length} 項未完成"><span class="d num">${parse(k).getDate()}</span><span class="dots">${dots}</span></button>`;
    }).join("")}</div></div>`;
  } else {
    const ws = weekStart(ui.anchor);
    title = `${short(ws)} – ${short(addDays(ws, 6))}`;
    grid = `<div class="week">${[0, 1, 2, 3, 4, 5, 6].map(i => {
      const k = addDays(ws, i), list = (byDay[k] || []).filter(x => !isEvent(x)), open = list.filter(x => !x.done), m = openMinutes(list);
      const h = Math.min(m / Math.max(cap, 1), 1.2) / 1.2 * 100;
      return `<button class="wcol${k === t ? " today" : ""}${k === ui.sel ? " sel" : ""}" data-act="cal-day" data-date="${k}" data-drop="${k}" aria-label="${md(k)}，${open.length} 項未完成"><span class="w">${WD[i]}</span><span class="d num">${parse(k).getDate()}</span><span class="wring${m > cap ? " over" : ""}" title="${dur(m)}"><svg viewBox="0 0 24 24" aria-hidden="true"><circle class="tr" cx="12" cy="12" r="9"/><circle class="br" cx="12" cy="12" r="9" stroke-dasharray="56.5" stroke-dashoffset="${(56.5 * (1 - Math.min(m / Math.max(cap, 1), 1))).toFixed(1)}"/></svg><span class="num">${open.length || ""}</span></span></button>`;
    }).join("")}</div>`;
  }
  const dayAll = onDay(ui.sel);
  const list = dayAll.filter(x => !isEvent(x)), dayEvents = eventsOn(ui.sel);
  const mins = openMinutes(list);
  const extra = overflow(dayAll);
  let h = head("行事曆", "", maxKey(ui.sel, t));
  h += `<div class="ctrl cal">${calSeg()}
    <div class="calnav"><button class="navbtn" data-act="cal-prev" aria-label="上一個">${I.left}</button><strong>${title}${ui.sel !== t ? `<button class="todaylink" data-act="cal-today">回到今天</button>` : ""}</strong><button class="navbtn" data-act="cal-next" aria-label="下一個">${I.right}</button></div>
    ${grid}</div>
    <section class="sec"><div class="sechead"><h2>${full(ui.sel)}</h2><span class="aside${mins > dayCap() ? " over" : ""}">${hm(S.settings.workStart)}–${hm(S.settings.workEnd)}・已排 ${dur(mins)}</span></div>
    ${ui.calDayMode === "list" ? otBannerHTML(ui.sel) : ""}
    <div class="seg"><button class="${ui.calDayMode === "list" ? "on" : ""}" data-act="calday-mode" data-mode="list">清單</button><button class="${ui.calDayMode === "timeline" ? "on" : ""}" data-act="calday-mode" data-mode="timeline">時間表</button></div>
    ${ui.calDayMode === "timeline" ? timelineHTML(ui.sel) : `${dayEvents.length ? `<div class="sechead"><h2>固定事件</h2></div><div class="list">${dayEvents.map(x => rowHTML(x)).join("")}</div><div class="sechead"><h2>要做的事</h2></div>` : ""}<div class="list">${list.filter(x => !x.done).length ? list.filter(x => !x.done).map(x => rowHTML(x, { drag: true })).join("") : `<div class="empty">${list.length ? "這天的工作都做完了 🎉" : "這天沒有工作。"}</div>`}
    ${extra.length ? `<button class="linkbtn" data-act="spread" data-date="${ui.sel}">${I.wand}這天排太滿，把 ${extra.length} 項分散到其他天</button>` : ""}</div>
    <p class="hint">點工作右邊的日曆箭頭可以改日期；用電腦的話，也可以直接把工作拖到上面的日期。</p>`}</section>`;
  if (ui.calDayMode !== "timeline") h += doneFolderHTML(ui.sel);
  return h;
}

/* ===================== Plantri 風格：行事曆、10 分鐘方格、專注、結束今天 ===================== */
const PC = { before: 12, after: 12, zoom: [48, 72, 110, 160] };
const catColor = t => (cat(t.cat) || {}).color || "#8E8E93";
const multiEnd = t => t.endDate && t.endDate > t.date ? t.endDate : null;
/** D-day：還有幾天（今天 = D-Day，過了 = D+n） */
const ddayTxt = k => { const n = diff(today(), k); return n > 0 ? `D-${n}` : n === 0 ? "D-Day" : `D+${-n}`; };
const ddayList = () => S.tasks.filter(t => t.dday && !t.cancelled && (multiEnd(t) || t.date) >= addDays(today(), -1) && !(t.done && !isEvent(t))).sort((a, b) => a.date < b.date ? -1 : 1);

/* ---------- 月曆：一整年上下連續捲動，每天最多 3 行，跨天的事連成一條 ---------- */
function pcalHTML() {
  const t0 = today(), a = parse(ui.anchor || t0);
  const byDay = {}, bands = [];
  for (const x of S.tasks) {
    if (x.cancelled) continue;
    if (multiEnd(x)) { bands.push(x); continue; }
    (byDay[x.date] = byDay[x.date] || []).push(x);
  }
  for (const k in byDay) byDay[k].sort((p, q) => (isEvent(q) - isEvent(p)) || ((p.start ?? 9999) - (q.start ?? 9999)) || (q.pri - p.pri));
  let h = `<div class="pcal" id="pcal"><div class="pwk">${WD.map((w, i) => `<span class="${i === 0 ? "sun" : i === 6 ? "sat" : ""}">${w}</span>`).join("")}</div>`;
  for (let mi = -PC.before; mi <= PC.after; mi++) {
    const y = a.getFullYear(), m = a.getMonth() + mi, first = new Date(y, m, 1), mk = key(first);
    const dim = new Date(first.getFullYear(), first.getMonth() + 1, 0).getDate();
    h += `<section class="pmonth${mk.slice(0, 7) === t0.slice(0, 7) ? " cur" : ""}" data-month="${mk.slice(0, 7)}"><h3 class="pmt">${first.getFullYear()}年${first.getMonth() + 1}月</h3>`;
    const cells = [];
    for (let i = 0; i < first.getDay(); i++) cells.push(null);
    for (let d = 1; d <= dim; d++) cells.push(key(new Date(first.getFullYear(), first.getMonth(), d)));
    while (cells.length % 7) cells.push(null);
    for (let w = 0; w < cells.length; w += 7) {
      const wk = cells.slice(w, w + 7);
      h += pweekHTML(wk, byDay, bands);
      if (wk.includes(ui.sel) && ui.pbarOpen !== false) h += pbarHTML(ui.sel);
    }
    h += `</section>`;
  }
  return h + `</div>`;
}
function pweekHTML(wk, byDay, bands) {
  const t0 = today(), real = wk.filter(Boolean), ws = real[0], we = real[real.length - 1];
  // 跨天的事：照開始日排成幾條「車道」
  const mine = bands.filter(b => b.date <= we && multiEnd(b) >= ws).sort((p, q) => p.date < q.date ? -1 : 1);
  const lanes = []; const place = [];
  for (const b of mine) {
    const s = Math.max(0, wk.indexOf(b.date < ws ? ws : b.date)), e = wk.indexOf(multiEnd(b) > we ? we : multiEnd(b));
    let ln = 0; while (lanes[ln] && lanes[ln].some(([p, q]) => !(e < p || s > q))) ln++;
    (lanes[ln] = lanes[ln] || []).push([s, e]); place.push({ b, s, e, ln });
  }
  const used = i => lanes.filter(L => L.some(([p, q]) => i >= p && i <= q)).length;
  let h = `<div class="pw">`;
  wk.forEach((k, i) => {
    if (!k) { h += `<div class="pd empty" style="grid-column:${i + 1}"></div>`; return; }
    const d = parse(k), list = byDay[k] || [];
    const room = Math.max(0, 3 - used(i)), more = list.length - room;
    const dd = list.find(x => x.dday) || mine.find(b => b.dday && b.date === k);
    h += `<button class="pd${k === t0 ? " today" : ""}${k === ui.sel ? " sel" : ""}${i === 0 ? " sun" : i === 6 ? " sat" : ""}${k < t0 ? " past" : ""}" style="grid-column:${i + 1}" data-act="pcal-day" data-date="${k}" data-drop="${k}" aria-label="${full(k)}，${list.length} 件">
      <span class="pdn num">${d.getDate()}</span>${dd ? `<span class="pdd">${ddayTxt(k)}</span>` : ""}
      <span class="plines" style="--off:${used(i)}">${list.slice(0, more > 0 ? room - 1 : room).map(x => plineHTML(x)).join("")}${more > 0 ? `<span class="pmore">+${more + 1}</span>` : ""}</span></button>`;
  });
  for (const { b, s, e, ln } of place) {
    const cont = b.date < ws, goes = multiEnd(b) > we;
    h += `<span class="pband${cont ? " cont" : ""}${goes ? " goes" : ""}" style="grid-column:${s + 1}/${e + 2};--ln:${ln};--c:${catColor(b)}" data-id="${b.id}" data-pdrag="${b.id}">${b.dday ? `<b>${ddayTxt(b.date)}</b>` : ""}${esc(b.title)}</span>`;
  }
  return h + `</div>`;
}
function plineHTML(x) {
  const ev = isEvent(x), c = catColor(x);
  return `<span class="pl${ev ? " ev" : ""}${x.done ? " done" : ""}" style="--c:${c}" data-id="${x.id}" data-pdrag="${x.id}">${x.dday ? `<b>${ddayTxt(x.date)}</b>` : ""}${esc(x.title)}</span>`;
}
/* ---------- 點日期：展開這天的橫向時間條 ---------- */
function pbarHTML(k) {
  const z = PC.zoom[ui.pzoom ?? 1], list = S.tasks.filter(x => x.date === k && !x.cancelled);
  const timed = list.filter(x => x.start != null).sort((a, b) => a.start - b.start), todo = list.filter(x => x.start == null && !isEvent(x));
  const bands = S.tasks.filter(x => multiEnd(x) && x.date <= k && multiEnd(x) >= k && !x.cancelled);
  const ends = []; const lane = x => { let l = 0; while (ends[l] != null && ends[l] > x.start) l++; ends[l] = x.start + x.min; return l; };
  const blocks = timed.map(x => ({ x, l: lane(x) })), L = Math.max(1, ends.length);
  const now = k === today() ? nowMin() : null;
  return `<div class="pbar" data-date="${k}" style="--z:${z};--lanes:${L}">
    <div class="pbh"><strong>${md(k)}${k === today() ? "・今天" : ""}</strong><span class="pbsp"></span>
      <button class="pbz" data-act="pzoom" data-d="-1" aria-label="縮小">−</button><button class="pbz" data-act="pzoom" data-d="1" aria-label="放大">＋</button>
      <button class="btn sm" data-act="new" data-date="${k}">${I.plus}新增</button><button class="btn sm" data-act="pcal-open" data-date="${k}">打開這天</button></div>
    ${bands.length ? `<div class="pbbands">${bands.map(b => `<button class="pchip band" style="--c:${catColor(b)}" data-act="edit" data-id="${b.id}">${esc(b.title)}<small>${short(b.date)}–${short(multiEnd(b))}</small></button>`).join("")}</div>` : ""}
    ${todo.length ? `<div class="pbtodo" aria-label="還沒排時間的事（拖到下面的時間條就能排時間）">${todo.map(x => `<button class="pchip${x.done ? " done" : ""}" style="--c:${catColor(x)}" data-act="edit" data-id="${x.id}" data-tdrag="${x.id}">${x.dday ? `<b>${ddayTxt(x.date)}</b>` : ""}${esc(x.title)}<small>${dur(x.min)}</small></button>`).join("")}</div>` : ""}
    <div class="pbs" data-date="${k}"><div class="pbt" style="width:${24 * z}px">
      ${Array.from({ length: 25 }, (_, h) => `<i class="pbh-l" style="left:${h * z}px"><em>${h < 24 ? h : ""}</em></i>`).join("")}
      ${now != null ? `<i class="pbnow" style="left:${now / 60 * z}px"></i>` : ""}
      ${blocks.map(({ x, l }) => `<div class="pblk2${isEvent(x) ? " ev" : ""}${x.done ? " done" : ""}" style="--c:${catColor(x)};left:${x.start / 60 * z}px;width:${Math.max(x.min / 60 * z, 14)}px;top:calc(24px + ${l} * 40px)" data-id="${x.id}" data-bdrag="${x.id}" role="button" aria-label="${esc(x.title)} ${range(x)}"><b>${esc(x.title)}</b><small>${hm(x.start)}–${hm(x.start + x.min)}</small><span class="pbr" data-bresize="${x.id}"></span></div>`).join("")}
    </div></div>
    <p class="pbhint">點空白的地方新增・按住方塊拖曳改時間、拉右邊改長度・上面的待辦拖到時間條就排好時間</p>
  </div>`;
}

/* ---------- 行程頁（Plantri）：方格／分割／計畫＋實際／週 ---------- */
const GVIEWS = [["grid", "方格"], ["split", "分割"], ["actual", "實際"], ["week", "週"]];
const MARKS = { circle: ["○", "●"], square: ["□", "■"], heart: ["♡", "♥"], star: ["☆", "★"], diamond: ["◇", "◆"], check: ["☐", "☑"] };
const markOf = done => (MARKS[S.settings.gridMark] || MARKS.circle)[done ? 1 : 0];
const RATE = ["😣", "🙁", "😐", "🙂", "😄"];
function gridRange(k, list) {
  const s = S.settings, timed = list.filter(x => x.start != null);
  let h0 = Math.floor(s.workStart / 60) - 1, h1 = Math.ceil(s.workEnd / 60) + 2;
  if (!ui.gridFold) { for (const x of timed) { h0 = Math.min(h0, Math.floor(x.start / 60)); h1 = Math.max(h1, Math.ceil((x.start + x.min) / 60)); } }
  else { h0 = Math.floor(s.workStart / 60); h1 = Math.ceil(s.workEnd / 60); }
  return [Math.max(0, h0), Math.min(24, h1)];
}
/** 今天頁最上面的操作卡：日期 ＋ 三種看法 ＋ ⋯（其他選項） */
const TMODES = [["list", "清單"], ["grid", "時間"], ["week", "週"]];
function todayCtrlHTML(sel) {
  const mode = ui.todayMode || "list", ws = weekStart(sel), we = addDays(ws, 6);
  const top = mode === "week"
    ? `<div class="wknav"><button class="navbtn" data-act="g-week" data-d="-7" aria-label="上一週">${I.left}</button><button class="wkt" data-act="g-pick">${short(ws)} – ${short(we)}${ws <= today() && today() <= we ? "・這週" : ""}</button><button class="navbtn" data-act="g-week" data-d="7" aria-label="下一週">${I.right}</button></div>`
    : stripHTML(sel);
  const sub = mode === "grid" ? (ui.gridLayout === "split" ? "分割" : ui.gridLayout === "actual" ? "計畫＋實際" : "") : "";
  const opt = (act, label, on, extra = "") => `<button role="menuitemcheckbox" aria-checked="${!!on}" data-act="${act}"${extra}><span>${label}</span>${on ? I.check : ""}</button>`;
  const menu = !ui.gMenu ? "" : `<div class="gmenu" role="menu">
    ${mode === "grid" ? `<div class="gmh">時間怎麼排</div>${opt("g-layout", "一般", !ui.gridLayout, ' data-v=""')}${opt("g-layout", "左邊清單、右邊時間", ui.gridLayout === "split", ' data-v="split"')}${opt("g-layout", "計畫＋實際做完的時間", ui.gridLayout === "actual", ' data-v="actual"')}<hr>` : ""}
    ${mode !== "list" ? `${opt("g-dense", "緊湊", ui.gridDense)}${opt("g-fold", "只看工作時間", ui.gridFold)}<hr>` : ""}
    <button data-act="g-pick"><span>跳到某一天…</span></button></div>`;
  return `<div class="ctrl tctrl">${top}<input type="date" id="g-date" value="${sel}" tabindex="-1" aria-hidden="true">
    <div class="tmrow"><div class="seg">${TMODES.map(([v, n]) => `<button class="${mode === v ? "on" : ""}" data-act="today-mode" data-mode="${v}">${n}${v === "grid" && sub ? `<small>${sub}</small>` : ""}</button>`).join("")}</div>
      <button class="tmore" data-act="g-menu" aria-label="更多選項" aria-expanded="${!!ui.gMenu}">⋯</button></div>${menu}</div>`;
}
function gridHTML(k) {
  const view = ui.gridLayout || "grid";
  const list = S.tasks.filter(x => x.date === k && !x.cancelled);
  const todo = list.filter(x => x.start == null && !x.done && !isEvent(x)).sort((a, b) => (a.order ?? 1e9) - (b.order ?? 1e9) || b.pri - a.pri);
  const anyEv = list.filter(x => x.start == null && isEvent(x));
  const head = "";
  const tray = `<div class="tray gswipe" data-tray="${k}" aria-label="隨時可以做（拖到方格裡排時間；方格裡的拖回來就變成隨時）">
      ${anyEv.map(x => `<button class="pchip ev" style="--c:${catColor(x)}" data-act="edit" data-id="${x.id}">${esc(x.title)}</button>`).join("")}
      ${todo.map(x => `<span class="pchip" style="--c:${catColor(x)}" data-tdrag="${x.id}"><button class="gmark" data-act="g-check" data-id="${x.id}" aria-label="完成">${markOf(false)}</button><button class="pct" data-act="edit" data-id="${x.id}">${esc(x.title)}<small>${dur(x.min)}</small></button></span>`).join("")}
      <span class="gquick"><input type="text" id="g-quick" data-date="${k}" placeholder="＋ 打字新增待辦，按 Enter" enterkeyhint="done"></span></div>`;
  const grid = gridRowsHTML(k, list, view);
  if (view === "split") {
    const all = list.filter(x => !isEvent(x) || x.start != null).sort((a, b) => (a.start ?? 1e4) - (b.start ?? 1e4));
    return `<section class="sec main gridsec">${head}${tray}<div class="gsplit"><div class="gslist">${all.map(x => `<div class="gsl${x.done ? " done" : ""}" style="--c:${catColor(x)}">${isEvent(x) ? `<i class="gsev"></i>` : `<button class="gmark" data-act="g-check" data-id="${x.id}">${markOf(x.done)}</button>`}<button class="pct" data-act="edit" data-id="${x.id}">${esc(x.title)}<small>${x.start != null ? hm(x.start) : "隨時"}・${dur(x.min)}</small></button></div>`).join("") || `<small class="traye">這天還沒有事</small>`}</div>${grid}</div>${gridHint(view)}</section>`;
  }
  return `<section class="sec main gridsec">${head}${tray}${view === "actual" ? `<div class="ghead"><span></span><b>計畫</b><b>實際</b></div>` : ""}${grid}${gridHint(view)}</section>`;
}
const gridHint = v => `<p class="pbhint">${v === "actual" ? "點做完的方塊打分數・" : ""}橫著滑新增・按住方塊拖曳改時間</p>`;
function gridRowsHTML(k, list, view) {
  const timed = list.filter(x => x.start != null), act = view === "actual";
  const [h0, h1] = gridRange(k, list);
  const actual = list.filter(x => x.done && x.doneAt != null && x.doneOn === k).map(x => ({ x, a: Math.max(0, x.doneAt - (x.actMin || x.min)), b: x.doneAt }));
  const segs = (items, hr, A) => items.filter(o => A ? (o.a < (hr + 1) * 60 && o.b > hr * 60) : (o.start < (hr + 1) * 60 && o.start + o.min > hr * 60)).map(o => {
    const x = A ? o.x : o, a0 = A ? o.a : o.start, b0 = A ? o.b : o.start + o.min;
    const a = Math.max(a0, hr * 60) - hr * 60, b = Math.min(b0, (hr + 1) * 60) - hr * 60, first = a0 >= hr * 60, ev = isEvent(x);
    const tap = A ? "" : act && x.done && !ev ? ` data-act="g-rate" data-id="${x.id}"` : ` data-act="edit" data-id="${x.id}"`;
    return `<span class="gs${ev ? " ev" : ""}${x.done ? " done" : ""}${first ? " first" : ""}" style="--c:${catColor(x)};left:${a / 60 * 100}%;width:${(b - a) / 60 * 100}%"${A ? "" : ` data-gdrag="${x.id}"`}${tap}>${first && !A && !ev ? `<button class="gmark" data-act="g-check" data-id="${x.id}" aria-label="${x.done ? "改回沒做完" : "完成"}">${markOf(x.done)}</button>` : ""}${first ? esc(x.title) : ""}${first && x.rate ? `<em class="grate">${RATE[x.rate - 1]}</em>` : ""}</span>`;
  }).join("");
  const nowM = k === today() ? nowMin() : null;
  let rows = "";
  for (let hr = h0; hr < h1; hr++) {
    rows += `<div class="gr${nowM != null && Math.floor(nowM / 60) === hr ? " nowrow" : ""}"><span class="gh num">${pad(hr)}</span>
      <div class="gc" data-hr="${hr}" data-date="${k}">${segs(timed, hr, false)}${nowM != null && Math.floor(nowM / 60) === hr ? `<i class="gnow" style="left:${nowM % 60 / 60 * 100}%"></i>` : ""}</div>
      ${act ? `<div class="gc ga">${segs(actual, hr, true)}</div>` : ""}</div>`;
  }
  return `<div class="grid10${act ? " two" : ""}${ui.gridDense ? " dense" : ""}">${rows}</div>`;
}
/* ---------- 週檢視：7 天的時間表 + 下方的待辦盤 ---------- */
function weekGridHTML(k) {
  const ws = weekStart(k), days = Array.from({ length: 7 }, (_, i) => addDays(ws, i)), t0 = today();
  const all = S.tasks.filter(x => x.date >= ws && x.date <= days[6] && !x.cancelled);
  const [h0, h1] = gridRange(k, all), H = ui.gridDense ? 26 : 38;
  const cols = days.map(d => {
    const items = all.filter(x => x.date === d && x.start != null).sort((a, b) => a.start - b.start);
    const ends = []; const lane = x => { let l = 0; while (ends[l] != null && ends[l] > x.start) l++; ends[l] = x.start + x.min; return l; };
    const placed = items.map(x => ({ x, l: lane(x) })), L = Math.max(1, ends.length);
    return `<div class="wgc" data-date="${d}" data-h0="${h0}" data-hh="${H}">${placed.map(({ x, l }) => `<span class="wgb${isEvent(x) ? " ev" : ""}${x.done ? " done" : ""}" style="--c:${catColor(x)};top:${(x.start - h0 * 60) / 60 * H}px;height:${Math.max(x.min / 60 * H - 2, 12)}px;left:${l / L * 100}%;width:${100 / L}%" data-act="edit" data-id="${x.id}" data-gdrag="${x.id}">${esc(x.title)}</span>`).join("")}
      ${d === t0 && nowMin() >= h0 * 60 && nowMin() <= h1 * 60 ? `<i class="wnow" style="top:${(nowMin() - h0 * 60) / 60 * H}px"></i>` : ""}</div>`;
  }).join("");
  const tray = all.filter(x => x.start == null && !x.done && !isEvent(x));
  const sel = ui.wtSel || (ui.wtSel = new Set());
  const size = ui.wtSize || "m";
  return `<section class="sec main wgsec">
    <div class="wgdays"><span></span>${days.map(d => `<button class="${d === t0 ? "today" : ""}${d === k ? " sel" : ""}" data-act="strip-day" data-date="${d}" data-drop="${d}">${WD[parse(d).getDay()]}<b class="num">${parse(d).getDate()}</b></button>`).join("")}</div>
    <div class="wgbody" style="height:${(h1 - h0) * H}px"><div class="wghours">${Array.from({ length: h1 - h0 }, (_, i) => `<span style="top:${i * H}px">${pad(h0 + i)}</span>`).join("")}</div>
      <div class="wgcols" style="background-size:100% ${H}px">${cols}</div></div></section>
    <section class="sec wtray wt-${size}"><div class="sechead"><h2>這週的待辦盤</h2><span class="aside"><span class="seg sm">${[["s", "小"], ["m", "中"], ["l", "大"]].map(([v, n]) => `<button class="${size === v ? "on" : ""}" data-act="wt-size" data-v="${v}">${n}</button>`).join("")}</span></span></div>
      <div class="list">${tray.length ? tray.map(x => `<div class="row wtrow" data-id="${x.id}"><button class="chk${sel.has(x.id) ? " on" : ""}" data-act="wt-pick" data-id="${x.id}" aria-label="選取">${I.check}</button><span class="pchip wtchip" style="--c:${catColor(x)}" data-tdrag="${x.id}"><button class="pct" data-act="edit" data-id="${x.id}">${esc(x.title)}<small>${short(x.date)}・${dur(x.min)}</small></button></span></div>`).join("") : `<div class="empty">這週沒有還沒排時間的待辦。</div>`}</div>
      ${sel.size ? `<div class="btnrow wtact"><span>選了 ${sel.size} 件</span><button class="btn sm" data-act="wt-move">移到下週</button><button class="btn sm" data-act="wt-del" style="color:var(--danger)">刪除</button></div>` : ""}
      <p class="pbhint">待辦拖到上面的時間表就排好時間・在空白處點一下新增</p></section>`;
}
/* 左右滑上面的區塊 → 換天 */
const GSW = {};
document.addEventListener("pointerdown", e => { const z = e.target.closest && e.target.closest(".gswipe"); if (!z || e.target.closest("[data-tdrag],input,.gmark")) return; Object.assign(GSW, { x: e.clientX, y: e.clientY, id: e.pointerId, on: true }); }, { passive: true });
document.addEventListener("pointerup", e => {
  if (!GSW.on || GSW.id !== e.pointerId) return; GSW.on = false;
  const dx = e.clientX - GSW.x, dy = e.clientY - GSW.y;
  if (Math.abs(dx) > 60 && Math.abs(dy) < 40 && ui.tab === "today") {
    const k = addDays(ui.todaySel || today(), dx < 0 ? 1 : -1); ui.todaySel = k; ui.stripJump = true;
    PD.swallow = Date.now(); renderMain(); animateView(dx < 0 ? "enter-right" : "enter-left");
  }
});
/* 拖曳時碰到畫面上下緣 → 自動捲動 */
let autoScrollY = 0;
function autoScrollLoop() { if (!PD.on || !autoScrollY) return; window.scrollBy(0, autoScrollY); requestAnimationFrame(autoScrollLoop); }
document.addEventListener("pointermove", e => {
  if (!PD.on) { autoScrollY = 0; return; }
  const edge = 70, v = e.clientY < edge + 40 ? -Math.ceil((edge + 40 - e.clientY) / 6) : e.clientY > innerHeight - edge - 70 ? Math.ceil((e.clientY - (innerHeight - edge - 70)) / 6) : 0;
  const was = autoScrollY; autoScrollY = v; if (v && !was) requestAnimationFrame(autoScrollLoop);
}, { passive: true });
function sheetRate(o) {
  const t = task(o.id); if (!t) return "";
  return sheetWrap("做得怎麼樣？", cancelBtn(), spacer, `<p class="footnote" style="margin:0">「${esc(t.title)}」${t.doneAt != null ? `・${hm(Math.max(0, t.doneAt - (t.actMin || t.min)))}–${hm(t.doneAt)} 做完` : ""}</p>
    <div class="rates">${RATE.map((r, i) => `<button class="${t.rate === i + 1 ? "on" : ""}" data-act="g-rate-set" data-id="${t.id}" data-v="${i + 1}" aria-label="${i + 1} 分">${r}</button>`).join("")}</div>
    <button class="opt" data-act="edit" data-id="${t.id}"><span class="main">打開這件事</span></button>`);
}

/* ---------- 拖曳：月曆換日（移動／複製）、時間條改時間、方格滑動新增 ---------- */
const PD = { on: false };
function pdStart(e) {
  if (e.button > 0) return;
  const el = e.target;
  const line = el.closest("[data-pdrag]"), blk = el.closest("[data-bdrag]"), rs = el.closest("[data-bresize]"), chip = el.closest("[data-tdrag]");
  const gseg = el.closest("[data-gdrag]"), gcell = !gseg && el.closest(".gc[data-hr]"), pbs = !blk && !chip && (el.closest(".pbt") || (!gseg && el.closest(".wgc")));
  const pday = !line && el.closest(".pd[data-date]");
  if (!(line || blk || chip || gseg || gcell || pbs || pday)) return;
  Object.assign(PD, { on: false, x0: e.clientX, y0: e.clientY, id: (rs && rs.dataset.bresize) || (blk && blk.dataset.bdrag) || (line && line.dataset.pdrag) || (chip && chip.dataset.tdrag) || (gseg && gseg.dataset.gdrag),
    kind: rs ? "resize" : blk ? "bmove" : chip ? "chip" : gseg ? "gmove" : gcell ? "gnew" : pbs ? "bnew" : line ? "day" : "range", el: rs || blk || chip || gseg || gcell || pbs || line || pday, src: pday, pid: e.pointerId, moved: false });
  clearTimeout(PD.t);
  // 方格滑動、時間條拉長、待辦拖曳：馬上開始；其他要按住一下（才不會擋到捲動）
  if (["gnew", "resize", "chip"].includes(PD.kind)) PD.armed = true;
  else { PD.armed = false; PD.t = setTimeout(() => { PD.armed = true; pdActivate(); }, 330); }
}
function pdActivate() {
  if (PD.on) return;
  PD.on = true; document.documentElement.classList.add("pdragging");
  try { navigator.vibrate && navigator.vibrate(8); } catch (e) {}
  if (["day", "bmove", "gmove", "chip"].includes(PD.kind)) {
    const t = task(PD.id); if (!t) return;
    const g = PD.ghost = document.createElement("div"); g.className = "pghost"; g.textContent = t.title; g.style.setProperty("--c", catColor(t));
    document.body.appendChild(g); pdGhost(PD.x0, PD.y0);
    PD.el.classList.add("pdsrc");
  }
  if (PD.kind === "range") { PD.a = PD.src.dataset.date; PD.b = PD.a; pdMark(); }
}
function pdGhost(x, y) { if (PD.ghost) PD.ghost.style.transform = `translate3d(${x - 20}px,${y - 34}px,0)`; }
function pdMark() {
  document.querySelectorAll(".pd.rsel").forEach(c => c.classList.remove("rsel"));
  if (!PD.a) return;
  const [a, b] = PD.a <= PD.b ? [PD.a, PD.b] : [PD.b, PD.a];
  document.querySelectorAll(".pd[data-date]").forEach(c => { if (c.dataset.date >= a && c.dataset.date <= b) c.classList.add("rsel"); });
}
/** 方格／時間條上這個位置是幾點幾分（10 分鐘一格） */
function pdTimeAt(x, y) {
  const el = document.elementFromPoint(x, y); if (!el) return null;
  const gc = el.closest(".gc[data-hr]");
  if (gc) { const r = gc.getBoundingClientRect(); return { date: gc.dataset.date, m: +gc.dataset.hr * 60 + Math.max(0, Math.min(5, Math.floor((x - r.left) / r.width * 6))) * 10 }; }
  const wc = el.closest(".wgc");
  if (wc) { const r = wc.getBoundingClientRect(), H = +wc.dataset.hh; return { date: wc.dataset.date, m: Math.max(0, Math.min(1430, +wc.dataset.h0 * 60 + Math.floor((y - r.top) / H * 6) * 10)) }; }
  const bt = el.closest(".pbt"); if (bt) { const r = bt.getBoundingClientRect(), z = PC.zoom[ui.pzoom ?? 1]; return { date: bt.closest(".pbar").dataset.date, m: Math.max(0, Math.min(1430, Math.round((x - r.left) / z * 6) * 10)) }; }
  return null;
}
function pdMove(e) {
  if (PD.pid !== e.pointerId || !PD.kind) return;
  const dx = e.clientX - PD.x0, dy = e.clientY - PD.y0;
  if (!PD.armed) { if (Math.hypot(dx, dy) > 8) { clearTimeout(PD.t); PD.kind = null; } return; }
  if (PD.kind === "gnew" && !PD.on) {
    // 上下捲動優先：先往上下動就放棄新增；要明顯橫著滑才開始
    if (Math.abs(dy) > 8 && Math.abs(dy) >= Math.abs(dx) * 0.8) { PD.kind = null; return; }
    if (Math.abs(dx) < 16 || Math.abs(dx) < Math.abs(dy) * 1.8) return;
  }
  if (!PD.on) { if (Math.hypot(dx, dy) < 6) return; pdActivate(); }
  PD.moved = true; e.preventDefault();
  pdGhost(e.clientX, e.clientY);
  if (PD.kind === "range") { const c = document.elementFromPoint(e.clientX, e.clientY); const d = c && c.closest(".pd[data-date]"); if (d) { PD.b = d.dataset.date; pdMark(); } return; }
  if (PD.kind === "gnew") {
    const p = pdTimeAt(e.clientX, e.clientY); if (!p) return;
    if (PD.a == null) { const q = pdTimeAt(PD.x0, PD.y0); PD.a = q ? q.m : p.m; PD.date = q ? q.date : p.date; }
    PD.b = p.m; pdGridSel(); return;
  }
  if (PD.kind === "resize") {
    const t = task(PD.id), bl = PD.el.closest(".pblk2"); if (!t || !bl) return;
    const z = PC.zoom[ui.pzoom ?? 1];
    PD.newMin = Math.max(10, Math.round((t.min + dx / z * 60) / 10) * 10);
    bl.style.width = PD.newMin / 60 * z + "px"; bl.querySelector("small").textContent = `${hm(t.start)}–${hm(t.start + PD.newMin)}`; return;
  }
  if (PD.kind === "bnew") return;
  // 拖到哪裡：日期格子／方格／時間條
  document.querySelectorAll(".pdrop").forEach(c => c.classList.remove("pdrop"));
  const tgt = document.elementFromPoint(e.clientX, e.clientY);
  const cell = tgt && tgt.closest(".pd[data-date], .dp[data-date], [data-tray], .wgdays [data-drop]"); if (cell) cell.classList.add("pdrop");
  const p = pdTimeAt(e.clientX, e.clientY);
  if (PD.ghost) PD.ghost.dataset.at = p ? hm(p.m) : cell ? (cell.dataset.tray ? "隨時" : short(cell.dataset.date || cell.dataset.drop)) : "";
}
function pdGridSel() {
  document.querySelectorAll(".gsel").forEach(x => x.remove());
  const [a, b] = PD.a <= PD.b ? [PD.a, PD.b + 10] : [PD.b, PD.a + 10];
  for (let hr = Math.floor(a / 60); hr * 60 < b; hr++) {
    const gc = document.querySelector(`.gc[data-hr="${hr}"]:not(.ga)`); if (!gc) continue;
    const s0 = Math.max(a, hr * 60) - hr * 60, e0 = Math.min(b, hr * 60 + 60) - hr * 60;
    const sp = document.createElement("span"); sp.className = "gsel"; sp.style.left = s0 / 60 * 100 + "%"; sp.style.width = (e0 - s0) / 60 * 100 + "%";
    if (s0 === Math.max(a, hr * 60) - hr * 60 && hr === Math.floor(a / 60)) sp.textContent = `${hm(a)}–${hm(b)}`;
    gc.appendChild(sp);
  }
}
function pdEnd(e) {
  if (PD.pid !== e.pointerId) return;
  clearTimeout(PD.t);
  const kind = PD.kind, on = PD.on, id = PD.id;
  document.documentElement.classList.remove("pdragging");
  if (PD.ghost) { PD.ghost.remove(); PD.ghost = null; }
  document.querySelectorAll(".pdsrc").forEach(c => c.classList.remove("pdsrc"));
  document.querySelectorAll(".pdrop").forEach(c => c.classList.remove("pdrop"));
  document.querySelectorAll(".gsel").forEach(x => x.remove());
  PD.kind = null; PD.on = false;
  if (!kind) return;
  // 沒有拖：當成點一下
  if (!on || !PD.moved) {
    if ((kind === "gnew" || kind === "bnew") && Date.now() - (PD.scrolled || 0) > 350) { const p = pdTimeAt(e.clientX, e.clientY); if (p) { PD.swallow = Date.now(); showPlus(p, e.clientX, e.clientY); } }
    document.querySelectorAll(".pd.rsel").forEach(c => c.classList.remove("rsel"));
    PD.a = PD.b = null; return;
  }
  PD.swallow = Date.now();     // 拖完不要再觸發「點一下」
  if (kind === "range") {
    const [a, b] = PD.a <= PD.b ? [PD.a, PD.b] : [PD.b, PD.a];
    document.querySelectorAll(".pd.rsel").forEach(c => c.classList.remove("rsel"));
    PD.a = PD.b = null;
    openSheet({ type: "edit", id: null, date: a, preset: b > a ? { endDate: b, cat: eventCatId() || (S.cats[0] || {}).id } : {} }); return;
  }
  if (kind === "gnew") { const a = Math.min(PD.a, PD.b), b = Math.max(PD.a, PD.b) + 10; const d = PD.date; PD.a = PD.b = null; newAt(d, a, b - a); return; }
  const t = task(id); if (!t) return;
  if (kind === "resize") { if (PD.newMin) { snapshot(); t.min = PD.newMin; t.locked = true; PD.newMin = null; commit(`「${t.title}」改成 ${dur(t.min)}`, true); } return; }
  const tgt = document.elementFromPoint(e.clientX, e.clientY);
  const p = pdTimeAt(e.clientX, e.clientY), cell = tgt && tgt.closest(".pd[data-date]");
  const tray = tgt && tgt.closest("[data-tray]"), strip = tgt && tgt.closest(".dp[data-date], .wgdays [data-drop]");
  if (tray) {
    const other = tgt.closest("[data-tdrag]");
    snapshot();
    if (other && other.dataset.tdrag !== t.id && t.start == null) {        // 待辦盤裡換順序
      const ids = [...tray.querySelectorAll("[data-tdrag]")].map(x => x.dataset.tdrag).filter(x => x !== t.id);
      ids.splice(ids.indexOf(other.dataset.tdrag), 0, t.id);
      ids.forEach((id2, i) => { const y = task(id2); if (y) y.order = i; }); commit(); return;
    }
    t.date = tray.dataset.tray; t.start = null; t.locked = false; t.anytime = true; commit(`「${t.title}」改成隨時都可以做`, true); return;
  }
  if (strip && !p) {
    const d = strip.dataset.date || strip.dataset.drop; if (d === t.date) return;
    snapshot(); if (t.series) t.detached = true; t.date = d; if (!t.locked) t.start = null;
    commit(`「${t.title}」移到 ${short(d)}`, true); return;
  }
  if (p) {                                                   // 放到方格／時間條：改成那個時間
    snapshot(); t.date = p.date; t.start = p.m; t.locked = true; delete t.anytime;
    commit(`「${t.title}」排在 ${short(p.date)} ${hm(p.m)}`, true); return;
  }
  if (cell && cell.dataset.date !== t.date) openSheet({ type: "mvcp", id: t.id, date: cell.dataset.date });
}
/** 點空白：先出現一個「＋ 10:30」，再點一次才新增（滑動時不小心點到也不會跳出新增畫面） */
function showPlus(p, x, y) {
  document.querySelectorAll(".gplus").forEach(b => b.remove());
  const b = document.createElement("button"); b.className = "gplus"; b.dataset.act = "g-plus"; b.dataset.date = p.date; b.dataset.m = p.m;
  b.innerHTML = `${I.plus}${hm(p.m)} 新增`;
  b.style.left = Math.min(innerWidth - 120, Math.max(8, x - 50)) + "px"; b.style.top = (y - 52) + "px";
  document.body.appendChild(b);
  clearTimeout(showPlus.t); showPlus.t = setTimeout(() => b.remove(), 2600);
}
window.addEventListener("scroll", () => { document.querySelectorAll(".gplus").forEach(b => b.remove()); PD.scrolled = Date.now(); if (PD.kind && !PD.on) { clearTimeout(PD.t); PD.kind = null; } }, { passive: true });
function newAt(date, start, min) { document.querySelectorAll(".gplus").forEach(b => b.remove()); openSheet({ type: "edit", id: null, date, preset: { start, min: Math.max(10, min), locked: true } }); }
document.addEventListener("pointerdown", pdStart, { passive: true });
document.addEventListener("pointermove", pdMove, { passive: false });
document.addEventListener("pointerup", pdEnd);
document.addEventListener("pointercancel", e => { if (PD.pid === e.pointerId && !PD.on) { clearTimeout(PD.t); PD.kind = null; } else pdEnd(e); });
document.addEventListener("touchmove", e => { if (PD.on) e.preventDefault(); }, { passive: false });
document.addEventListener("click", e => { if (PD.swallow && Date.now() - PD.swallow < 450) { PD.swallow = 0; e.stopPropagation(); e.preventDefault(); } }, true);
document.addEventListener("contextmenu", e => { if (e.target.closest && e.target.closest(".pcal,.grid10,.pbar,.tray")) e.preventDefault(); });
// 時間條：兩指縮放、ctrl+滾輪縮放
let pinch0 = null;
document.addEventListener("touchstart", e => { if (e.touches.length === 2 && e.target.closest && e.target.closest(".pbs")) pinch0 = { d: Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY), z: ui.pzoom ?? 1 }; }, { passive: true });
document.addEventListener("touchend", () => { pinch0 = null; }, { passive: true });
document.addEventListener("touchmove", e => {
  if (!pinch0 || e.touches.length !== 2) return;
  const d = Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY), r = d / pinch0.d;
  const z = Math.max(0, Math.min(PC.zoom.length - 1, pinch0.z + (r > 1.35 ? 1 : r < 0.75 ? -1 : 0)));
  if (z !== (ui.pzoom ?? 1)) { ui.pzoom = z; pinch0 = { d, z }; renderMain(); }
}, { passive: true });
document.addEventListener("wheel", e => { if (e.ctrlKey && e.target.closest && e.target.closest(".pbs")) { e.preventDefault(); ui.pzoom = Math.max(0, Math.min(PC.zoom.length - 1, (ui.pzoom ?? 1) + (e.deltaY < 0 ? 1 : -1))); renderMain(); } }, { passive: false });

/** 拖到別天：移動還是複製？ */
function sheetMvcp(o) {
  const t = task(o.id); if (!t) return "";
  return sheetWrap(`「${esc(t.title)}」`, cancelBtn(), spacer, `<p class="footnote" style="margin:0">放到 ${full(o.date)}</p>
    <button class="btn primary block" data-act="mvcp-go" data-m="move">移到這天</button>
    <button class="btn block" data-act="mvcp-go" data-m="copy">複製一份到這天</button>`);
}
function mvcpGo(o, mode) {
  const t = task(o.id); if (!t) return;
  snapshot();
  const span = multiEnd(t) ? diff(t.date, multiEnd(t)) : 0;
  if (mode === "copy") {
    const c = { ...t, id: uid(), date: o.date, done: false, doneOn: null, doneAt: null, series: null, occ: null, detached: false, created: Date.now(), resched: 0, wid: undefined };
    if (span) c.endDate = addDays(o.date, span);
    S.tasks.push(normalize(c)); markFresh([c.id]); closeSheet(); commit(`已複製到 ${short(o.date)}`, true);
  } else {
    if (t.series) t.detached = true;
    t.date = o.date; if (span) t.endDate = addDays(o.date, span);
    if (!t.locked) t.start = null;
    closeSheet(); commit(`已移到 ${short(o.date)}`, true);
  }
}

/* ---------- 慶祝：今天的事全部做完 ---------- */
function confetti() {
  if (matchMedia("(prefers-reduced-motion: reduce)").matches || document.documentElement.dataset.anim === "none") return;
  const c = document.createElement("canvas"); c.className = "confetti"; document.body.appendChild(c);
  const W = c.width = innerWidth * devicePixelRatio, H = c.height = innerHeight * devicePixelRatio, g = c.getContext("2d");
  const cols = ["#FF3B30", "#FF9500", "#FFCC00", "#34C759", "#5AC8FA", "#007AFF", "#AF52DE", "#FF2D55"];
  const P = Array.from({ length: 140 }, () => ({ x: W / 2 + (Math.random() - .5) * W * .3, y: H * .35, vx: (Math.random() - .5) * 18 * devicePixelRatio, vy: (-Math.random() * 16 - 6) * devicePixelRatio, r: Math.random() * 6 + 4, a: Math.random() * 6, va: (Math.random() - .5) * .3, c: cols[Math.random() * cols.length | 0] }));
  let f = 0;
  const step = () => {
    g.clearRect(0, 0, W, H);
    for (const p of P) { p.vy += .45 * devicePixelRatio; p.vx *= .99; p.x += p.vx; p.y += p.vy; p.a += p.va; g.save(); g.translate(p.x, p.y); g.rotate(p.a); g.fillStyle = p.c; g.fillRect(-p.r, -p.r / 2, p.r * 2 * devicePixelRatio / 1.5, p.r * devicePixelRatio / 1.5); g.restore(); }
    if (++f < 150) requestAnimationFrame(step); else c.remove();
  };
  requestAnimationFrame(step);
  try { navigator.vibrate && navigator.vibrate([12, 40, 12]); } catch (e) {}
}
function checkDayDone(t) {
  if (!t || !t.done || t.date !== today()) return;
  const list = S.tasks.filter(x => x.date === today() && !isEvent(x) && !x.cancelled);
  if (list.length >= 2 && list.every(x => x.done)) { setTimeout(confetti, 350); toast("今天的事全部做完了 🎉"); }
}

/* ---------- 結束今天：回顧 + 剩下的一鍵移到明天 ---------- */
function sheetWrapUp() {
  const t0 = today(), list = S.tasks.filter(x => x.date === t0 && !isEvent(x) && !x.cancelled);
  const done = list.filter(x => x.done), left = list.filter(x => !x.done);
  const fm = (S.settings.focusLog || []).filter(f => f.d === t0).reduce((a, f) => a + f.m, 0);
  const sel = ui.sheet.sel || (ui.sheet.sel = new Set(left.map(x => x.id)));
  return sheetWrap("結束今天", cancelBtn(), spacer, `<div class="mp-hero"><b>今天完成了 ${done.length} 件${list.length ? `（${Math.round(done.length / list.length * 100)}%）` : ""}</b>
      <small>做完的共 ${dur(done.reduce((a, x) => a + x.min, 0))}${fm ? `・專注 ${dur(fm)}` : ""}</small></div>
    ${left.length ? `<div class="sechead"><h2>還沒做完的 ${left.length} 件</h2><span class="aside">勾選要移到明天的</span></div>
      <div class="list">${left.map(x => `<button class="row wrow${sel.has(x.id) ? " on" : ""}" data-act="wrap-pick" data-id="${x.id}"><span class="chk${sel.has(x.id) ? " on" : ""}">${I.check}</span><span class="rbody"><span class="rtitle">${esc(x.title)}</span><span class="meta"><span>${dur(x.min)}</span></span></span></button>`).join("")}</div>
      <button class="btn primary block" data-act="wrap-go">移 ${sel.size} 件到明天，結束今天</button>` : `<button class="btn primary block" data-act="wrap-go">結束今天 🎉</button>`}`);
}
function wrapGo() {
  const sel = ui.sheet.sel || new Set(), t1 = addDays(today(), 1), ids = [];
  snapshot();
  for (const x of S.tasks) if (sel.has(x.id) && !x.done) { x.date = t1; if (!x.locked) x.start = null; x.resched = (x.resched || 0) + 1; ids.push(x.id); }
  if (ids.length) arrangeTimes(t1, "fill");
  S.settings.wrapDay = today();
  closeSheet(); commit(ids.length ? `已把 ${ids.length} 件移到明天，今天辛苦了` : "今天辛苦了", true); confetti();
}

/* ---------- 專注計時 ---------- */
const FOC = {};
function focusStart(t, mins) {
  focusStop(true);
  Object.assign(FOC, { id: t.id, title: t.title, end: Date.now() + mins * 60000, start: Date.now(), mins, paused: null });
  try { localStorage.setItem("planflow-focus", JSON.stringify(FOC)); } catch (e) {}
  focusRender(); FOC.iv = setInterval(focusTick, 500);
}
function focusTick() {
  if (!FOC.id) return;
  const left = FOC.paused != null ? FOC.paused : FOC.end - Date.now();
  const el = document.getElementById("focusbar"); if (el) { const s0 = Math.max(0, Math.round(left / 1000)); el.querySelector(".ft").textContent = `${Math.floor(s0 / 60)}:${String(s0 % 60).padStart(2, "0")}`; el.style.setProperty("--p", 1 - left / (FOC.mins * 60000)); }
  if (left <= 0 && FOC.paused == null) {
    const t = task(FOC.id); focusLog(FOC.mins);
    notify("專注時間到了", t ? `「${t.title}」做完了嗎？` : "休息一下吧", "focus@" + Date.now());
    focusStop(true); toast(`專注 ${FOC.mins} 分鐘完成！`); if (t && !t.done) openSheet({ type: "edit", id: t.id });
  }
}
function focusLog(m) {
  if (m < 1) return;
  S.settings.focusLog = [...(S.settings.focusLog || []), { d: today(), id: FOC.id, m: Math.round(m), at: Date.now() }].slice(-300);
  const t = task(FOC.id); if (t) t.actMin = (t.actMin || 0) + Math.round(m);
  save();
}
function focusStop(silent) {
  if (FOC.iv) clearInterval(FOC.iv);
  if (!silent && FOC.id) focusLog((Date.now() - FOC.start) / 60000 - (FOC.pausedMs || 0) / 60000);
  for (const k of Object.keys(FOC)) delete FOC[k];
  try { localStorage.removeItem("planflow-focus"); } catch (e) {}
  focusRender();
}
function focusRender() {
  let el = document.getElementById("focusbar");
  if (!FOC.id) { if (el) el.remove(); return; }
  if (!el) { el = document.createElement("div"); el.id = "focusbar"; document.body.appendChild(el); }
  el.innerHTML = `<span class="fring"></span><span class="fn">${esc(FOC.title)}</span><span class="ft num">--:--</span>
    <button data-act="focus-pause" aria-label="${FOC.paused != null ? "繼續" : "暫停"}">${FOC.paused != null ? "▶" : "❚❚"}</button><button data-act="focus-stop" aria-label="結束專注">■</button>`;
  focusTick();
}
try { const f = JSON.parse(localStorage.getItem("planflow-focus") || "null"); if (f && f.end > Date.now()) { Object.assign(FOC, f); setTimeout(() => { focusRender(); FOC.iv = setInterval(focusTick, 500); }, 1500); } } catch (e) {}

/* ---------- 早上的圓形時鐘：今天的行程一圈 ---------- */
function clockSVG(k) {
  const list = S.tasks.filter(x => x.date === k && x.start != null && !x.cancelled), R = 70, C = 90;
  const pt = (m, r) => { const a = m / 1440 * Math.PI * 2 - Math.PI / 2; return [C + r * Math.cos(a), C + r * Math.sin(a)]; };
  const arc = (a, b) => { const [x1, y1] = pt(a, R), [x2, y2] = pt(b, R); return `M${x1.toFixed(1)} ${y1.toFixed(1)}A${R} ${R} 0 ${b - a > 720 ? 1 : 0} 1 ${x2.toFixed(1)} ${y2.toFixed(1)}`; };
  const now = k === today() ? nowMin() : null;
  return `<svg class="pclock" viewBox="0 0 180 180" role="img" aria-label="今天的行程時鐘">
    <circle cx="${C}" cy="${C}" r="${R}" class="ck-bg"/>
    ${[0, 6, 12, 18].map(h => { const [x, y] = pt(h * 60, R - 20); return `<text x="${x}" y="${y + 4}" text-anchor="middle" class="ck-t">${h}</text>`; }).join("")}
    ${list.map(x => `<path d="${arc(x.start, Math.min(1439, x.start + x.min))}" stroke="${catColor(x)}" class="ck-seg${x.done ? " done" : ""}" data-act="edit" data-id="${x.id}"><title>${esc(x.title)} ${range(x)}</title></path>`).join("")}
    ${now != null ? (() => { const [x, y] = pt(now, R + 10); return `<line x1="${C}" y1="${C}" x2="${x}" y2="${y}" class="ck-now"/>`; })() : ""}
    <circle cx="${C}" cy="${C}" r="3" class="ck-c"/></svg>`;
}

function viewStats(embedded) {
  const t = today(), n = ui.range, start = addDays(t, -(n - 1));
  const win = S.tasks.filter(x => x.date >= start && x.date <= t && !isEvent(x) && !x.cancelled);
  const otMin = S.tasks.filter(x => x.date >= start && x.date <= t && x.ot && !x.cancelled).reduce((a, x) => a + x.ot, 0);
  const cancelledN = S.tasks.filter(x => x.date >= start && x.date <= t && x.cancelled).length;
  const completed = S.tasks.filter(x => x.done && x.doneOn && x.doneOn >= start && x.doneOn <= t);
  const rate = win.length ? win.filter(x => x.done).length / win.length : 0;
  const overdueN = S.tasks.filter(isOverdue).length;
  const postponed = win.reduce((s, x) => s + x.resched, 0);

  const days = [];
  for (let i = 0; i < n; i++) { const k = addDays(start, i); days.push({ k, c: completed.filter(x => x.doneOn === k).length }); }
  const maxC = Math.max(2, ...days.map(d => d.c));
  const top = maxC % 2 ? maxC + 1 : maxC;
  const W = 320, H = 150, L = 22, B = 20, T = 8;
  const bw = (W - L) / n;
  let svg = `<svg class="chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="每天完成數長條圖">`;
  for (const v of [0, top / 2, top]) {
    const y = H - B - (v / top) * (H - B - T);
    svg += `<line class="gl" x1="${L}" x2="${W}" y1="${y}" y2="${y}"/><text class="tx" x="${L - 6}" y="${y + 3}" text-anchor="end">${v}</text>`;
  }
  days.forEach((d, i) => {
    const bh = (d.c / top) * (H - B - T);
    const x = L + i * bw + bw * 0.18, w = bw * 0.64;
    if (d.c) svg += `<rect class="b${d.k === t ? " t" : ""}" x="${x}" y="${H - B - bh}" width="${w}" height="${bh}" rx="${Math.min(4, w / 2)}"/>`;
    if (n === 7 || i % 5 === (n - 1) % 5) svg += `<text class="tx" x="${x + w / 2}" y="${H - 5}" text-anchor="middle">${short(d.k)}</text>`;
  });
  svg += "</svg>";

  const groups = S.cats.filter(c => !c.event).map(c => ({ c, list: win.filter(x => x.cat === c.id) })).filter(g => g.list.length);
  const maxG = Math.max(1, ...groups.map(g => g.list.length));
  const postList = S.tasks.filter(x => !x.done && x.resched > 0).sort((a, b) => b.resched - a.resched).slice(0, 5);

  let h = embedded ? head("行事曆", `統計・${short(start)} – ${short(t)}`) + calSeg() : head("統計", `${short(start)} – ${short(t)}`);
  h += `<div class="seg"><button class="${n === 7 ? "on" : ""}" data-act="stat-range" data-n="7">最近 7 天</button><button class="${n === 30 ? "on" : ""}" data-act="stat-range" data-n="30">最近 30 天</button></div>
  <div class="tiles">
    <div class="tile"><span class="v ok">${completed.length}</span><span class="l">完成工作</span></div>
    <div class="tile"><span class="v ac">${Math.round(rate * 100)}%</span><span class="l">完成率（排在這段期間的工作）</span></div>
    <div class="tile"><span class="v wa">${postponed}</span><span class="l">延後次數</span></div>
    <div class="tile"><span class="v ${overdueN ? "da" : ""}">${overdueN}</span><span class="l">目前逾期</span></div>
    <div class="tile"><span class="v wa">${otMin ? hrsTxt(otMin) : 0}</span><span class="l">加班（小時）</span></div>
    <div class="tile"><span class="v">${cancelledN}</span><span class="l">取消的事件</span></div>
  </div>
  <div class="card"><h3>每天完成數</h3>${svg}</div>`;
  if (groups.length) h += `<div class="card"><h3>各分類完成狀況</h3>
    ${groups.map(g => { const d = g.list.filter(x => x.done).length, o = g.list.length - d;
      return `<div class="catbar"><span class="catline"><span class="catdot" style="background:${g.c.color}"></span>${esc(g.c.name)}</span><span class="track"><i style="width:${d / maxG * 100}%;background:var(--ok)"></i><i style="width:${o / maxG * 100}%;background:var(--warn)"></i></span><span class="c num">${d}/${g.list.length}</span></div>`; }).join("")}
    <div class="legend"><span><i style="background:var(--ok)"></i>已完成</span><span><i style="background:var(--warn)"></i>未完成</span></div></div>`;
  if (postList.length) h += `<div class="card"><h3>最常被延後的工作</h3><div class="plist">${postList.map(x => `<div><span>${esc(x.title)}</span><span class="num ${x.resched >= 3 ? "hot" : ""}">${x.resched} 次</span></div>`).join("")}</div><div class="footnote" style="padding:0">一直延後的工作，可以試著拆成更小的步驟。</div></div>`;
  return h;
}

function viewSettings() {
  const s = S.settings;
  const sw = (k, label) => `<div class="field"><label for="sw-${k}">${label}</label><span class="switch"><input type="checkbox" id="sw-${k}" data-set="${k}"${s[k] ? " checked" : ""}><span></span></span></div>`;
  let h = head("設定");
  h += `<section class="sec"><div class="sechead"><h2>排程</h2></div><div class="form">
    ${sw("skipWeekends", "排程時跳過週末")}
    <div class="field col"><span class="lab">時間到了還沒做完時</span>
      <div class="modepick" role="radiogroup">
        <label><input type="radio" name="rmode" data-act="set-mode" data-mode="ask"${s.reflowMode !== "auto" ? " checked" : ""}><span>跳出視窗問我<small>可以選「做完了」「自動往後排」或「自己選時間」</small></span></label>
        <label><input type="radio" name="rmode" data-act="set-mode" data-mode="auto"${s.reflowMode === "auto" ? " checked" : ""}><span>直接自動往後排<small>不問，自動排到之後的空檔，會跳出可以復原的提示</small></span></label>
      </div></div>
    ${s.reflowMode === "auto" ? "" : sw("prompt", "每天開啟時，詢問之前沒做完的工作要排到哪天")}
  </div><p class="footnote">固定事件不會被移動。</p></section>
  ${notifySectionHTML()}
  ${gmailSectionHTML()}
  ${swipeSettingsHTML()}
  <section class="sec"><div class="sechead"><h2>工作時段</h2></div><div class="form">
    <div class="field"><label for="tm-ws">開始工作</label><input type="time" id="tm-ws" step="300" data-time="workStart" value="${hm(s.workStart)}"></div>
    <div class="field"><label for="tm-we">結束工作</label><input type="time" id="tm-we" step="300" data-time="workEnd" value="${hm(s.workEnd)}"></div>
    ${sw("breakOn", "午餐（午休）")}
    ${s.breakOn ? `<div class="field"><label for="tm-bs">午休開始</label><input type="time" id="tm-bs" step="300" data-time="breakStart" value="${hm(s.breakStart)}"></div>
    <div class="field"><label for="tm-be">午休結束</label><input type="time" id="tm-be" step="300" data-time="breakEnd" value="${hm(s.breakEnd)}"></div>` : ""}
    ${sw("dinnerOn", "晚餐")}
    ${s.dinnerOn ? `<div class="field"><label for="tm-ds">晚餐開始</label><input type="time" id="tm-ds" step="300" data-time="dinnerStart" value="${hm(s.dinnerStart)}"></div>
    <div class="field"><label for="tm-de">晚餐結束</label><input type="time" id="tm-de" step="300" data-time="dinnerEnd" value="${hm(s.dinnerEnd)}"></div>` : ""}
    <button class="opt" data-act="setup-open"><span class="ic">${I.cal}</span><span class="main">作息設定<small>工作時段、吃飯時間、每週固定的課或會議，一次設定好</small></span></button>
    <button class="opt" data-act="help"><span class="ic">${I.spark}</span><span class="main">怎麼用<small>排程本的各種用法</small></span></button>
    <div class="field"><label for="set-gap">工作之間休息</label><span class="durpick"><input type="number" inputmode="numeric" id="set-gap" min="0" max="120" step="5" value="${s.gap}" data-setnum="gap"><span>分鐘</span></span></div>
    <div class="field"><span class="lab">每天可以排工作的時間</span><span style="color:var(--detail);font-weight:700">${dur(availMin())}</span></div>
  </div><p class="footnote">${s.workEnd <= s.workStart ? "結束時間要比開始時間晚。" : "智慧排程只會把工作排在開始～結束之間（扣掉午休）；排不下的會移到之後有空的日子。"}</p></section>
  ${estSettingsHTML()}
  <section class="sec"><div class="sechead"><h2>分類</h2></div><div class="form">
    ${S.cats.map(c => `<div class="field"><span class="catline lab"><span class="catdot" style="background:${c.color}"></span>${esc(c.name)}${c.event ? `<span class="evtag">固定事件</span>` : ""}</span><span class="num" style="color:var(--muted);font-size:13px">${S.tasks.filter(x => x.cat === c.id).length}</span><button class="x" style="color:var(--accent)" data-act="cat-event" data-id="${c.id}">${c.event ? "改成一般" : "設為固定事件"}</button><button class="x" data-act="cat-del" data-id="${c.id}">刪除</button></div>`).join("")}
    <div class="field col"><input type="text" id="cat-name" placeholder="新增分類名稱" maxlength="12">
      <div class="swatches">${PALETTE.map((p, i) => `<label><input type="radio" name="catc" value="${p}"${i === 0 ? " checked" : ""}><span style="background:${p}"></span></label>`).join("")}</div>
      <label class="catline" style="font-size:14px"><input type="checkbox" id="cat-event">這個分類是固定事件（例如上課、開會，不用打勾）</label>
      <button class="btn primary" data-act="cat-add" style="align-self:flex-start">${I.plus}新增分類</button></div>
  </div><p class="footnote">「固定事件」分類裡的事情不需要打勾完成，會在清單上分開顯示，並在時間表上占用時段；自動排程會避開它們。</p><div hidden>
  </div></section>
  <section class="sec"><div class="sechead"><h2>資料</h2></div><div class="form">
    ${S.sample ? `<button class="opt" data-act="sample-clear"><span class="main">清除範例工作<small>保留分類，刪掉所有示範用的工作</small></span></button>` : ""}
    <button class="opt" data-act="clean-done"><span class="main">清除 30 天前已完成的工作</span></button>
    <button class="opt" data-act="sample-reset"><span class="main">重新載入範例<small>會取代目前所有工作</small></span></button>
  </div><p class="footnote">工作存在你的帳號裡，手機和電腦會自動同步；沒有網路時也能用，連上後會補傳。</p></section>
  <section class="sec"><div class="sechead"><h2>外觀</h2></div><div class="form">
    <div class="field col"><span class="lab">風格</span>
      <div class="skinpick">
        <button class="${s.skin !== "glass" && s.skin !== "oldschool" ? "on" : ""}" data-act="set-skin" data-skin="ios6"><span class="sw ios6"></span><span class="lbl">iOS 6 擬物</span></button>
        <button class="${s.skin === "glass" ? "on" : ""}" data-act="set-skin" data-skin="glass"><span class="sw glass"></span><span class="lbl">液態玻璃</span></button>
        <button class="${s.skin === "oldschool" ? "on" : ""}" data-act="set-skin" data-skin="oldschool"><span class="sw oldschool"></span><span class="lbl">old school</span></button>
      </div></div>
    <div class="field col"><span class="lab">方格的打勾記號</span><div class="seg">${Object.entries(MARKS).map(([k, [a, b]]) => `<button class="${(s.gridMark || "circle") === k ? "on" : ""}" data-act="set-mark" data-m="${k}">${a}${b}</button>`).join("")}</div></div>
    <div class="field col"><span class="lab">動畫</span>
      <div class="animpick">${ANIMS.map(([k, n, d]) => `<button class="${(s.anim || "ios") === k ? "on" : ""}" data-act="set-anim" data-anim="${k}"><span class="ap ap-${k}" aria-hidden="true"><i></i></span><b>${n}</b><small>${d}</small></button>`).join("")}</div></div>
    <div class="field"><span class="bgprev" style="${bgData ? `background-image:url('${bgData}')` : ""}" aria-hidden="true"></span>
      <span class="lab" style="flex:1">背景照片<small style="display:block;font-weight:400;color:var(--muted);font-size:12px">${bgData ? "正在使用你的照片" : s.skin === "glass" ? "目前是玻璃漸層背景" : "目前是 iOS 6 直條紋背景"}</small></span>
      <span class="btnrow" style="flex-direction:column;align-items:stretch"><button class="btn primary" data-act="bg-pick">選擇照片</button>${bgData ? `<button class="btn" data-act="bg-clear">換回預設</button>` : ""}</span></div>
    ${bgData ? `<div class="field"><label for="sw-bgDim">照片調暗（文字比較清楚）</label><span class="switch"><input type="checkbox" id="sw-bgDim" data-bgdim${s.bgDim !== false ? " checked" : ""}><span></span></span></div>` : ""}
  </div><p class="footnote">照片會存在你的帳號裡，換手機或電腦登入也看得到。</p></section>
  <section class="sec"><div class="sechead"><h2>智慧排程</h2></div><div class="form">
    <div class="field col"><label for="ai-key">Gemini API 金鑰（選填）</label>
      <input type="password" id="ai-key" autocomplete="off" placeholder="${s.geminiKey ? "已設定（要更換請貼上新的）" : "貼上以 AIza 開頭的金鑰"}" style="border:0;background:var(--surface-2);border-radius:8px;padding:8px 10px">
      <div class="btnrow"><button class="btn primary" data-act="ai-key-save">儲存金鑰</button>${s.geminiKey ? `<button class="btn" data-act="ai-key-clear">移除金鑰</button>` : ""}</div>
    </div>
  </div><p class="footnote">${s.geminiKey ? "目前使用你的 Gemini 金鑰。" : "沒有金鑰也能用智慧排程。"}想讓它看懂更複雜的句子，可以到 aistudio.google.com/api-keys 免費申請 Gemini 金鑰貼在這裡；金鑰只存在你的帳號裡，別人看不到。</p></section>
  ${smartSettingsHTML()}
  ${brainSettingsHTML()}
  <section class="sec"><div class="sechead"><h2>帳號</h2></div><div class="form">
    <div class="field acct">${FB.user && FB.user.photoURL ? `<img src="${esc(FB.user.photoURL)}" alt="" referrerpolicy="no-referrer">` : ""}<span class="who">${esc((FB.user && FB.user.displayName) || "已登入")}<small>${esc((FB.user && FB.user.email) || "")}</small></span><button class="btn" data-act="logout">登出</button></div>
  </div></section>`;
  return h;
}

/* ---------- Sheets ---------- */
function sheetWrap(title, left, right, body) {
  return `<div class="scrim" data-act="close"></div><div class="sheet" tabindex="-1" style="outline:none" role="dialog" aria-modal="true" aria-label="${title}">
    <div class="sheethead">${left}<strong>${title}</strong>${right}</div><div class="sheetbody">${body}</div></div>`;
}
const cancelBtn = (label = "取消") => `<button data-act="close">${label}</button>`;
const spacer = `<button tabindex="-1" aria-hidden="true" style="visibility:hidden">取消</button>`;

function loadText(k, t) {
  const used = loadMap(new Set([t.id]))[k] || 0;
  if (!used) return { txt: "當天還沒有其他工作", over: false };
  const over = used + t.min > dayCap();
  return { txt: `當天已排 ${dur(used)}${over ? "，會超過" : ""}`, over };
}

function sheetMove(t, fromDue) {
  const start = isOverdue(t) ? today() : addDays(today(), 1);
  const sug = plan([t], start)[t.id];
  const base = maxKey(t.date, today());
  const opts = [];
  if (t.date !== today()) opts.push(["今天", today(), I.sun]);
  opts.push(["明天", addDays(today(), 1), I.arrow], ["後天", addDays(today(), 2), I.arrow], ["下週一", nextMonday(), I.cal], ["一週後", addDays(base, 7), I.cal]);
  const sl = loadText(sug, t);
  const body = `<div class="taskhead"><strong>${esc(t.title)}</strong><div class="meta"><span>目前：${rel(t.date)}</span><span>需要 ${dur(t.min)}</span>${t.deadline ? `<span>截止 ${md(t.deadline)}</span>` : ""}</div>
    ${t.resched >= 3 ? `<div class="warnline">這項工作已經延後 ${t.resched} 次了，可以考慮拆小一點，或提高優先順序。</div>` : ""}</div>
    ${t.wid ? `<section class="sec"><div class="sechead"><h2>智慧排法</h2></div><div class="form">
      <button class="opt suggest" data-act="wk-replan" data-id="${t.id}"><span class="ic">${I.wand}</span><span class="main">把剩下的時數排進截止日前的空檔<small>${esc(t.wname)}・截止 ${md(t.deadline)}</small></span></button></div></section>` : ""}
    <section class="sec"><div class="sechead"><h2>智慧建議</h2></div><div class="form">
      <button class="opt suggest" data-act="move-to" data-id="${t.id}" data-date="${sug}"><span class="ic">${I.spark}</span><span class="main">${rel(sug) === md(sug) ? md(sug) : `${rel(sug)}　${md(sug)}`}<small>${sl.txt}</small></span></button></div></section>
    <section class="sec"><div class="sechead"><h2>快速選擇</h2></div><div class="form">
      ${opts.map(([n, k, ic]) => { const l = loadText(k, t); return `<button class="opt" data-act="move-to" data-id="${t.id}" data-date="${k}"><span class="ic">${ic}</span><span class="main">${n}</span><span class="side">${md(k)}<small class="${l.over ? "over" : ""}">${l.txt}</small></span></button>`; }).join("")}
    </div></section>
    <section class="sec"><div class="sechead"><h2>自訂日期</h2></div><div class="form">
      <div class="field"><label for="mv-date">日期</label><input type="date" id="mv-date" min="${today()}" value="${fromDue ? today() : addDays(base, 1)}"></div>
      <div class="field"><label for="mv-time">時間（選填）</label><input type="time" id="mv-time" step="300" value="${fromDue ? hm(Math.min(Math.ceil(nowMin() / 15) * 15 + 15, 23 * 60)) : ""}"></div>
      <div class="field"><span class="lab" id="mv-load" style="font-size:13px;color:var(--muted)">${loadText(fromDue ? today() : addDays(base, 1), t).txt}</span><button class="btn primary" data-act="move-custom" data-id="${t.id}">移過去</button></div>
    </div><p class="footnote">有填時間就固定在那個時間；沒填的話，會在時間表裡自動排進那天有空的時段。</p></section>`;
  return sheetWrap("重新規劃", cancelBtn(), spacer, body);
}

function sheetBulk(b) {
  const list = b.ids.map(task).filter(Boolean);
  const body = `<p class="footnote" style="margin:0">依照優先順序、截止日和工作時段（${hm(S.settings.workStart)}–${hm(S.settings.workEnd)}）自動分配日期。可以取消勾選，或逐項改日期。</p>
    <div class="form">
      <div class="field"><label for="bk-from">從 ${rel(addDays(b.base, 1))} 開始排</label><span class="switch"><input type="checkbox" id="bk-from" data-bulk="from"${b.from ? " checked" : ""}><span></span></span></div>
      <div class="field"><label for="bk-skip">跳過週末</label><span class="switch"><input type="checkbox" id="bk-skip" data-bulk="skip"${S.settings.skipWeekends ? " checked" : ""}><span></span></span></div>
    </div>
    <section class="sec"><div class="sechead"><h2>排程預覽</h2><span class="aside">${b.sel.size} / ${list.length} 項</span></div><div class="form">
    ${list.map(t => { const on = b.sel.has(t.id); return `<div class="brow ${on ? "on" : "off"}">
      <button class="chk" data-act="bulk-pick" data-id="${t.id}" aria-label="${on ? "不要移動" : "要移動"}「${esc(t.title)}」">${I.check}</button>
      <div class="rbody"><div class="rtitle">${esc(t.title)}</div><div class="meta"><span>優先 ${PRI[t.pri]}</span><span>${dur(t.min)}</span>${t.deadline ? `<span>截止 ${short(t.deadline)}</span>` : ""}</div></div>
      <input type="date" min="${today()}" value="${b.plan[t.id]}" data-bulkdate="${t.id}" aria-label="「${esc(t.title)}」的新日期"${on ? "" : " disabled"}></div>`; }).join("")}
    </div></section>`;
  return sheetWrap(`重新規劃 ${list.length} 項`, cancelBtn("稍後"), `<button class="strong" data-act="bulk-apply"${b.sel.size ? "" : " disabled"}>套用</button>`, body);
}

function repeatNote(preset, skip, existing) {
  if (preset === "none") return "例如每天運動、每週三上課、每月繳房租。";
  return "從排定日期開始，自動產生未來 4 週的工作。" + (skip ? "沒完成的那一次會自動略過，不會累積成逾期。" : "沒完成的會留下來，可以重新規劃。") + (existing ? "儲存後會套用到之後還沒完成的每一次。" : "");
}
function sheetDue(d) {
  const list = d.ids.map(task).filter(t => t && !t.done);
  const body = `<p class="footnote" style="margin:0">這些工作的時段已經過了，還沒有打勾。要怎麼處理？</p>
    ${list.map(t => `<div class="due-card">
      <div><strong>${esc(t.title)}</strong><div class="when">原本 ${range(t)}・${dur(t.min)}</div></div>
      <div class="btnrow">
        <button class="btn ok" data-act="due-done" data-id="${t.id}">${I.check}做完了</button>
        <button class="btn primary" data-act="due-auto" data-id="${t.id}">${I.wand}自動往後排</button>
        <button class="btn" data-act="due-manual" data-id="${t.id}">${I.cal}自己選時間</button>
      </div></div>`).join("")}
    ${list.length > 1 ? `<button class="btn primary block" data-act="due-auto-all">${I.wand}全部自動往後排</button>` : ""}
    <p class="footnote" style="margin:0">「自動往後排」會放進今天之後的空檔，今天排不下就移到之後有空的日子。按「稍後」會在 15 分鐘後再問。</p>`;
  return sheetWrap("時間到了", `<button data-act="due-snooze">稍後</button>`, spacer, body);
}
function sheetAI(a) {
  if (a.step === "loading") return sheetWrap("智慧排程", cancelBtn(), spacer, `<div class="ai-loading"><div class="spinner" aria-hidden="true"></div><p>${a.files && a.files.length ? "正在讀取檔案、排進你的行程…<br><small>圖片和 PDF 大約要 10–40 秒</small>" : "正在排進你的行程…"}</p></div>`);
  if (a.step === "preview") {
    const n = a.sel.size + (a.csel ? a.csel.size : 0);
    const catOpts = cur => `<option value="">無</option>${S.cats.map(c => `<option value="${c.id}"${c.id === cur ? " selected" : ""}>${esc(c.name)}</option>`).join("")}`;
    const minOpts = cur => { const list = MINUTES.includes(cur) ? MINUTES : [...MINUTES, cur].sort((x, y) => x - y); return list.map(m => `<option value="${m}"${m === cur ? " selected" : ""}>${dur(m)}</option>`).join(""); };
    const body = `${gemBarHTML(a)}${changesHTML(a)}${a.changes && a.changes.length && a.items.length ? `<div class="sechead"><h2>新增的</h2></div>` : ""}<p class="footnote" style="margin:0${a.items.length ? "" : ";display:none"}">已依照優先順序、截止日、每天可用時間和固定事件排好。每一項都可以直接修改，不要的取消勾選。開始時間留空，會自動排進當天有空的時段。</p>
      ${a.items.map(t => { const on = a.sel.has(t.id), c = cat(t.cat), ev = c && c.event;
        return `<div class="pv-card${on ? "" : " off"}">
          <div class="pv-top">
            <button class="chk${on ? " on" : ""}" data-act="ai-pick" data-id="${t.id}" aria-label="${on ? "不要加入" : "要加入"}「${esc(t.title)}」">${I.check}</button>
            <input type="text" class="pv-title" value="${esc(t.title)}" data-aif="title" data-id="${t.id}" maxlength="80" aria-label="名稱">
          </div>
          <div class="pv-grid">
            <label>日期<input type="date" min="${today()}" value="${t.date}" data-aif="date" data-id="${t.id}"></label>
            <label>開始時間<input type="time" step="300" value="${t.start != null ? hm(t.start) : ""}" data-aif="start" data-id="${t.id}"></label>
            <div class="pv-dur durfield" data-durgroup="pv" data-id="${t.id}"><span>需要多久</span>${durPickHTML(t.min, `data-dur="pv" data-id="${t.id}"`)}</div>
            <label>分類<select data-aif="cat" data-id="${t.id}">${catOpts(t.cat)}</select></label>
            ${ev ? "" : `<label>優先順序<select data-aif="pri" data-id="${t.id}">${PRI.map((p, i) => `<option value="${i}"${i === t.pri ? " selected" : ""}>${p}</option>`).join("")}</select></label>`}
            ${ev ? "" : `<label>截止日<input type="date" value="${t.deadline || ""}" data-aif="deadline" data-id="${t.id}"></label>`}
          </div>
          <label class="pv-notes">備註<input type="text" value="${esc(t.notes || "")}" data-aif="notes" data-id="${t.id}" placeholder="地點、細節（選填）"></label>
          <div class="ai-when" id="pvw-${t.id}">${t.repeat ? `${I.repeat.replace("<svg", '<svg style="width:12px;height:12px;vertical-align:-2px"')} ${seriesSummary({ ...t.repeat, anchor: t.date })}${t.repeat.until ? `（到 ${+t.repeat.until.slice(5, 7)}/${+t.repeat.until.slice(8)}）` : ""}，從 ` : ""}${pvWhen(t)}</div>
          ${on ? pvConflictHTML(t, a) : ""}
          ${!ev && !t.repeat && t.min >= 120 && !/（\d+\/\d+）$/.test(t.title) && !/：/.test(t.title) ? `<button class="btn sm pv-split" data-act="ai-split" data-id="${t.id}"${a.splitting ? " disabled" : ""}>${a.splitting === t.id ? "正在拆…" : `${I.wand}拆成小步驟`}</button>` : ""}
        </div>`; }).join("")}
      <button class="btn" data-act="ai-back" style="align-self:flex-start">修改輸入內容</button>`;
    const nc = a.changes ? a.changes.filter(c => !c.miss).length : 0;
    return sheetWrap(nc ? (a.items.length ? `修改 ${nc}・新增 ${a.items.length}` : `修改 ${nc} 項`) : `排好 ${a.items.length} 項`, cancelBtn(), `<button class="strong" data-act="ai-apply"${n ? "" : " disabled"}>${nc ? "套用" : `加入 ${n} 項`}</button>`, body);
  }
  const body = `${a.step === "error" ? `<div class="gate-err">${esc(a.error)}${a.detail ? `<div style="margin-top:6px;font-size:11px;opacity:.8;word-break:break-all">技術訊息：${esc(a.detail)}</div>` : ""}</div>` : ""}
    <textarea id="ai-text" class="ai-text" placeholder="把要做的事打出來，或說哪件事改時間、取消…" aria-label="要做的事">${esc(a.text || "")}</textarea>
    ${startersHTML()}
    <div class="ai-ex"><b>一行一件事，隨口說就好：</b><br>記得明天下午兩點去學校跟教授開會<br>週五前交熱傳報告，大概 3 小時，很重要<br>每週三下午2點到5點上兩相流<br>每天早上背單字 30 分鐘<br>下班後去全聯買菜、睡前讀論文<br>這週末跟朋友看電影、有空整理房間<br>11/1到11/7：讀完熱傳5章、寫實驗報告（會自動分配到每天的空檔）<br><b>改行程也可以：</b>讀高流改到週四晚上 8 點、取消週五的聚餐、昨天沒做完：熱傳作業<br><button class="linkbtn" data-act="help" style="padding:4px 0">怎麼用？</button></div>
    ${aiFilesHTML(a)}
    ${(a.files || []).length && !llmKey() ? `<div class="gate-err">讀課表、PDF 和圖片要用 AI：到「設定 › AI 排程」貼上你的 Gemini 金鑰（免費）。</div>` : ""}
    <button class="btn primary block" data-act="ai-run">${I.spark}幫我排程</button>
    <p class="footnote" style="margin:0">會看懂日期、時間、需要多久、急不急，再避開固定事件、排進有空的日子和時段。給一個日期區間，會把事情平均分到區間內的空檔；也可以放課表照片或 PDF（要先設定 Gemini 金鑰）。排好後每一項都可以先修改再加入。</p>`;
  return sheetWrap("智慧排程", cancelBtn(), spacer, body);
}
/** 預覽項目的衝突：跟現有行程、也跟其他要加入的項目比 */
function pvConflictHTML(t, a) {
  const pool = [...S.tasks, ...a.items.filter(x => x.id !== t.id && a.sel.has(x.id))];
  const cf = conflictsFor(t, pool);
  if (!cf.length) return "";
  return `<div class="conflict">⚠ ${esc(conflictText(cf))}<button class="btn sm" data-act="ai-fix" data-id="${t.id}">改到最近有空的時間</button></div>`;
}
function pvWhen(t) {
  return `${rel(t.date)}　${t.start != null ? range(t) : "時段：加入後自動安排"}${t.window ? `<span class="pv-win">區間 ${t.window}</span>` : ""}`;
}
function sheetEditor(e) {
  const t = e.id ? task(e.id) : null;
  const v = t || { title: "", notes: "", date: e.date, deadline: null, pri: 1, min: 30, cat: S.cats[0] ? S.cats[0].id : "", start: null, locked: false, ...(e.preset || {}) };
  const ser = t && t.series ? seriesOf(t.series) : null;
  let preset = "none", wdays = [parse(v.date).getDay()], wint = 1, nint = 2;
  if (ser) {
    const n = Math.max(1, ser.interval || 1);
    if (ser.freq === "daily") { if (n === 1) preset = "daily"; else { preset = "ndays"; nint = n; } }
    else if (ser.freq === "weekly") {
      const days = ser.weekdays && ser.weekdays.length ? ser.weekdays : [parse(ser.anchor).getDay()];
      if (n === 1 && days.slice().sort().join() === "1,2,3,4,5") preset = "weekdays"; else { preset = "weekly"; wdays = days; wint = n; }
    } else preset = "monthly";
  }
  const repOn = preset !== "none";
  const wk = t && t.wid ? workProgress(t.wid) : null, wkMiss = wk ? missedChunks(t.wid) : [];
  const body = `<div class="untimed" id="ed-conflict" hidden></div>
    ${!t ? `<button class="opt wk-entry" data-act="wk-from-ed"><span class="ic">${I.spark}</span><span class="main">智慧排法：拆段排到截止日前<small>只填名稱、總共要花多久（可以不填）、截止日，自動拆段分散到不同天的空檔</small></span></button>` : ""}
    ${wk ? `<section class="sec"><div class="sechead"><h2>智慧排法</h2></div><div class="form">
      <div class="field col">${workLineHTML(t.wid)}<small style="color:var(--muted)">共 ${wk.n} 段，已完成 ${wk.nd} 段・截止 ${md(wk.deadline)}</small></div>
      <button class="opt" data-act="wk-more" data-id="${t.id}"><span class="ic">${I.plus}</span><span class="main">還需要更多時間<small>多加幾小時，排進截止日前的空檔；不夠會提醒你</small></span></button>
      ${wkMiss.length ? `<button class="opt" data-act="wk-replan" data-id="${t.id}"><span class="ic">${I.wand}</span><span class="main">重新安排沒做完的 ${hrsTxt(wkMiss.reduce((a, x) => a + x.min, 0))} 小時<small>只把剩下的時數排進之後的空檔</small></span></button>` : ""}
    </div></section>` : ""}
    <div class="form">
      <div class="field"><input type="text" id="ed-title" placeholder="工作名稱" value="${esc(v.title)}" maxlength="80" aria-label="工作名稱"></div>
      <div class="field"><textarea id="ed-notes" rows="2" placeholder="備註（選填）" aria-label="備註">${esc(v.notes)}</textarea></div>
    </div>
    <section class="sec"><div class="sechead"><h2>分類與優先順序</h2></div><div class="form">
      <div class="field"><label for="ed-cat">分類</label><select id="ed-cat"><option value="">無</option>${S.cats.map(c => `<option value="${c.id}"${c.id === v.cat ? " selected" : ""}>${esc(c.name)}</option>`).join("")}<option value="__new">＋ 新增分類…</option></select></div>
      <div class="field col" id="ed-newcat" hidden>
        <input type="text" id="ed-newcat-name" placeholder="新分類的名稱，例如：社團" maxlength="12" aria-label="新分類名稱" style="border:0;background:var(--surface-2);border-radius:8px;padding:8px 10px">
        <div class="swatches">${PALETTE.map((c, i) => `<label><input type="radio" name="ed-newcat-color" value="${c}"${i === 5 ? " checked" : ""}><span style="background:${c}"></span></label>`).join("")}</div>
        <label class="catline" style="font-size:14px"><input type="checkbox" id="ed-newcat-event">固定事件（例如上課、開會，不用打勾）</label>
        <div class="btnrow"><button class="btn primary" data-act="ed-cat-add">${I.plus}新增這個分類</button><button class="btn" data-act="ed-cat-cancel">取消</button></div>
      </div>
      <div class="field col"><div class="seg" role="radiogroup" aria-label="優先順序">${PRI.map((p, i) => `<label><input type="radio" name="ed-pri" value="${i}"${i === v.pri ? " checked" : ""}><span>${p}</span></label>`).join("")}</div></div>
    </div></section>
    <section class="sec"><div class="sechead"><h2>時間</h2></div><div class="form">
      <div class="field"><label for="ed-date">排定日期</label><input type="date" id="ed-date" value="${v.date}"></div>
      <div class="field col durfield" data-durgroup="ed"><span class="lab">預估時間</span>${durPickHTML(v.min, 'data-dur="ed"', "ed-min")}</div>
      <div class="field"><label for="ed-hasdl">截止日期</label><span class="switch"><input type="checkbox" id="ed-hasdl"${v.deadline ? " checked" : ""}><span></span></span></div>
      <div class="field" id="ed-dlrow"${v.deadline ? "" : " hidden"}><label for="ed-dl">截止</label><input type="date" id="ed-dl" value="${v.deadline || addDays(v.date, 3)}"></div>
      ${t && !t.done && !isEvent(t) ? `<div class="field col"><span class="lab">開始專注<small class="sub">計時、記下實際花的時間（方格的「實際」會用）</small></span><div class="btnrow">${[25, 50, Math.min(180, t.min)].filter((m, i, a) => a.indexOf(m) === i).map(m => `<button class="btn sm" data-act="focus-start" data-id="${t.id}" data-m="${m}">⏱ ${m} 分鐘</button>`).join("")}</div></div>` : ""}
      <button class="opt" data-act="ed-suggest"><span class="ic">${I.spark}</span><span class="main">幫我找有空的一天<small id="ed-hint">會考慮每天已排的工作量、優先順序與截止日</small></span></button>
      ${t && !t.done && !isEvent(t) && !t.series && !t.wid && t.min >= 90 ? `<button class="opt" data-act="ed-split" data-id="${t.id}"><span class="ic">${I.wand}</span><span class="main">拆成小步驟<small>${llmKey() ? `用 ${esc(llmName())} 拆成` : "拆成"}幾個具體的步驟，依序排到${t.deadline ? "截止日" : "之後幾天"}前</small></span></button>` : ""}
    </div></section>
    <section class="sec"><div class="sechead"><h2>時段</h2></div><div class="form">
      <div class="field"><label for="ed-multi">跨好幾天<small class="sub">在月曆上連成一條</small></label><span class="switch"><input type="checkbox" id="ed-multi"${v.endDate ? " checked" : ""} onchange="document.getElementById('ed-endrow').hidden=!this.checked"><span></span></span></div>
      <div class="field" id="ed-endrow"${v.endDate ? "" : " hidden"}><label for="ed-end">結束日期</label><input type="date" id="ed-end" value="${v.endDate || addDays(v.date, 1)}"></div>
      <div class="field"><label for="ed-dday">D-day 倒數<small class="sub">在月曆、今天上面顯示還有幾天</small></label><span class="switch"><input type="checkbox" id="ed-dday"${v.dday ? " checked" : ""}><span></span></span></div>
      <div class="field"><label for="ed-fixed">指定開始時間</label><span class="switch"><input type="checkbox" id="ed-fixed"${v.locked ? " checked" : ""}><span></span></span></div>
      <div class="field" id="ed-timerow"${v.locked ? "" : " hidden"}><label for="ed-time">開始</label><input type="time" id="ed-time" step="300" value="${hm(v.start != null ? v.start : S.settings.workStart)}"></div>
      ${!v.locked && v.start != null ? `<div class="field"><span class="lab">目前自動排在</span><span class="num">${range(v)}</span></div>` : ""}
    </div><p class="footnote" id="ed-timenote">${v.locked ? "固定時間的工作（例如會議、上課）不會被自動排程移動。" : "不指定的話，會在時間表裡自動排進當天有空的時段。"}</p></section>
    <section class="sec"><div class="sechead"><h2>重複</h2></div><div class="form">
      <div class="field"><label for="ed-rep">重複</label><select id="ed-rep">${REPEAT_PRESETS.map(([k, n]) => `<option value="${k}"${k === preset ? " selected" : ""}>${n}</option>`).join("")}</select></div>
      <div class="field col" id="ed-rep-weekly"${preset === "weekly" ? "" : " hidden"}>
        <div class="wd-pick" role="group" aria-label="星期幾">${WD.map((w, i) => `<label><input type="checkbox" name="ed-wd" value="${i}"${wdays.includes(i) ? " checked" : ""}><span>${w}</span></label>`).join("")}</div>
      </div>
      <div class="field" id="ed-rep-wint"${preset === "weekly" ? "" : " hidden"}><label for="ed-wint">每幾週一次</label><input type="number" inputmode="numeric" id="ed-wint" min="1" max="12" value="${wint}"></div>
      <div class="field" id="ed-rep-ndays"${preset === "ndays" ? "" : " hidden"}><label for="ed-nint">每隔幾天</label><input type="number" inputmode="numeric" id="ed-nint" min="2" max="365" value="${nint}"></div>
      <div class="field" id="ed-rep-monthly"${preset === "monthly" ? "" : " hidden"}><span class="lab">每月的日期</span><span>依排定日期的那一天</span></div>
      <div class="field" id="ed-rep-until"${repOn ? "" : " hidden"}><label for="ed-hasuntil">結束日期</label><span class="switch"><input type="checkbox" id="ed-hasuntil"${ser && ser.until ? " checked" : ""}><span></span></span></div>
      <div class="field" id="ed-untilrow"${repOn && ser && ser.until ? "" : " hidden"}><label for="ed-until">重複到</label><input type="date" id="ed-until" value="${(ser && ser.until) || addDays(v.date, 30)}"></div>
      <div class="field" id="ed-rep-skip"${repOn ? "" : " hidden"}><label for="ed-skip">沒完成就略過</label><span class="switch"><input type="checkbox" id="ed-skip"${!ser || ser.skipMissed ? " checked" : ""}><span></span></span></div>
      ${ser ? `<div class="field"><span class="lab">目前設定</span><span>${seriesSummary(ser)}</span></div>` : ""}
    </div><p class="footnote" id="ed-repnote">${repeatNote(preset, !ser || ser.skipMissed, !!ser)}</p></section>
    ${t ? `<div class="form">${t.resched ? `<div class="field"><span class="lab">已延後</span><span class="num">${t.resched} 次</span></div>` : ""}
      <button class="opt" data-act="ed-cancel" data-id="${t.id}"><span class="ic">${t.cancelled ? I.redo : I.x}</span><span class="main">${t.cancelled ? "恢復這件事" : "取消這件事"}<small>${t.cancelled ? "取消的事會留下紀錄，恢復後會重新排" : "保留紀錄、不再排時間，可以再恢復"}</small></span></button>
      ${!e.confirmDel ? `<button class="opt" data-act="ed-del"><span class="main" style="color:var(--danger)">刪除這項工作</span></button>`
        : ser ? `<button class="opt" data-act="ed-del-yes"><span class="main" style="color:var(--danger)">只刪除這一次</span></button><button class="opt" data-act="ed-del-series"><span class="main" style="color:var(--danger)">刪除這次和之後全部（停止重複）</span></button>`
        : `<button class="opt" data-act="ed-del-yes"><span class="main" style="color:var(--danger)">再按一次確定刪除</span></button>`}</div>` : ""}`;
  return sheetWrap(t ? "編輯工作" : "新增工作", cancelBtn(), `<button class="strong" data-act="ed-save">儲存</button>`, body);
}

/* ---------- Render ---------- */
const TAB_ICONS = {
  today: '<svg class="tab-ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M3 3.5h4.5V8H3zM10 4.5h11v2.5H10zM3 10h4.5v4.5H3zM10 11h11v2.5H10zM3 16.5h4.5V21H3zM10 17.5h11V20H10z"/></svg>',
  calendar: '<svg class="tab-ic" viewBox="0 0 24 24" aria-hidden="true"><path fill-rule="evenodd" d="M7 1.5h2.2V4h5.6V1.5H17V4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2zM5 9.5V20h14V9.5zM7 12h4v3.5H7z"/></svg>',
  stats: '<svg class="tab-ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M3 13h4.5v8H3zM9.75 8h4.5v13h-4.5zM16.5 3H21v18h-4.5z"/></svg>',
  memo: '<svg class="tab-ic" viewBox="0 0 24 24" aria-hidden="true"><path fill-rule="evenodd" d="M5 2.5h10l4.5 4.5v13a1.5 1.5 0 0 1-1.5 1.5H5A1.5 1.5 0 0 1 3.5 20V4A1.5 1.5 0 0 1 5 2.5zM14 3.5V8h4.5zM7 11h10v1.8H7zm0 3.6h10v1.8H7zm0 3.6h6.5V20H7z"/></svg>',
  share: '<svg class="tab-ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M9 3.2a3.8 3.8 0 1 1 0 7.6 3.8 3.8 0 0 1 0-7.6zM1.5 20.5c0-4 3.4-7.2 7.5-7.2s7.5 3.2 7.5 7.2V21h-15zM17 5a3.2 3.2 0 1 1 0 6.4A3.2 3.2 0 0 1 17 5zm.6 8.3c2.9.3 5 2.7 5 5.7V21h-4.4v-.5c0-2.8-1.1-5.3-2.9-7a7 7 0 0 1 2.3-.2z"/></svg>',
  settings: '<svg class="tab-ic" viewBox="0 0 24 24" aria-hidden="true"><path fill-rule="evenodd" d="M10.3 1.5h3.4l.5 2.7a8.2 8.2 0 0 1 2 1.15l2.6-.95 1.7 2.95-2.1 1.8a8.4 8.4 0 0 1 0 2.3l2.1 1.8-1.7 2.95-2.6-.95a8.2 8.2 0 0 1-2 1.15l-.5 2.7h-3.4l-.5-2.7a8.2 8.2 0 0 1-2-1.15l-2.6.95-1.7-2.95 2.1-1.8a8.4 8.4 0 0 1 0-2.3l-2.1-1.8 1.7-2.95 2.6.95a8.2 8.2 0 0 1 2-1.15zM12 8.3a3.7 3.7 0 1 0 0 7.4 3.7 3.7 0 0 0 0-7.4z"/></svg>'
};
const TABS = [["today", "今天", TAB_ICONS.today], ["calendar", "行事曆", TAB_ICONS.calendar], ["memo", "備忘錄", TAB_ICONS.memo], ["share", "共享", TAB_ICONS.share], ["settings", "設定", TAB_ICONS.settings]];
function viewGate() {
  const err = FB.error ? `<div class="gate-err">${esc(FB.error)}</div>` : "";
  if (!FB.ready) return `<div class="gate"><div class="spinner" aria-hidden="true"></div><p>載入中…</p>${err}</div>`;
  if (!FB.user) return `<div class="gate">
      <img class="gate-icon" src="icon-192.png" alt="" width="88" height="88">
      <h1>排程本</h1>
      <p>沒做完的工作，一鍵排到未來。<br>登入後，紀錄會存在你的帳號，手機和電腦同步。</p>
      ${err}
      ${typeof firebase === "undefined" || !firebase.apps.length ? "" : `<button class="gbtn" data-act="login"><svg viewBox="0 0 48 48" aria-hidden="true"><path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.7 29.2 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.3-.1-2.4-.4-3.5z"/><path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.7 15.1 19 12 24 12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z"/><path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35.1 26.7 36 24 36c-5.2 0-9.6-3.3-11.3-7.9l-6.5 5C9.5 39.6 16.2 44 24 44z"/><path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.2-2.2 4.2-4.1 5.6l6.2 5.2C37 39.2 44 34 44 24c0-1.3-.1-2.4-.4-3.5z"/></svg>用 Google 帳號登入</button>`}
      <p class="gate-note">iPhone：用 Safari 打開，按分享 › 加入主畫面，就能像 App 一樣使用。</p>
    </div>`;
  return `<div class="gate"><div class="spinner" aria-hidden="true"></div><p>正在同步你的工作…</p>${err}</div>`;
}
function renderMain() {
  const gated = !FB.preview && (!FB.user || !FB.loaded);
  document.querySelector(".tabbar").hidden = gated;
  document.documentElement.classList.toggle("syncing", !!FB.preview);
  if (gated) {
    document.getElementById("view").innerHTML = viewGate();
    if (FB.ready || FB.error) hideSplash();          // 要登入或出錯 → 拿掉開啟畫面
    return;
  }
  hideSplash();
  const v = { today: viewToday, calendar: viewCalendar, memo: viewMemo, share: viewShare, settings: viewSettings }[ui.tab] || viewToday;
  document.getElementById("view").innerHTML = v();
  if (ui.tab === "today") { syncStrip(ui.stripJump !== false); ui.stripJump = false; }
  if (ui.tab === "calendar" && ui.calMode === "month") pcalAfter();
  if (ui.tab === "memo") { const ta = document.getElementById("memo-text"); if (ta) ta.style.height = Math.max(180, ta.scrollHeight + 2) + "px"; const st = document.getElementById("dstrip-memo"); if (st) st.scrollLeft = st.scrollWidth; }
  if (ui.fresh && ui.fresh.size) document.querySelectorAll("#view .row[data-id]").forEach(r => { if (ui.fresh.has(r.dataset.id)) r.classList.add("row-in"); });
  document.getElementById("tabs").innerHTML = TABS.map(([k, n, ic]) => `<button class="${ui.tab === k ? "on" : ""}" data-act="tab" data-tab="${k}"${ui.tab === k ? ' aria-current="page"' : ""}>${ic}${n}</button>`).join("");
}
function render() {
  renderMain();
  renderSheet();
}
/** 月曆畫好後：第一次打開、或按「今天」時，捲到這個月；展開的時間條捲到工作時間 */
function pcalAfter() {
  const key0 = scrollKey();
  if (ui.pcalJump || ui.scroll[key0] == null) {
    const m = document.querySelector(`.pmonth[data-month="${(ui.pcalJump || ui.sel).slice(0, 7)}"]`);
    if (m) { const y = m.getBoundingClientRect().top + window.scrollY - 110; window.scrollTo(0, Math.max(0, y)); ui.scroll[key0] = window.scrollY; }
    ui.pcalJump = null;
  }
  document.querySelectorAll(".pbs").forEach(b => { if (b.dataset.sx) return; const z = PC.zoom[ui.pzoom ?? 1]; const k2 = b.dataset.date, m0 = k2 === today() && nowMin() > S.settings.workStart ? nowMin() : S.settings.workStart; b.scrollLeft = Math.max(0, (m0 / 60 - 1) * z); b.dataset.sx = 1; });
}
/* ---------- 每個頁面記住滑到的位置，切回來不用重滑 ---------- */
try { history.scrollRestoration = "manual"; } catch (e) {}
ui.scroll = {};
const scrollKey = () => ui.tab + (ui.tab === "share" ? `:${ui.shareSub || "people"}:${ui.shareView || ""}` : "");
let scrollRAF = 0;
window.addEventListener("scroll", () => {
  if (scrollRAF) return;
  scrollRAF = requestAnimationFrame(() => { scrollRAF = 0; if (!ui.sheet && !ui.switching) ui.scroll[scrollKey()] = window.scrollY; });
}, { passive: true });
/** 換頁：先記住這頁的位置，換過去後回到那頁上次的位置 */
function goView(change, anim) {
  ui.scroll[scrollKey()] = window.scrollY;
  ui.switching = true;
  change();
  render();
  window.scrollTo(0, ui.scroll[scrollKey()] || 0);
  requestAnimationFrame(() => { window.scrollTo(0, ui.scroll[scrollKey()] || 0); ui.switching = false; });
  if (anim) animateView(anim);
}
/** 讓主畫面播放一次進場動畫 */
function animateView(cls) {
  const v = document.getElementById("view");
  v.classList.remove("enter-right", "enter-left", "fade-in", "anim-in");
  void v.offsetWidth;            // 重新觸發動畫
  v.classList.add(cls, "anim-in");
  clearTimeout(animateView.t);
  animateView.t = setTimeout(() => v.classList.remove(cls, "anim-in"), 1300);
}
const ANIMS = [["ios", "iOS 標準", "推入、滑上來"], ["spring", "彈性", "Q 彈有回彈"], ["fade", "柔和淡入", "輕輕浮現"], ["zoom", "縮放", "像打開 App"], ["flip", "立體翻頁", "3D 翻轉"], ["none", "不要動畫", "最快、最省電"]];
function applyAnim(a) {
  const v = ANIMS.some(x => x[0] === a) ? a : "ios";
  document.documentElement.dataset.anim = v;
  try { localStorage.setItem("planflow-anim", v); } catch (e) {}
}
function renderSheet() {
  const el = document.getElementById("sheet"), sh = ui.sheet;
  if (!sh) {
    // 關閉時：留一個複製品往下滑走，真正的內容立刻清掉（不影響接下來的動作）
    const old = el.querySelector(".sheet");
    if (old && !window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      const ghost = document.createElement("div");
      ghost.className = "sheet-ghost";
      ghost.innerHTML = el.innerHTML;
      ghost.style.setProperty("--from", (ui.dragY || 0) + "px"); ui.dragY = 0;
      ghost.querySelectorAll("[id]").forEach(n => n.removeAttribute("id"));
      ghost.querySelectorAll("[data-act]").forEach(n => n.removeAttribute("data-act"));
      document.body.appendChild(ghost);
      setTimeout(() => ghost.remove(), 560);
    }
    el.innerHTML = ""; el.dataset.kind = ""; fitSheet(); return;
  }
  const prevBody = el.querySelector(".sheetbody");
  const sameSheet = !!el.querySelector(".sheet");
  const keep = prevBody && el.dataset.kind === sh.type + ":" + (sh.step || "") ? prevBody.scrollTop : 0;
  el.dataset.kind = sh.type + ":" + (sh.step || "");
  if (sh.type === "move") { const t = task(sh.id); el.innerHTML = t ? sheetMove(t, sh.fromDue) : ""; }
  else if (sh.type === "bulk") el.innerHTML = sheetBulk(sh);
  else if (sh.type === "edit") el.innerHTML = sheetEditor(sh);
  else if (sh.type === "ai") el.innerHTML = sheetAI(sh);
  else if (sh.type === "due") el.innerHTML = sheetDue(sh);
  else if (sh.type === "work") el.innerHTML = sheetWork(sh);
  else if (sh.type === "actual") el.innerHTML = sheetActual(sh);
  else if (sh.type === "setup") el.innerHTML = sheetSetup(sh);
  else if (sh.type === "ot") el.innerHTML = sheetOT(sh);
  else if (sh.type === "person") el.innerHTML = sheetPerson(sh);
  else if (sh.type === "doneall") el.innerHTML = sheetDoneAll();
  else if (sh.type === "gmail") el.innerHTML = sheetGmail(sh);
  else if (sh.type === "morning") el.innerHTML = sheetMorning();
  else if (sh.type === "mvcp") el.innerHTML = sheetMvcp(sh);
  else if (sh.type === "wrapup") el.innerHTML = sheetWrapUp();
  else if (sh.type === "rate") el.innerHTML = sheetRate(sh);
  else if (sh.type === "help") el.innerHTML = sheetHelp(sh);
  if (sameSheet) { const sn = el.querySelector(".sheet"); if (sn) sn.style.animation = "none"; const sc = el.querySelector(".scrim"); if (sc) sc.style.animation = "none"; }
  if (keep) { const b = el.querySelector(".sheetbody"); if (b) b.scrollTop = keep; }
  fitSheet();
}
function openSheet(s) {
  const fresh = !ui.sheet;
  ui.sheet = s; renderSheet();
  if (fresh) { const f = document.querySelector("#sheet #ed-title") || document.querySelector("#sheet .sheet"); if (f) f.focus({ preventScroll: true }); }
}
function closeSheet() {
  if (ui.sheet && ui.sheet.abort) ui.sheet.abort();
  if (ui.sheet && ui.sheet.type === "due") ui.sheet.ids.forEach(id => { dueSnooze[id] = Date.now() + 15 * 60000; });
  ui.sheet = null; renderSheet();
  if (ui.morningPending) { ui.morningPending = false; setTimeout(maybeMorningPlan, 500); }
}
/** iPhone 鍵盤跳出來時：把編輯視窗剛好貼在「鍵盤上方看得到的區域」，背景不跟著捲 */
function fitSheet() {
  const sh = document.querySelector("#sheet .sheet");
  const wasOpen = document.documentElement.classList.contains("sheet-open");
  // 液態玻璃：後面的畫面以「目前看得到的那一塊」為中心縮小，捲到下面打開卡片也不會跳位置
  if (sh && !wasOpen) { const v = document.getElementById("view"); if (v) v.style.transformOrigin = `50% ${Math.round(window.scrollY)}px`; }
  document.documentElement.classList.toggle("sheet-open", !!sh);
  if (!sh || !window.visualViewport) return;
  const vv = window.visualViewport;
  const kbOpen = vv.height < window.innerHeight - 120;
  if (kbOpen) {
    sh.style.top = vv.offsetTop + "px";
    sh.style.bottom = "auto";
    sh.style.height = vv.height + "px";
    sh.style.maxHeight = vv.height + "px";
    sh.style.borderRadius = "0";
  } else {
    sh.style.top = ""; sh.style.bottom = ""; sh.style.height = ""; sh.style.maxHeight = ""; sh.style.borderRadius = "";
  }
}
/** 只捲動視窗裡面，讓正在輸入的格子停在可見範圍中間偏上 */
function keepFieldVisible(el) {
  const body = el.closest(".sheetbody");
  if (!body) return;
  const top = el.getBoundingClientRect().top - body.getBoundingClientRect().top;
  const target = body.scrollTop + top - Math.min(body.clientHeight / 3, 120);
  body.scrollTo({ top: Math.max(0, target), behavior: "smooth" });
}
if (window.visualViewport) {
  const onVV = () => {
    fitSheet();
    const a = document.activeElement;
    if (a && a.closest && a.closest("#sheet") && /INPUT|TEXTAREA|SELECT/.test(a.tagName)) keepFieldVisible(a);
  };
  window.visualViewport.addEventListener("resize", onVV);
  window.visualViewport.addEventListener("scroll", fitSheet);
}
document.addEventListener("focusin", e => {
  const el = e.target;
  if (el && el.closest && el.closest("#sheet") && /INPUT|TEXTAREA|SELECT/.test(el.tagName)) {
    setTimeout(() => { fitSheet(); keepFieldVisible(el); }, 250);
  }
});
document.addEventListener("focusout", () => setTimeout(fitSheet, 250));

function openBulk(ids, base, from) {
  const b = { type: "bulk", ids, base, from, sel: new Set(ids), plan: {} };
  recomputeBulk(b); openSheet(b);
}
function recomputeBulk(b) {
  const start = b.from ? addDays(b.base, 1) : b.base;
  b.plan = plan(b.ids.map(task).filter(Boolean), start);
}

let toastTimer;
function toast(msg, undo) {
  const el = document.getElementById("toast");
  el.innerHTML = `<div class="toast" role="status"><span>${esc(msg)}</span>${undo ? `<button data-act="undo">復原</button>` : ""}</div>`;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { el.innerHTML = ""; }, 4000);
}
function commit(msg, undoable) { save(); render(); if (msg) toast(msg, undoable); }
/** 打勾的動畫（畫面重畫之後再加上） */
function popCheck(id) {
  const b = document.querySelector(`#view .row[data-id="${id}"] .chk`);
  if (b) { b.classList.remove("pop"); void b.offsetWidth; b.classList.add("pop"); }
}
/** 新加入的工作：畫面重畫後淡入 */
function markFresh(ids) {
  ui.fresh = new Set(ids);
  setTimeout(() => { ui.fresh = null; }, 900);
}

/* ---------- Events ---------- */
document.addEventListener("click", e => {
  if (e.target.closest("a[href]")) return;          // 備註裡的連結：直接打開，不要進編輯
  const el = e.target.closest("[data-act]");
  if (!el) return;
  const act = el.dataset.act, id = el.dataset.id, t = id ? task(id) : null;
  if (ui.sheet && ui.sheet.type === "ai" && ui.sheet.step === "preview" && /^(ai-pick|ai-fix|dur-chip|chg-pick)/.test(act)) ui.sheet.touched = true;
  // 還在用手機裡的舊資料畫面時，只能看、不能改（避免改到一半被雲端的資料蓋掉）
  if (FB.preview && /^(memo-rec|memo-stop|clip-|share-(add|on|off|send|copy|unfollow)|bg-|push-on|notify-test|logout|brain-|habit-clear|sample-|gm-check)/.test(act)) { toast("正在同步最新資料，等一下下再改"); return; }
  switch (act) {
    case "tab": {
      const order = TABS.map(x => x[0]);
      const from = order.indexOf(ui.tab), to = order.indexOf(el.dataset.tab);
      if (from === to) {
        // 行程頁的方格模式：在最上面再點一次 → 換檢視（方格 → 分割 → 實際 → 週）
        if (ui.tab === "today" && window.scrollY < 20) { const i = TMODES.findIndex(v => v[0] === (ui.todayMode || "list")); ui.todayMode = TMODES[(i + 1) % TMODES.length][0]; renderMain(); animateView("fade-in"); break; }
        window.scrollTo({ top: 0, behavior: "smooth" }); break;      // 再點一次同一個分頁 → 回到最上面（像 iPhone）
      }
      goView(() => { ui.tab = el.dataset.tab; }, to > from ? "enter-right" : "enter-left");
      break;
    }
    case "toggle": {
      const row = el.closest("#view .list > .row[data-id]");
      if (t && !t.done && row && !row.closest(".donefold") && !matchMedia("(prefers-reduced-motion: reduce)").matches && document.documentElement.dataset.anim !== "none") {
        // 打勾 → 先在原地打勾，再慢慢收進下面的「已完成」資料夾
        toggle(t); save();
        row.classList.add("done"); const b = row.querySelector(".chk"); if (b) { b.classList.remove("pop"); void b.offsetWidth; b.classList.add("pop"); }
        setTimeout(() => { row.style.height = row.offsetHeight + "px"; void row.offsetHeight; row.classList.add("to-folder"); }, 420);
        setTimeout(() => { render(); const f = document.querySelector("#view .donefold .cnt"); if (f) { f.classList.remove("bump"); void f.offsetWidth; f.classList.add("bump"); } afterToggle(t); checkDayDone(t); }, 900);
        break;
      }
      toggle(t); commit(); if (t && t.done) popCheck(t.id); afterToggle(t); checkDayDone(t); break;
    }
    case "wk-from-ed": { const f = document.getElementById("ed-title"); openWork({ name: f ? f.value.trim() : "" }); break; }
    case "wk-auto": { const w = ui.sheet; wkRead(w); w.auto = el.dataset.v === "1"; renderSheet(); break; }
    case "wk-next": {
      const w = ui.sheet; wkRead(w);
      if (!w.name) { const f = document.getElementById("wk-name"); f.placeholder = "請先輸入工作名稱"; f.focus(); break; }
      if (!w.deadline) { toast("請選截止日"); break; }
      if (w.auto) { w.est = estimateWork(w.name, w.cat, w.deadline); w.total = w.est.m; w.step = "estimate"; }
      else { w.est = null; wkCompute(w); }
      renderSheet(); break;
    }
    case "wk-plan": { const w = ui.sheet; wkRead(w); wkCompute(w); renderSheet(); break; }
    case "wk-back": { const w = ui.sheet; w.step = w.mode === "new" && w.auto && w.est && ui.sheet.step === "preview" ? "estimate" : "input"; renderSheet(); break; }
    case "wk-recalc": { wkCompute(ui.sheet); renderSheet(); toast("已重新計算"); break; }
    case "wk-redl": { const w = ui.sheet, v = document.getElementById("wk-dl2").value; if (v) w.deadline = v; wkCompute(w); renderSheet(); break; }
    case "wk-del": { const w = ui.sheet; w.plan.chunks.splice(+el.dataset.i, 1); renderSheet(); break; }
    case "wk-apply": wkApply(ui.sheet); break;
    case "wk-more": { const p = workProgress(t.wid); openWork({ mode: "extra", wid: t.wid, name: p.name, deadline: p.deadline || today(), total: 60 }); break; }
    case "wk-replan": { const p = workProgress(t.wid); openWork({ mode: "replan", wid: t.wid, name: p.name, deadline: p.deadline || today() }); break; }
    case "act-save": {
      const a = ui.sheet, p = workProgress(a.wid);
      const m = readDur(document.querySelector('#sheet [data-durgroup="act"]'), 12000);
      const ty = (p.list[0] && p.list[0].wtype) || "其他";
      S.settings.estLog = [...(S.settings.estLog || []).filter(x => x.w !== a.wid), { n: ty, m, w: a.wid, d: today() }].slice(-60);
      closeSheet(); commit(`已記錄：「${p.name}」實際花了 ${dur(m)}`); break;
    }
    case "est-del": { const i = +el.dataset.i; S.settings.estTypes = estTypes().filter((_, j) => j !== i).map(x => ({ ...x })); commit(); break; }
    case "est-add": {
      const n = document.getElementById("est-new-n").value.trim(), h = Math.max(0.5, Math.min(200, +document.getElementById("est-new-h").value || 0));
      if (!n) { document.getElementById("est-new-n").focus(); break; }
      if (estTypes().some(x => x.n === n)) { toast("已經有這個類型了"); break; }
      const list = estTypes().map(x => ({ ...x })), other = list.findIndex(x => x.n === "其他");
      list.splice(other < 0 ? list.length : other, 0, { n, h, kw: n.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") });
      S.settings.estTypes = list; commit(`已新增「${n}」預設 ${hrsTxt(h * 60)} 小時`); break;
    }
    case "edit": openSheet({ type: "edit", id }); break;
    case "new": openSheet({ type: "edit", id: null, date: el.dataset.date || today() }); break;
    case "move": openSheet({ type: "move", id }); break;
    case "close": closeSheet(); break;
    case "share-on": {
      const c = { ...shareCfg() };
      if (!c.id) c.id = randId();
      Object.assign(c, { on: true, mode: c.mode || "link", detail: c.detail || "title", range: c.range || 14, name: c.name || (FB.user && FB.user.displayName) || "我" });
      S.settings.share = c; commit("已開始分享，把連結傳給朋友吧"); publishShare(true); break;
    }
    case "share-off": {
      const c = { ...shareCfg() }; const id = c.id;
      c.on = false; c.id = ""; S.settings.share = c;
      if (id) shareRef(id).delete().catch(() => {});
      commit("已停止分享"); break;
    }
    case "share-copy": {
      const u = shareURL(shareCfg().id);
      (navigator.clipboard ? navigator.clipboard.writeText(u) : Promise.reject()).then(() => toast("已複製連結")).catch(() => { const f = document.getElementById("share-url"); if (f) { f.select(); document.execCommand && document.execCommand("copy"); } toast("已選取連結，按複製就好"); });
      break;
    }
    case "share-send": {
      const u = shareURL(shareCfg().id);
      if (navigator.share) navigator.share({ title: "我的行程", text: `${shareCfg().name || ""} 的排程本行程`, url: u }).catch(() => {});
      else { (navigator.clipboard ? navigator.clipboard.writeText(u) : Promise.reject()).then(() => toast("已複製連結，貼給朋友就好")).catch(() => toast(u)); }
      break;
    }
    case "share-add": {
      const id2 = parseShareId((document.getElementById("share-add") || {}).value);
      if (!id2) { toast("看不懂這個連結，請貼完整的分享連結"); break; }
      if (followShare(id2)) { ui.shareView = id2; renderMain(); animateView("enter-right"); }
      break;
    }
    case "share-view": goView(() => { ui.shareView = el.dataset.sid; ui.friendDay = ui.friendDay || today(); }, "enter-right"); break;
    case "share-back": goView(() => { ui.shareView = null; }, "enter-left"); break;
    case "share-unfollow": {
      const sid = el.dataset.sid;
      S.settings.follows = (S.settings.follows || []).filter(x => x.id !== sid);
      ui.shareView = null; unwatchFriend(sid); closeSheet();
      commit("已移除"); break;
    }
    case "friend-day": ui.friendDay = el.dataset.date; renderMain(); break;
    case "all-day": ui.allDay = el.dataset.date; renderMain(); break;
    case "done-fold": {
      ui.doneOpen = ui.doneOpen === el.dataset.date ? null : el.dataset.date; renderMain();
      if (ui.doneOpen) requestAnimationFrame(() => { const f = document.querySelector("#view .donefold.open"); if (f) { f.classList.add("opening"); const r = f.getBoundingClientRect(); if (r.bottom > innerHeight - 90) window.scrollBy({ top: Math.min(r.bottom - innerHeight + 110, r.top - 80), behavior: "smooth" }); } });
      break;
    }
    case "done-all": openSheet({ type: "doneall" }); break;
    case "gm-check": checkGmail(true); break;
    case "gm-off": disconnectGmail(); break;
    case "gm-kw-add": {
      const inp = document.getElementById("gm-kw"), v = (inp && inp.value || "").trim();
      if (!v) { if (inp) inp.focus(); break; }
      const list = gmKws(); if (list.some(k => k.toLowerCase() === v.toLowerCase())) { toast("已經有這個關鍵字"); break; }
      S.settings.gmailKw = [...list, v].slice(0, 30); commit(`已加入關鍵字「${v}」`);
      requestAnimationFrame(() => { const i = document.getElementById("gm-kw"); if (i) i.focus(); }); break;
    }
    case "gm-kw-del": S.settings.gmailKw = gmKws().filter(k => k !== el.dataset.kw); commit(`已移除關鍵字「${el.dataset.kw}」`); break;
    case "gm-pick": { const o = ui.sheet; if (o && o.type === "gmail") { gmReadTitles(o); o.pick[el.dataset.mid] = !o.pick[el.dataset.mid]; renderSheet(); } break; }
    case "gm-when": { const o = ui.sheet; if (o && o.type === "gmail") { gmReadTitles(o); o.when = el.dataset.w; renderSheet(); } break; }
    case "gm-add": if (ui.sheet && ui.sheet.type === "gmail") gmailAdd(ui.sheet); break;
    case "gm-ai": if (ui.sheet && ui.sheet.type === "gmail") gmailToAI(ui.sheet); break;
    case "gm-skip": if (ui.sheet && ui.sheet.type === "gmail") { gmMarkSeen(ui.sheet.items.map(x => x.id)); closeSheet(); commit("好，這幾封不會再問"); } break;
    case "share-sub": goView(() => { ui.shareSub = el.dataset.sub; }, el.dataset.sub === "people" ? "enter-right" : "enter-left"); break;
    case "share-toggle": {
      const h = new Set(S.settings.shareHide || []), pid = el.dataset.pid;
      h.has(pid) ? h.delete(pid) : h.add(pid); S.settings.shareHide = [...h]; commit(); break;
    }
    case "person": openSheet({ type: "person", pid: el.dataset.pid }); break;
    case "ps-av-clear": if (ui.sheet && ui.sheet.type === "person") { ui.sheet.avatar = ""; renderSheet(); } break;
    case "person-save": {
      const pid = el.dataset.pid, av = ui.sheet ? ui.sheet.avatar : undefined;
      if (av !== undefined) {
        if (pid === "me") { S.settings.myAvatar = av; publishShare(true); }
        else S.settings.follows = (S.settings.follows || []).map(x => x.id === pid ? { ...x, avatar: av } : x);
      }
      const picked = (document.querySelector('#sheet input[name="ps-color"]:checked') || {}).value;
      const custom = (document.getElementById("ps-custom") || {}).value;
      const color = ui.sheet && ui.sheet.custom ? custom : (picked || custom);
      if (pid === "me") S.settings.myColor = color;
      else {
        const list = (S.settings.follows || []).map(x => ({ ...x }));
        const f = list.find(x => x.id === pid);
        if (f) { f.color = color; const nm = (document.getElementById("ps-name") || {}).value; f.alias = (nm || "").trim().slice(0, 16); }
        S.settings.follows = list;
      }
      closeSheet(); commit("已儲存"); break;
    }
    case "friend-meet": {
      const s0 = +el.dataset.s, e0 = +el.dataset.e;
      openSheet({ type: "edit", id: null, date: el.dataset.date, preset: { title: `跟${el.dataset.name}約`, start: s0, min: e0 - s0, locked: true, cat: eventCatId() } });
      break;
    }
    case "cancel": cancelTask(t); break;
    case "memo-day": { const k = el.dataset.date; if (memoUI.rec) { toast("先停止錄音"); break; } ui.memoDate = k === today() ? null : k; renderMain(); animateView("fade-in"); window.scrollTo(0, 0); break; }
    case "memo-rec": startRec(); break;
    case "memo-stop": stopRec(); break;
    case "memo-todo": {
      const ta = document.getElementById("memo-text"); if (!ta) break;
      const selTxt = ta.value.slice(ta.selectionStart, ta.selectionEnd).trim();
      const text = selTxt || ta.value.trim();
      if (!text) { toast("備忘錄是空的"); break; }
      openSheet({ type: "ai", step: "input", text }); toast(selTxt ? "用選起來的文字排程" : "用整篇備忘錄排程，可以先刪掉不要的"); break;
    }
    case "clip-play": playClip(ui.memoDate || today(), el.dataset.cid); break;
    case "clip-del": {
      const k = ui.memoDate || today(), m = memoOf(k), c = m.clips.find(x => x.id === el.dataset.cid); if (!c) break;
      if (!el.dataset.sure) { el.dataset.sure = "1"; el.textContent = "確定刪除？"; setTimeout(() => { if (el.isConnected) { delete el.dataset.sure; el.textContent = "刪除"; } }, 3000); break; }
      if (memoUI.rec && memoUI.rec.id === c.id) { toast("還在錄音，先按停止"); break; }
      m.clips = m.clips.filter(x => x.id !== c.id);
      for (const sg of clipSegList(c)) for (let i = 0; i < sg.n; i++) audioRef(`${sg.key}_${i}`).delete().catch(() => {});
      saveMemo(k, true); renderMain(); toast("已刪除錄音"); break;
    }
    case "ot-accept": {
      const k = el.dataset.date, o = overloadInfo(k); if (!o) break;
      snapshot();
      o.list.forEach((x, i) => { x.start = o.place[i]; x.locked = true; markOT(x, x.min); });
      commit(`加班 ${dur(o.need)}，排到 ${hmx(o.until)}`, true); break;
    }
    case "ot-spread": { const o = overloadInfo(el.dataset.date); if (o) openBulk(o.list.map(x => x.id), maxKey(el.dataset.date, today()), true); break; }
    case "swipe-act": { const k = el.dataset.a; swClose(false); runSwipe(k, t); break; }
    case "ed-ot": { const sh = ui.sheet; ui.sheet = null; openSheet({ type: "ot", id: sh.id }); break; }
    case "ed-cancel": { closeSheet(); if (t) { if (t.cancelled) { toggle(t); commit("已恢復"); } else cancelTask(t); } break; }
    case "ot-add": {
      if (!t) break;
      const m = el.dataset.custom ? readDur(document.querySelector('#sheet [data-durgroup="ot"]'), 8 * 60) : +el.dataset.min;
      if (!m) break;
      snapshot(); growTask(t, m, true);
      const endAt = t.start != null ? t.start + t.min : null; closeSheet(); commit(`「${t.title}」加班 ${dur(m)}${endAt != null ? `，到 ${hmx(endAt)}` : ""}`, true); break;
    }
    case "strip-day": {
      const k = el.dataset.date, back = k < (ui.todaySel || today());
      ui.todaySel = k; ui.stripJump = k === today();
      if (ui.sheet && ui.sheet.type === "help") closeSheet();
      renderMain(); animateView(back ? "enter-left" : "enter-right"); break;
    }
    case "help": { const back = ui.sheet; if (back) { const f = document.getElementById("ai-text"); if (f) back.text = f.value; } ui.sheet = null; openSheet({ type: "help", back }); break; }
    case "help-back": { const b = ui.sheet && ui.sheet.back; if (b) { ui.sheet = b; renderSheet(); } else closeSheet(); break; }
    case "setup-open": openSheet({ type: "setup" }); break;
    case "setup-skip": S.settings.setupDone = true; closeSheet(); commit(); break;
    case "setup-save": {
      readSetupForm(); S.settings.setupDone = true;
      arrangeTimes(today(), "fill");
      closeSheet(); commit("作息已更新"); break;
    }
    case "setup-add": {
      const sh = ui.sheet;
      readSetupForm();
      const wd = [...document.querySelectorAll('#sheet input[name="su-wd"]:checked')].map(i => +i.value);
      const cs = document.getElementById("su-cs").value, ce = document.getElementById("su-ce").value, ct = document.getElementById("su-ct").value.trim();
      sh.wd = wd; sh.cs = cs; sh.ce = ce; sh.ct = ct;
      if (!wd.length || !cs || !ce || !ct) { toast("星期、開始、結束、名稱都要填"); renderSheet(); break; }
      if (toMin(ce) <= toMin(cs)) { toast("結束時間要比開始晚"); renderSheet(); break; }
      let anchor = today(); for (let i = 0; i < 7 && !wd.includes(parse(anchor).getDay()); i++) anchor = addDays(anchor, 1);
      S.series.push({ id: uid(), created: Date.now(), genUntil: null, title: ct, notes: "", pri: 1, min: toMin(ce) - toMin(cs), cat: eventCatId(),
        start: toMin(cs), dlOffset: null, anchor, freq: "weekly", interval: 1, weekdays: wd, until: null, skipMissed: true });
      refreshRecurring();
      sh.wd = []; sh.cs = ""; sh.ce = ""; sh.ct = "";
      save(); renderMain(); renderSheet(); toast(`已加入「${ct}」`); break;
    }
    case "setup-del": {
      const sid = id;
      S.series = S.series.filter(x => x.id !== sid);
      S.tasks = S.tasks.filter(x => !(x.series === sid && !x.done && x.date >= today()));
      save(); renderMain(); renderSheet(); break;
    }
    case "review-skip": S.settings.reviewSkip = today(); commit(); break;
    case "review-open": S.settings.reviewSkip = ""; commit(); break;
    case "overdue-all-done": {
      snapshot(); const list = S.tasks.filter(isOverdue);
      list.forEach(x => { x.done = true; x.doneOn = x.date; });
      commit(`已把 ${list.length} 項標記為完成`, true); break;
    }
    case "miss-later": {
      if (!t) break;
      snapshot();
      if (t.start != null) habitLearnTask(t, t.start + t.min / 2, -0.7);
      const r = plan([t], today()); reschedule(t, r[t.id]); t.start = null; t.locked = false; arrangeTimes(t.date, "fill");
      commit(`「${t.title}」排到 ${rel(t.date)}${t.start != null ? " " + hm(t.start) : ""}`, true); break;
    }
    case "chg-pick": { const a = ui.sheet; a.csel.has(id) ? a.csel.delete(id) : a.csel.add(id); renderSheet(); break; }
    case "ai-starter": {
      const f = document.getElementById("ai-text"), v = STARTERS[+el.dataset.i][1];
      if (!f) break;
      const pre = f.value && !/\n$/.test(f.value) ? f.value + "\n" : f.value;
      f.value = pre + v.replace("|", "");
      f.focus(); const pos = pre.length + v.indexOf("|"); try { f.setSelectionRange(pos, pos); } catch (e2) {}
      break;
    }
    case "note-x": ui.dismissNote = true; render(); break;
    case "smart-overdue": openBulk(sortTasks(S.tasks.filter(isOverdue)).map(x => x.id), today(), false); break;
    case "all-today": { snapshot(); const list = S.tasks.filter(isOverdue); list.forEach(x => reschedule(x, today())); commit(`已把 ${list.length} 項移到今天`, true); break; }
    case "spread": { const k = el.dataset.date; openBulk(overflow(onDay(k)).map(x => x.id), maxKey(k, today()), true); break; }
    case "move-to": snapshot(); reschedule(t, el.dataset.date); closeSheet(); commit(`已移到 ${rel(el.dataset.date)}`, true); break;
    case "move-custom": {
      const k = document.getElementById("mv-date").value; if (!k) break;
      const tv = document.getElementById("mv-time").value;
      snapshot();
      if (k !== t.date) reschedule(t, k);
      if (tv) { t.start = toMin(tv); t.locked = true; habitLearnTask(t, t.start + t.min / 2, 1.5); }
      else if (k === t.date) { t.start = null; t.locked = false; arrangeTimes(k, "fill"); }
      closeSheet(); commit(`已移到 ${rel(k)}${tv ? " " + tv : ""}`, true); break;
    }
    case "bulk-pick": { const b = ui.sheet; b.sel.has(id) ? b.sel.delete(id) : b.sel.add(id); renderSheet(); break; }
    case "bulk-apply": {
      const b = ui.sheet; snapshot();
      b.ids.forEach(i => { if (b.sel.has(i)) reschedule(task(i), b.plan[i]); });
      const n = b.sel.size; closeSheet(); commit(`已重新規劃 ${n} 項工作`, true); break;
    }
    case "ed-suggest": {
      const min = readDur(document.querySelector('[data-durgroup="ed"]'));
      const dl = document.getElementById("ed-hasdl").checked ? document.getElementById("ed-dl").value : null;
      const excl = new Set(ui.sheet.id ? [ui.sheet.id] : []);
      const d = bestDay(min, dl, loadMap(excl), today());
      document.getElementById("ed-date").value = d;
      document.getElementById("ed-hint").textContent = `建議排在 ${rel(d)}（${md(d)}）`;
      break;
    }
    case "ed-force": ui.sheet.force = true; document.querySelector('[data-act="ed-save"]').click(); break;
    case "ed-fix": {
      const sh = ui.sheet;
      const date = document.getElementById("ed-date").value || today();
      const min = readDur(document.querySelector('[data-durgroup="ed"]'));
      const slot = nearestFree(date, min, new Set([sh.id || "__new"]));
      if (!slot) { toast("之後兩週都找不到空檔，請自己改時間"); break; }
      document.getElementById("ed-date").value = slot.date;
      document.getElementById("ed-time").value = hm(slot.start);
      const box = document.getElementById("ed-conflict");
      box.innerHTML = `<div class="t" style="color:var(--ok)">${I.check}已改到 ${rel(slot.date)} ${hm(slot.start)}，確認後按「儲存」</div>`;
      break;
    }
    case "ed-save": {
      const title = document.getElementById("ed-title").value.trim();
      if (!title) { const f = document.getElementById("ed-title"); f.placeholder = "請先輸入工作名稱"; f.focus(); break; }
      const sh = ui.sheet;
      const date = document.getElementById("ed-date").value || today();
      const vals = {
        title, notes: document.getElementById("ed-notes").value, cat: document.getElementById("ed-cat").value === "__new" ? "" : document.getElementById("ed-cat").value,
        pri: +(document.querySelector('input[name="ed-pri"]:checked') || { value: 1 }).value,
        min: readDur(document.querySelector('[data-durgroup="ed"]')),
        deadline: document.getElementById("ed-hasdl").checked ? (document.getElementById("ed-dl").value || null) : null,
        endDate: document.getElementById("ed-multi").checked ? (document.getElementById("ed-end").value || null) : null,
        dday: document.getElementById("ed-dday").checked
      };
      if (vals.endDate && vals.endDate <= date) vals.endDate = null;
      const fixed = document.getElementById("ed-fixed").checked || !!(cat(vals.cat) && cat(vals.cat).event);
      const fixedAt = toMin(document.getElementById("ed-time").value);
      const repPreset = document.getElementById("ed-rep").value;
      if (fixed && !(cat(vals.cat) && cat(vals.cat).event) && fixedAt != null) {
        const old = sh.id ? task(sh.id) : null;
        if (!old || old.start !== fixedAt || !old.locked) habitAdd(habitKey(vals), fixedAt + vals.min / 2, 1.5);
      }
      { const old = sh.id ? task(sh.id) : null;
        if (!(old && old.wid)) brainLearn(title, vals.cat, vals.min, !!old && (old.cat !== vals.cat || old.min !== vals.min || old.pri !== vals.pri), old && old.pri !== vals.pri ? vals.pri : null); }
      // 指定了時間 → 先檢查有沒有撞到其他行程
      if (fixed && !sh.force) {
        const probe = { id: sh.id || "__new", date, start: fixedAt, min: vals.min, done: false };
        const cf = conflictsFor(probe);
        if (cf.length) {
          const box = document.getElementById("ed-conflict");
          box.innerHTML = `<div class="t">${I.alert}${esc(conflictText(cf))}</div>
            <div class="btnrow"><button class="btn primary" data-act="ed-fix">改到最近有空的時間</button><button class="btn" data-act="ed-force">仍要儲存</button></div>`;
          box.hidden = false;
          box.scrollIntoView({ block: "nearest" });
          const body = box.closest(".sheetbody"); if (body) body.scrollTo({ top: 0, behavior: "smooth" });
          break;
        }
      }
      const applySeries = (sx, anchor) => {
        Object.assign(sx, { title: vals.title, notes: vals.notes, pri: vals.pri, min: vals.min, cat: vals.cat,
          start: fixed ? fixedAt : null, dlOffset: vals.deadline ? Math.max(0, diff(anchor, vals.deadline)) : null, anchor });
        const clamp = (x, lo, hi) => Math.min(hi, Math.max(lo, Math.round(+x || lo)));
        if (repPreset === "daily") Object.assign(sx, { freq: "daily", interval: 1, weekdays: [] });
        else if (repPreset === "ndays") Object.assign(sx, { freq: "daily", interval: clamp(document.getElementById("ed-nint").value, 2, 365), weekdays: [] });
        else if (repPreset === "weekdays") Object.assign(sx, { freq: "weekly", interval: 1, weekdays: [1, 2, 3, 4, 5] });
        else if (repPreset === "weekly") {
          const days = [...document.querySelectorAll('input[name="ed-wd"]:checked')].map(i => +i.value);
          Object.assign(sx, { freq: "weekly", interval: clamp(document.getElementById("ed-wint").value, 1, 12), weekdays: days.length ? days : [parse(anchor).getDay()] });
        } else if (repPreset === "monthly") Object.assign(sx, { freq: "monthly", interval: 1, weekdays: [] });
        sx.until = document.getElementById("ed-hasuntil").checked ? (document.getElementById("ed-until").value || null) : null;
        sx.skipMissed = document.getElementById("ed-skip").checked;
      };
      if (!sh.id && repPreset !== "none") {
        const sx = { id: uid(), created: Date.now(), genUntil: null };
        applySeries(sx, date);
        S.series.push(sx);
        refreshRecurring();
        closeSheet(); commit(`已新增重複工作：${seriesSummary(sx)}`); break;
      }
      if (sh.id) {
        const x = task(sh.id);
        const minChanged = x.min !== vals.min;
        Object.assign(x, vals);
        if (fixed) { x.locked = true; x.start = fixedAt; }
        else { if (x.locked || minChanged) x.start = null; x.locked = false; }
        reschedule(x, date);
        const ser = x.series ? seriesOf(x.series) : null;
        if (repPreset === "none") { if (ser) stopSeries(ser, x.id); else { x.series = null; x.occ = null; x.detached = false; } }
        else {
          let sx = ser;
          if (!sx) { sx = { id: uid(), created: Date.now(), genUntil: null }; S.series.push(sx); }
          applySeries(sx, x.date);
          x.series = sx.id; x.occ = x.date; x.detached = false;
          regenerateSeries(sx, x.id);
        }
      } else {
        { const nid = uid(); S.tasks.push({ id: nid, ...vals, date, done: false, doneOn: null, resched: 0, created: Date.now(), start: fixed ? fixedAt : null, locked: fixed }); markFresh([nid]); }
      }
      closeSheet(); commit(sh.id ? "已儲存" : `已新增到 ${rel(date)}`); break;
    }
    case "ed-del": ui.sheet.confirmDel = true; renderSheet(); break;
    case "ed-del-series": {
      snapshot();
      const x = task(ui.sheet.id), sx = x && x.series ? seriesOf(x.series) : null;
      if (sx) stopSeries(sx, x.id);
      S.tasks = S.tasks.filter(y => y.id !== ui.sheet.id);
      closeSheet(); commit("已停止重複並刪除"); break;
    }
    case "ed-del-yes": snapshot(); S.tasks = S.tasks.filter(x => x.id !== ui.sheet.id); closeSheet(); commit("已刪除", true); break;
    case "cal-mode": ui.calMode = el.dataset.mode; ui.anchor = ui.sel; if (ui.calMode === "month") ui.pcalJump = ui.sel; render(); animateView("fade-in"); break;
    case "cal-prev": case "cal-next": {
      const dir = act === "cal-next" ? 1 : -1;
      if (ui.calMode === "month") { const a = parse(ui.anchor); ui.anchor = key(new Date(a.getFullYear(), a.getMonth() + dir, 1)); }
      else { ui.anchor = addDays(ui.anchor, 7 * dir); ui.sel = addDays(ui.sel, 7 * dir); }
      render(); break;
    }
    case "cal-today": ui.anchor = today(); ui.sel = today(); render(); break;
    case "pcal-today": ui.anchor = today(); ui.sel = today(); ui.pbarOpen = true; ui.pcalJump = today(); renderMain(); break;
    case "pcal-day": {
      const k = el.dataset.date;
      ui.pbarOpen = ui.sel === k ? !(ui.pbarOpen !== false) : true; ui.sel = k;
      const y0 = el.getBoundingClientRect().top;
      renderMain();
      const c2 = document.querySelector(`.pd[data-date="${k}"]`); if (c2) window.scrollBy(0, c2.getBoundingClientRect().top - y0);
      const bar = document.querySelector(".pbar"); if (bar) { bar.classList.add("pbar-in"); const r = bar.getBoundingClientRect(); if (r.bottom > innerHeight - 80) window.scrollBy({ top: Math.min(r.bottom - innerHeight + 100, r.top - 120), behavior: "smooth" }); }
      break;
    }
    case "pcal-open": ui.todaySel = el.dataset.date; ui.stripJump = true; goView(() => { ui.tab = "today"; }, "enter-right"); break;
    case "pzoom": { ui.pzoom = Math.max(0, Math.min(PC.zoom.length - 1, (ui.pzoom ?? 1) + +el.dataset.d)); const sx = (document.querySelector(".pbs") || {}).scrollLeft || 0, old = PC.zoom[(ui.pzoom ?? 1) - +el.dataset.d] || 72; renderMain(); const b = document.querySelector(".pbs"); if (b) b.scrollLeft = sx / old * PC.zoom[ui.pzoom]; break; }
    case "mvcp-go": if (ui.sheet && ui.sheet.type === "mvcp") mvcpGo(ui.sheet, el.dataset.m); break;
    case "grid-act": ui.gridActual = el.dataset.v === "1"; renderMain(); break;
    case "g-menu": ui.gMenu = !ui.gMenu; renderMain(); break;
    case "g-view": ui.gridView = el.dataset.v; ui.gMenu = false; renderMain(); animateView("fade-in"); break;
    case "g-dense": ui.gridDense = !ui.gridDense; ui.gMenu = false; renderMain(); break;
    case "g-fold": ui.gridFold = !ui.gridFold; ui.gMenu = false; renderMain(); break;
    case "g-plus": { document.querySelectorAll(".gplus").forEach(x => x.remove()); newAt(el.dataset.date, +el.dataset.m, 30); break; }
    case "g-pick": { ui.gMenu = false; document.querySelectorAll(".gmenu").forEach(m => m.remove()); const i = document.getElementById("g-date"); if (i) { try { i.showPicker(); } catch (e2) { i.focus(); i.click(); } } break; }
    case "g-check": { if (!t) break; toggle(t); commit(); try { navigator.vibrate && navigator.vibrate(10); } catch (e2) {} afterToggle(t); checkDayDone(t); break; }
    case "g-rate": openSheet({ type: "rate", id }); break;
    case "g-rate-set": { const t2 = task(el.dataset.id); if (t2) { t2.rate = +el.dataset.v; closeSheet(); commit(`記下來了 ${RATE[t2.rate - 1]}`); } break; }
    case "g-week": { ui.todaySel = addDays(ui.todaySel || today(), +el.dataset.d); renderMain(); animateView(+el.dataset.d > 0 ? "enter-right" : "enter-left"); break; }
    case "wt-size": ui.wtSize = el.dataset.v; renderMain(); break;
    case "wt-pick": { const sl = ui.wtSel || (ui.wtSel = new Set()); sl.has(id) ? sl.delete(id) : sl.add(id); renderMain(); break; }
    case "wt-move": { const sl = ui.wtSel; if (!sl || !sl.size) break; snapshot(); let n = 0; for (const x of S.tasks) if (sl.has(x.id)) { x.date = addDays(x.date, 7); x.start = null; x.locked = false; n++; } ui.wtSel = new Set(); commit(`已把 ${n} 件移到下週`, true); break; }
    case "wt-del": { const sl = ui.wtSel; if (!sl || !sl.size) break; snapshot(); const n = sl.size; S.tasks = S.tasks.filter(x => !sl.has(x.id)); ui.wtSel = new Set(); commit(`已刪除 ${n} 件`, true); break; }
    case "set-mark": S.settings.gridMark = el.dataset.m; commit("已換打勾記號"); break;
    case "wrap-open": openSheet({ type: "wrapup" }); break;
    case "wrap-pick": { const sl = ui.sheet && ui.sheet.sel; if (sl) { sl.has(el.dataset.id) ? sl.delete(el.dataset.id) : sl.add(el.dataset.id); renderSheet(); } break; }
    case "wrap-go": if (ui.sheet && ui.sheet.type === "wrapup") wrapGo(); break;
    case "focus-start": { const t2 = task(el.dataset.id); if (t2) { closeSheet(); focusStart(t2, +el.dataset.m); toast(`開始專注 ${el.dataset.m} 分鐘`); } break; }
    case "focus-pause": if (FOC.id) { if (FOC.paused != null) { FOC.end = Date.now() + FOC.paused; FOC.pausedMs = (FOC.pausedMs || 0) + (Date.now() - FOC.pausedAt); FOC.paused = null; } else { FOC.paused = FOC.end - Date.now(); FOC.pausedAt = Date.now(); } focusRender(); } break;
    case "focus-stop": focusStop(false); toast("已結束專注，時間記下來了"); break;
    case "cal-day": ui.sel = el.dataset.date; render(); break;
    case "stat-range": ui.range = +el.dataset.n; render(); animateView("fade-in"); break;
    case "today-mode": ui.todayMode = el.dataset.mode; ui.gMenu = false; render(); animateView("fade-in"); break;
    case "g-layout": ui.gridLayout = el.dataset.v || ""; ui.todayMode = "grid"; ui.gMenu = false; renderMain(); animateView("fade-in"); break;
    case "calday-mode": ui.calDayMode = el.dataset.mode; render(); animateView("fade-in"); break;
    case "replan": snapshot(); arrangeTimes(el.dataset.date, "all"); commit("已重新安排時段", true); break;
    case "spread-untimed": {
      const k = el.dataset.date;
      openBulk(S.tasks.filter(x => x.date === k && !x.done && x.start == null).map(x => x.id), maxKey(k, today()), true); break;
    }
    case "gap": S.settings.gap = Math.min(30, Math.max(0, S.settings.gap + +el.dataset.d)); commit(); break;
    case "cap-from-hours": S.settings.cap = Math.max(30, Math.floor(availMin() / 30) * 30); commit(`每日可用時間設為 ${dur(S.settings.cap)}`); break;
    case "cap": S.settings.cap = Math.min(720, Math.max(30, S.settings.cap + +el.dataset.d)); commit(); break;
    case "cat-add": {
      const name = document.getElementById("cat-name").value.trim(); if (!name) { document.getElementById("cat-name").focus(); break; }
      const color = (document.querySelector('input[name="catc"]:checked') || { value: PALETTE[0] }).value;
      const ev = document.getElementById("cat-event").checked;
      S.cats.push(ev ? { id: uid(), name, color, event: true } : { id: uid(), name, color }); commit(`已新增分類「${name}」`); break;
    }
    case "cat-event": {
      const c = cat(id); if (!c) break;
      if (c.event) delete c.event; else c.event = true;
      commit(c.event ? `「${c.name}」改成固定事件` : `「${c.name}」改成一般分類`); break;
    }
    case "cat-del": { const c = cat(id); S.tasks.forEach(x => { if (x.cat === id) x.cat = ""; }); S.cats = S.cats.filter(x => x.id !== id); commit(`已刪除分類「${c ? c.name : ""}」`); break; }
    case "sample-clear": snapshot(); S.tasks = []; S.series = []; S.sample = false; commit("已清除範例工作", true); break;
    case "sample-reset": snapshot(); { const fresh = seed(); S.tasks = fresh.tasks; S.series = []; S.cats = fresh.cats; S.sample = true; ui.dismissNote = false; } commit("已重新載入範例", true); break;
    case "clean-done": { snapshot(); const cut = addDays(today(), -30); const before = S.tasks.length; S.tasks = S.tasks.filter(x => !(x.done && x.doneOn && x.doneOn < cut)); commit(`已清除 ${before - S.tasks.length} 項`, before !== S.tasks.length); break; }
    case "due-done": { snapshot(); toggle(t); const d = ui.sheet; d.ids = d.ids.filter(x => x !== id); commit("做得好！已標記完成", true); if (!d.ids.length) closeSheet(); else renderSheet(); afterToggle(t); break; }
    case "due-auto": {
      if (t && t.wid) {
        // 拆段的工作：只把剩下的時數排進截止日前的空檔（先預覽）
        const d = ui.sheet; d.ids = d.ids.filter(x => x !== id); d.ids.forEach(x => { dueSnooze[x] = Date.now() + 2 * 60000; });
        const p = workProgress(t.wid); openWork({ mode: "replan", wid: t.wid, name: p.name, deadline: p.deadline || today() }); break;
      }
      snapshot(); pushLater([t]);
      const d = ui.sheet; d.ids = d.ids.filter(x => x !== id);
      commit(`已移到 ${rel(t.date)}${t.start != null ? " " + hm(t.start) : ""}`, true);
      if (!d.ids.length) closeSheet(); else renderSheet(); break;
    }
    case "due-auto-all": {
      snapshot(); const all = ui.sheet.ids.map(task).filter(x => x && !x.done);
      const list = all.filter(x => !x.wid), shorts = [];
      [...new Set(all.filter(x => x.wid).map(x => x.wid))].forEach(w => { const r = autoReplanWork(w); if (r.short > 0) shorts.push(`「${r.name}」還差 ${hrsTxt(r.short)} 小時`); });
      const later = pushLater(list); ui.sheet.ids = []; closeSheet();
      commit(`已重新安排 ${all.length} 項${later ? `（${later} 項移到之後的日子）` : ""}${shorts.length ? "；截止日前空檔不夠：" + shorts.join("、") : ""}`, true); break;
    }
    case "due-manual": {
      const d = ui.sheet; d.ids = d.ids.filter(x => x !== id);
      d.ids.forEach(x => { dueSnooze[x] = Date.now() + 2 * 60000; });
      ui.sheet = null; openSheet({ type: "move", id, fromDue: true }); break;
    }
    case "due-snooze": closeSheet(); toast("15 分鐘後再提醒你"); break;
    case "ai-key-save": {
      const v = document.getElementById("ai-key").value.trim();
      if (!v) { document.getElementById("ai-key").focus(); break; }
      S.settings.geminiKey = v; commit("已儲存 Gemini 金鑰"); break;
    }
    case "ai-key-clear": S.settings.geminiKey = ""; commit("已移除 Gemini 金鑰"); break;
    case "set-anim": S.settings.anim = el.dataset.anim; applyAnim(S.settings.anim); commit(); animateView("enter-right"); break;
    case "set-skin": S.settings.skin = el.dataset.skin; applySkin(S.settings.skin); commit(el.dataset.skin === "glass" ? "已換成液態玻璃風格" : el.dataset.skin === "oldschool" ? "已換成 old school 風格" : "已換成 iOS 6 擬物風格"); animateView("fade-in"); break;
    case "bg-pick": document.getElementById("bg-file").click(); break;
    case "bg-clear": {
      applyBg("");
      try { localStorage.removeItem(BG_CACHE); } catch (e) {}
      if (FB.user) bgRef().delete();
      renderMain(); toast("已換回條紋背景"); break;
    }
    case "dur-chip": {
      const grp = el.closest(".durfield"); if (!grp) break;
      const v = +el.dataset.min;
      grp.querySelector('[data-part="h"]').value = Math.floor(v / 60);
      grp.querySelector('[data-part="m"]').value = v % 60;
      grp.querySelector('[data-part="h"]').dispatchEvent(new Event("change", { bubbles: true }));
      break;
    }
    case "set-mode": S.settings.reflowMode = el.dataset.mode; commit(); break;
    case "ed-cat-add": {
      const nameEl = document.getElementById("ed-newcat-name"), name = nameEl.value.trim();
      if (!name) { nameEl.placeholder = "請先輸入分類名稱"; nameEl.focus(); break; }
      const exist = S.cats.find(c => c.name === name);
      const sel = document.getElementById("ed-cat");
      let c = exist;
      if (!c) {
        const color = (document.querySelector('input[name="ed-newcat-color"]:checked') || { value: PALETTE[0] }).value;
        c = document.getElementById("ed-newcat-event").checked ? { id: uid(), name, color, event: true } : { id: uid(), name, color };
        S.cats.push(c); save();
        const opt = document.createElement("option"); opt.value = c.id; opt.textContent = c.name;
        sel.insertBefore(opt, sel.querySelector('option[value="__new"]'));
      }
      sel.value = c.id;
      document.getElementById("ed-newcat").hidden = true;
      sel.dispatchEvent(new Event("change", { bubbles: true }));
      toast(exist ? `已選擇「${name}」` : `已新增分類「${name}」`); break;
    }
    case "ed-cat-cancel": {
      const sel = document.getElementById("ed-cat");
      sel.value = ""; document.getElementById("ed-newcat").hidden = true; break;
    }
    case "ai-open": openSheet({ type: "ai", step: "input", text: "" }); setTimeout(() => { const f = document.getElementById("ai-text"); if (f) f.focus(); }, 50); break;
    case "ai-run": runAI(); break;
    case "ai-use-local": { const a = ui.sheet; if (!a || !a.localItems) break; a.items = a.localItems; a.localItems = null; a.sel = new Set(a.items.map(x => x.id)); a.engine = "local"; a.gem.state = "done"; a.touched = true; renderSheet(); break; }
    case "ai-split": {
      const a = ui.sheet; if (!a || a.type !== "ai") break;
      const i = a.items.findIndex(x => x.id === el.dataset.id); if (i < 0) break;
      const src = a.items[i]; a.touched = true; a.splitting = src.id; renderSheet();
      breakSteps(src.title, src.min).then(({ steps, by }) => {
        if (ui.sheet !== a) return;
        // 排的時候把其他要加入的項目也算進去，才不會撞在一起
        const keep = S.tasks; S.tasks = [...S.tasks, ...a.items.filter(x => x.id !== src.id && a.sel.has(x.id)).map(cleanItem)];
        let outs; try { outs = scheduleSteps(src, steps); } finally { S.tasks = keep; }
        const j = a.items.findIndex(x => x.id === src.id);
        a.items.splice(j < 0 ? a.items.length : j, j < 0 ? 0 : 1, ...outs);
        a.sel.delete(src.id); outs.forEach(o => a.sel.add(o.id)); a.splitting = null;
        renderSheet(); toast(`拆成 ${outs.length} 個步驟${by ? `（${by}）` : ""}`);
      });
      break;
    }
    case "ed-split": {
      const t2 = task(el.dataset.id); if (!t2) break;
      el.disabled = true; el.querySelector(".main").firstChild.textContent = "正在拆成步驟…";
      breakSteps(t2.title, t2.min).then(({ steps, by }) => {
        snapshot();
        const outs = scheduleSteps(t2, steps).map(cleanItem);
        S.tasks = S.tasks.filter(x => x.id !== t2.id); S.tasks.push(...outs);
        [...new Set(outs.map(x => x.date))].forEach(k => arrangeTimes(k, "fill"));
        markFresh(outs.map(x => x.id)); closeSheet(); commit(`「${t2.title}」拆成 ${outs.length} 個步驟${by ? `（${by}）` : ""}`, true);
      });
      break;
    }
    case "morning-replan": {
      const t0 = today();
      S.tasks.forEach(x => { if (x.date === t0 && !x.done && !x.locked && !isEvent(x) && x.start != null) x.start = null; });
      arrangeTimes(t0, "fill"); save(); renderSheet(); renderMain(); toast("已重新排好今天的時段"); break;
    }
    case "cl-key-save": {
      const v = (document.getElementById("cl-key").value || "").trim();
      if (!v) { document.getElementById("cl-key").focus(); break; }
      if (!/^sk-ant-/.test(v)) { toast("Claude 的金鑰應該是 sk-ant- 開頭"); break; }
      S.settings.claudeKey = v; commit("已儲存 Claude 金鑰"); break;
    }
    case "cl-key-clear": S.settings.claudeKey = ""; commit("已移除 Claude 金鑰"); break;
    case "cl-model": S.settings.claudeModel = el.dataset.m; commit(`已改用 ${llmName()}`); break;
    case "cl-key-test": {
      toast(`正在測試 ${llmName()}…`);
      claudeWithKey('回覆 JSON：{"ok":true}', claudeKey()).then(() => toast(`${llmName()} 可以用了 ✓`)).catch(e2 => toast(aiErrorText(e2))); break;
    }
    case "buffer-x": S.settings.bufferX = +el.dataset.v; commit(`拖延緩衝改成 ×${el.dataset.v}`); break;
    case "dur-clear": S.settings.durLearn = {}; commit("已清除時間長度的學習"); break;
    case "ai-use-gem": {
      const a = ui.sheet; if (!a || !a.gem || !a.gem.items) break;
      a.items = aiSchedule(a.gem.items); a.sel = new Set(a.items.map(x => x.id)); a.engine = "ai"; a.gem.state = "applied";
      renderSheet(); break;
    }
    case "notify-on": {
      if (!notifySupported()) { renderMain(); break; }
      Notification.requestPermission().then(p => {
        if (p === "granted") {
          S.settings.notifyOn = true; commit("已開啟通知");
          notify("排程本通知已開啟", `工作開始前 ${S.settings.notifyLead} 分鐘會提醒你。`, "welcome");
          checkNotify();
          ensurePush().then(() => renderMain());
        } else renderMain();
      });
      break;
    }
    case "notify-test": notify("測試通知", "看到這則就代表通知正常 👍", "test" + Date.now()).then(ok => { if (!ok) toast("通知沒有送出，請確認系統設定允許排程本通知"); }); break;
    case "notify-ics": exportICS(); break;
    case "push-on": el.disabled = true; ensurePush().then(ok => { toast(ok ? "背景推播已開啟" : "背景推播沒有開成功"); renderMain(); }); break;
    case "brain-retrain": { Brain.reset(); Brain.train(true); renderMain(); const i = Brain.info(); toast(`訓練完成：分類準確率 ${Math.round(i.acc * 100)}%`); break; }
    case "habit-clear": S.settings.habit = {}; commit("已清除時段習慣"); break;
    case "brain-clear": S.settings.learnLog = []; Brain.reset(); commit("已清除小模型學到的修改"); break;
    case "ai-attach": { const f = document.getElementById("ai-text"); if (f && ui.sheet) ui.sheet.text = f.value; document.getElementById("ai-file").click(); break; }
    case "ai-file-del": { const sh = ui.sheet, f = document.getElementById("ai-text"); if (f) sh.text = f.value; sh.files.splice(+el.dataset.i, 1); renderSheet(); break; }
    case "ai-fix": {
      const a = ui.sheet, x = a.items.find(i => i.id === id); if (!x) break;
      const others = a.items.filter(i => i.id !== x.id && a.sel.has(i.id));
      const slot = nearestFree(x.date, x.min, new Set([x.id]), others);
      if (!slot) { toast("之後兩週都找不到空檔，請自己改時間"); break; }
      x.date = slot.date; x.start = slot.start; x.locked = true;
      renderSheet(); toast(`已改到 ${rel(slot.date)} ${hm(slot.start)}`); break;
    }
    case "ai-back": ui.sheet.step = "input"; renderSheet(); break;
    case "ai-pick": { const a = ui.sheet; a.sel.has(id) ? a.sel.delete(id) : a.sel.add(id); renderSheet(); break; }
    case "ai-apply": {
      const a = ui.sheet; snapshot();
      // 名稱輸入框可能還沒觸發 change，直接讀一次
      document.querySelectorAll('#sheet .pv-title').forEach(inp => { const x = a.items.find(i => i.id === inp.dataset.id); if (x && inp.value.trim()) x.title = inp.value.trim(); });
      applyChanges(a);
      const nchg = a.changes ? a.changes.filter(c => !c.miss && a.csel.has(c.id)).length : 0;
      const add = a.items.filter(x => a.sel.has(x.id));
      const singles = add.filter(x => !x.repeat), reps = add.filter(x => x.repeat);
      add.forEach(x => {
        // 記下你確認／修改後的分類和時間長度，讓 AI 小模型下次更準
        if (x._src != null) brainLearn(x._src, x.cat, /（\d+\/\d+）$/.test(x.title) || /：/.test(x.title) ? 0 : Math.round(x.min / (x._f || 1) / 5) * 5, x.cat !== x._pc || x.min !== x._pm || x.pri !== x._pp, x.pri !== x._pp ? x.pri : null);
        delete x.window; delete x._src; delete x._pc; delete x._pm; delete x._pp; delete x._f; delete x._g; delete x._p; delete x._n;
      });
      singles.forEach(x => { delete x.repeat; });
      S.tasks.push(...singles);
      for (const x of reps) {
        S.series.push({ id: uid(), created: Date.now(), genUntil: null, title: x.title, notes: x.notes || "", pri: x.pri, min: x.min, cat: x.cat,
          start: x.locked ? x.start : null, dlOffset: null, anchor: x.date, freq: x.repeat.freq, interval: x.repeat.interval || 1,
          weekdays: x.repeat.weekdays || [], until: x.repeat.until || null, skipMissed: true });
      }
      if (reps.length) refreshRecurring();
      // 新加入的項目如果彼此撞時段（沒有指定時間的），讓它們重新找空檔
      for (const k of new Set(singles.map(x => x.date))) {
        const day = S.tasks.filter(x => x.date === k && !x.cancelled && x.start != null);
        for (const x of singles.filter(y => y.date === k && !y.locked && y.start != null).sort((p, q) => p.start - q.start)) {
          if (day.some(o => o !== x && o.start != null && o.start < x.start + x.min && x.start < o.start + o.min)) x.start = null;
        }
      }
      [...new Set(add.map(x => x.date))].forEach(k => arrangeTimes(k, "fill"));
      markFresh(add.map(x => x.id));
      closeSheet(); commit(nchg ? `已修改 ${nchg} 項${add.length ? `、加入 ${add.length} 項` : ""}` : `已加入 ${add.length} 項工作`, true); break;
    }
    case "login": signIn(); el.disabled = true; el.lastChild.textContent = "正在前往 Google…"; break;
    case "logout": signOut(); break;
    case "undo": if (undoSnap) { S.tasks = JSON.parse(undoSnap); undoSnap = null; commit("已復原"); } break;
  }
});

document.addEventListener("change", e => {
  const el = e.target;
  if (FB.preview && (el.type === "file" || el.dataset.share)) { toast("正在連上雲端，等一下下再改"); renderMain(); return; }
  if (el.id === "g-date" && el.value) { ui.todaySel = el.value; ui.stripJump = true; renderMain(); animateView("fade-in"); return; }
  if (el.id === "ps-avatar" && ui.sheet && el.files && el.files[0]) {
    shrinkImage(el.files[0]).then(d => { if (ui.sheet && ui.sheet.type === "person") { ui.sheet.avatar = d; renderSheet(); } }).catch(err => toast(err.message));
    return;
  }
  if (el.id === "ps-custom" && ui.sheet) { ui.sheet.custom = true; document.querySelectorAll('#sheet input[name="ps-color"]').forEach(r => { r.checked = false; }); const pv = document.querySelector("#sheet .pprev"); if (pv) pv.style.setProperty("--pc", el.value); return; }
  if (el.name === "ps-color" && ui.sheet) { ui.sheet.custom = false; const pv = document.querySelector("#sheet .pprev"); if (pv) pv.style.setProperty("--pc", el.value); return; }
  if (el.dataset.share) {
    const c = { ...shareCfg() }, f = el.dataset.share;
    if (f === "emails") c.emails = el.value.split(/[\s,;，；]+/).map(x => x.trim().toLowerCase()).filter(x => /@/.test(x));
    else if (f === "range") c.range = +el.value;
    else if (f === "name") c.name = el.value.trim().slice(0, 20);
    else c[f] = el.value;
    S.settings.share = c; commit(); publishShare(true); return;
  }
  if (el.dataset.swipe) {
    const side = el.dataset.swipe[0] === "R" ? "swipeR" : "swipeL", i = +el.dataset.swipe[1];
    const a = [...(S.settings[side] || [])]; a[i] = el.value; S.settings[side] = a.map(x => x || "none");
    commit(); return;
  }
  if (el.dataset.dur) {
    const grp = el.closest(".durfield"), v = readDur(grp);
    grp.querySelectorAll(".chip").forEach(c => c.classList.toggle("on", +c.dataset.min === v));
    if (el.dataset.dur === "ed") { document.getElementById("ed-min").value = v; return; }
    if (el.dataset.dur === "wk") { const w = ui.sheet; if (w) { w.total = readDur(grp, 12000); if (w.step === "estimate") renderSheet(); } return; }
    if (el.dataset.dur === "wkc") { const w = ui.sheet, c = w && w.plan && w.plan.chunks[+el.dataset.i]; if (c) { c.min = v; renderSheet(); } return; }
    if (el.dataset.dur === "wkdone") { const w = ui.sheet; if (w) w.done[el.dataset.id] = readDur(grp, 12000); return; }
    if (el.dataset.dur === "chunkMax" || el.dataset.dur === "chunkMin") {
      S.settings[el.dataset.dur] = Math.max(el.dataset.dur === "chunkMax" ? 15 : 5, Math.min(480, v));
      if (S.settings.chunkMin > S.settings.chunkMax) S.settings[el.dataset.dur === "chunkMax" ? "chunkMin" : "chunkMax"] = S.settings[el.dataset.dur];
      save(); return;
    }
    if (el.dataset.dur === "act" || el.dataset.dur === "ot") return;
    if (el.dataset.dur === "cap") { S.settings.cap = Math.max(15, v); save(); renderMain(); return; }
    if (el.dataset.dur === "pv") {
      const x = ui.sheet && ui.sheet.items && ui.sheet.items.find(i => i.id === el.dataset.id);
      if (x) { x.min = v; renderSheet(); }
      return;
    }
    return;
  }
  if (el.dataset.setnum) {
    const v = Math.max(0, Math.min(240, Math.round(+el.value || 0)));
    S.settings[el.dataset.setnum] = v; save(); return;
  }
  if (el.dataset.bgdim !== undefined) {
    S.settings.bgDim = el.checked; save();
    applyBg(bgData, el.checked);
    if (FB.user && bgData) bgRef().set({ data: bgData, dim: el.checked, updated: Date.now() });
    return;
  }
  if (el.dataset.set) { S.settings[el.dataset.set] = el.checked; commit(); }
  else if (el.dataset.bulk) {
    const b = ui.sheet;
    if (el.dataset.bulk === "from") b.from = el.checked; else { S.settings.skipWeekends = el.checked; save(); }
    recomputeBulk(b); renderSheet();
  } else if (el.dataset.wkf) {
    const w = ui.sheet, c = w && w.plan && w.plan.chunks[+el.dataset.i];
    if (!c || !el.value) return;
    if (el.dataset.wkf === "date") c.date = el.value; else { c.start = toMin(el.value); habitAdd(habitKey({ cat: w.cat || (w.wid && (workChunks(w.wid)[0] || {}).cat) }), c.start + c.min / 2, 1); }
    w.plan.chunks.sort((a, b) => a.date < b.date ? -1 : a.date > b.date ? 1 : a.start - b.start);
    renderSheet(); return;
  } else if (el.dataset.esth !== undefined) {
    const i = +el.dataset.esth, h = Math.max(0.5, Math.min(200, +el.value || 0));
    S.settings.estTypes = estTypes().map((x, j) => j === i ? { ...x, h } : { ...x }); save(); return;
  } else if (el.dataset.aif) {
    const x = ui.sheet && ui.sheet.items && ui.sheet.items.find(i => i.id === el.dataset.id);
    if (!x) return;
    const f = el.dataset.aif, v = el.value;
    if (f === "title") { if (v.trim()) x.title = v.trim(); }
    else if (f === "date") { if (v) { x.date = v; if (!x.locked) x.start = null; } }
    else if (f === "start") { if (v) { x.start = toMin(v); x.locked = true; habitLearnTask(x, x.start + x.min / 2, 1); } else { x.start = null; x.locked = false; } }
    else if (f === "min") x.min = +v;
    else if (f === "cat") { x.cat = v; const c = cat(v); if (c && c.event && x.start == null) { x.start = S.settings.workStart; x.locked = true; } renderSheet(); return; }
    else if (f === "pri") x.pri = +v;
    else if (f === "deadline") x.deadline = v || null;
    else if (f === "notes") x.notes = v;
    if (f === "date" || f === "start" || f === "min") { renderSheet(); return; }
    const w = document.getElementById("pvw-" + x.id); if (w) w.innerHTML = pvWhen(x);
  } else if (el.dataset.bulkdate) { if (el.value) ui.sheet.plan[el.dataset.bulkdate] = el.value; }
  else if (el.id === "ed-hasdl") document.getElementById("ed-dlrow").hidden = !el.checked;
  else if (el.id === "ed-rep") {
    const v = el.value, on = v !== "none";
    document.getElementById("ed-rep-weekly").hidden = v !== "weekly";
    document.getElementById("ed-rep-wint").hidden = v !== "weekly";
    document.getElementById("ed-rep-ndays").hidden = v !== "ndays";
    document.getElementById("ed-rep-monthly").hidden = v !== "monthly";
    document.getElementById("ed-rep-until").hidden = !on;
    document.getElementById("ed-rep-skip").hidden = !on;
    document.getElementById("ed-untilrow").hidden = !on || !document.getElementById("ed-hasuntil").checked;
    document.getElementById("ed-repnote").textContent = repeatNote(v, document.getElementById("ed-skip").checked, !!(ui.sheet && ui.sheet.id && task(ui.sheet.id) && task(ui.sheet.id).series));
  }
  else if (el.id === "ed-hasuntil") document.getElementById("ed-untilrow").hidden = !el.checked;
  else if (el.id === "ed-skip") document.getElementById("ed-repnote").textContent = repeatNote(document.getElementById("ed-rep").value, el.checked, !!(ui.sheet && ui.sheet.id && task(ui.sheet.id) && task(ui.sheet.id).series));
  else if (el.id === "ed-cat") {
    const box = document.getElementById("ed-newcat");
    if (el.value === "__new") { box.hidden = false; setTimeout(() => document.getElementById("ed-newcat-name").focus(), 50); return; }
    box.hidden = true;
    const c = cat(el.value);
    if (c && c.event) {
      const f = document.getElementById("ed-fixed");
      if (!f.checked) { f.checked = true; f.dispatchEvent(new Event("change", { bubbles: true })); }
    }
  }
  else if (el.id === "ed-fixed") {
    document.getElementById("ed-timerow").hidden = !el.checked;
    document.getElementById("ed-timenote").textContent = el.checked ? "固定時間的工作（例如會議、上課）不會被自動排程移動。" : "不指定的話，會在時間表裡自動排進當天有空的時段。";
  }
  else if (el.dataset.time) {
    const v = toMin(el.value);
    if (el.value) { S.settings[el.dataset.time] = v; commit(); }
  }
  else if (el.id === "mv-date" && el.value) document.getElementById("mv-load").textContent = loadText(el.value, task(ui.sheet.id)).txt;
});

document.addEventListener("keydown", e => {
  if (e.key === "Escape" && ui.sheet) closeSheet();
  if (e.key === "Enter" && e.target.id === "g-quick" && !e.isComposing) {
    e.preventDefault();
    const v = e.target.value.trim(), d = e.target.dataset.date; if (!v) return;
    // 打字新增：一樣用智慧輸入看懂「15:00 開會」「讀論文 2 小時」
    let it = null; try { it = aiParse(JSON.stringify(localParse(v)))[0]; } catch (e2) {}
    const nid = uid();
    S.tasks.push(normalize({ id: nid, title: (it && it.title) || v, notes: "", date: d, deadline: it ? it.deadline : null, pri: it ? it.pri : 1, min: it ? Math.round(it.min * smartFactor(it) / 10) * 10 || 30 : 30,
      cat: it ? it.cat : (S.cats[0] || {}).id, done: false, doneOn: null, resched: 0, created: Date.now(), start: it && it.time != null ? it.time : null, locked: !!(it && it.time != null), anytime: !(it && it.time != null) }));
    markFresh([nid]); commit(); requestAnimationFrame(() => { const q = document.getElementById("g-quick"); if (q) q.focus(); });
    return;
  }
  if (e.key === "Enter" && e.target.id === "gm-kw") { e.preventDefault(); const b = document.querySelector('[data-act="gm-kw-add"]'); if (b) b.click(); }
  if (e.key === "Enter" && e.target.id === "ed-title") { e.preventDefault(); document.querySelector('[data-act="ed-save"]').click(); }
});

/* Drag & drop on the calendar (desktop) */
document.addEventListener("dragstart", e => {
  const row = e.target.closest && e.target.closest(".row[draggable]");
  if (!row) return;
  e.dataTransfer.setData("text/plain", row.dataset.id); e.dataTransfer.effectAllowed = "move"; row.classList.add("dragging");
});
document.addEventListener("dragend", e => { const r = e.target.closest && e.target.closest(".row"); if (r) r.classList.remove("dragging"); });
document.addEventListener("dragover", e => { const c = e.target.closest && e.target.closest("[data-drop]"); if (c) { e.preventDefault(); c.classList.add("dropover"); } });
document.addEventListener("dragleave", e => { const c = e.target.closest && e.target.closest("[data-drop]"); if (c) c.classList.remove("dropover"); });
document.addEventListener("drop", e => {
  const c = e.target.closest && e.target.closest("[data-drop]"); if (!c) return;
  e.preventDefault();
  const t = task(e.dataTransfer.getData("text/plain")); if (!t) return;
  snapshot(); reschedule(t, c.dataset.drop); ui.sel = c.dataset.drop; commit(`已移到 ${rel(c.dataset.drop)}`, true);
});

/* ---------- Start ---------- */
function rolloverPrompt() {
  { let tz = ""; try { tz = Intl.DateTimeFormat().resolvedOptions().timeZone || ""; } catch (e) {}
    if (tz && S.settings.tz !== tz) { S.settings.tz = tz; save(); } }
  if (S.settings.notifyOn && notePerm() === "granted") ensurePush().then(() => { if (ui.tab === "settings") renderMain(); });
  if (!S.cats.some(c => c.event) && !S.settings.eventCatAdded) {
    S.cats.push({ id: "cev", name: "固定事件", color: "#64748B", event: true });
    S.settings.eventCatAdded = true;
    save();
  }
  refreshIfNewDay();
  if (parseShareId(location.hash) || (() => { try { return sessionStorage.getItem("planflow-pending-share"); } catch (e) { return null; } })()) { checkShareHash(); return; }
  if (!S.settings.setupDone && !S.tasks.length && !S.series.length && !ui.sheet) { openSheet({ type: "setup", first: true }); return; }
  if (S.settings.reflowMode === "auto") {
    const n = autoReflow();
    if (n) { renderMain(); toast(`已自動把 ${n} 項沒做完的工作往後重新安排${autoShort.length ? "；" + autoShort.join("、") : ""}`, true); }
    setTimeout(maybeMorningPlan, 600);
    return;
  }
  const overdueNow = S.tasks.filter(isOverdue);
  if (S.settings.prompt && S.settings.lastPrompt !== today() && overdueNow.length) {
    S.settings.lastPrompt = today(); save();
    openBulk(sortTasks(overdueNow).map(x => x.id), today(), false);
    ui.morningPending = true;
    return;
  }
  checkDue();
  setTimeout(maybeMorningPlan, 600);
}
if (loadSnap()) { applySkin(S.settings.skin); }
// 切到背景或關掉前，立刻把資料存在手機裡（下次打開馬上有）
document.addEventListener("visibilitychange", () => { if (document.visibilityState === "hidden") saveSnap(true); });
window.addEventListener("pagehide", () => saveSnap(true));
if (parseShareId(location.hash)) { try { sessionStorage.setItem("planflow-pending-share", parseShareId(location.hash)); } catch (e) {} }
render();
initFirebase();
if ("serviceWorker" in navigator) navigator.serviceWorker.register("/sw.js").catch(e => console.warn("sw", e));
setInterval(checkNotify, 30 * 1000);
setTimeout(() => gemBackfill(), 20000);
setInterval(() => {
  if (!FB.loaded || document.visibilityState !== "visible") return;
  gemBackfill();
  if (S.settings.reflowMode === "auto") {
    const n = autoReflow();
    if (n) { renderMain(); toast(`已自動把 ${n} 項過了時間的工作往後安排${autoShort.length ? "；" + autoShort.join("、") : ""}`, true); return; }
  } else {
    checkDue();
  }
  if (ui.tab === "today" && ui.todayMode === "timeline" && !ui.sheet) renderMain();
}, 60 * 1000);
document.addEventListener("visibilitychange", () => {
  if (document.visibilityState !== "visible" || !FB.loaded) return;
  checkNotify();
  if (lastRefreshDay !== today()) { refreshIfNewDay(); renderMain(); rolloverPrompt(); }
  else checkDue();
});
// 測試／訓練用：只有測試程式會打開，平常不會
if (window.__pfExpose) window.__pf = { localParse, aiParse, parseLine, Brain, catName: id => (cat(id) || {}).name || "", S: () => S };
})();
