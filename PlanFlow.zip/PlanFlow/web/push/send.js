/*
 * 排程本背景推播（GitHub Actions 每 5 分鐘跑一次）
 * - 用 FIREBASE_SERVICE_ACCOUNT 讀每個人的工作，時間到了就送 Web Push 通知到手機
 * - 推播金鑰（VAPID）從服務帳戶金鑰推導出來，不用另外設定；公開的那一半寫到 config/push 給網頁讀
 * - 跟網頁共用 users/{uid}/meta/pushlog，同一則通知不會送兩次
 */
const crypto = require("crypto");

function vapidFrom(sa) {
  // 用服務帳戶的私密金鑰算出一把固定的 P-256 金鑰（同一個專案每次都一樣）
  const n = BigInt("0xFFFFFFFF00000000FFFFFFFFFFFFFFFFBCE6FAADA7179E84F3B9CAC2FC632551");
  let seed = crypto.createHmac("sha256", sa.private_key).update("planflow-vapid-v1").digest();
  for (let i = 0; i < 10; i++) {
    const d = BigInt("0x" + seed.toString("hex"));
    if (d > 0n && d < n) break;
    seed = crypto.createHash("sha256").update(seed).digest();
  }
  const ecdh = crypto.createECDH("prime256v1");
  ecdh.setPrivateKey(seed);
  const b64u = b => Buffer.from(b).toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  return { publicKey: b64u(ecdh.getPublicKey(null, "uncompressed")), privateKey: b64u(seed) };
}

/** 依使用者時區算出「今天」「明天」和現在是幾點（分鐘） */
function localNow(tz, date = new Date()) {
  let parts;
  try { parts = new Intl.DateTimeFormat("en-CA", { timeZone: tz, year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).formatToParts(date); }
  catch (e) { return localNow("Asia/Taipei", date); }
  const g = t => +parts.find(p => p.type === t).value;
  const y = g("year"), m = g("month"), d = g("day");
  const key = (Y, M, D) => { const x = new Date(Date.UTC(Y, M - 1, D)); return x.toISOString().slice(0, 10); };
  return { today: key(y, m, d), tomorrow: key(y, m, d + 1), yesterday: key(y, m, d - 1), now: g("hour") * 60 + g("minute") };
}
const hm = m => `${String(Math.floor(m / 60) % 24).padStart(2, "0")}:${String(m % 60).padStart(2, "0")}`;

/** 決定這位使用者現在要送哪些通知（跟網頁 checkNotify 同一套規則、同一組 key） */
function planMessages({ settings, cats, todayTasks, dueTasks, sent, clock }) {
  const s = settings || {}, out = [];
  if (!s.notifyOn) return out;
  const { today: t0, tomorrow: t1, now } = clock;
  const lead = Math.max(0, +(s.notifyLead ?? 10) || 0);
  const isEvent = t => { const c = (cats || []).find(c => c.id === t.cat); return !!(c && c.event); };
  const catName = t => { const c = (cats || []).find(c => c.id === t.cat); return c ? c.name : ""; };
  for (const t of todayTasks) {
    if (t.done || t.start == null || t.date !== t0) continue;
    const k = `s@${t.id}@${t0}@${t.start}`;
    if (!sent[k] && now >= t.start - lead && now <= t.start + 10) {
      const left = t.start - now;
      out.push({ key: k, title: `${left > 0 ? `${left} 分鐘後` : "現在開始"}：${t.title}`, body: `${hm(t.start)}–${hm(t.start + t.min)}${catName(t) ? ` · ${catName(t)}` : ""}${t.notes ? `\n${String(t.notes).split("\n")[0]}` : ""}` });
    }
    if (s.notifyDue !== false && !isEvent(t)) {
      const end = t.start + t.min, ke = `e@${t.id}@${t0}@${end}`;
      if (!sent[ke] && now >= end && now <= end + 30) out.push({ key: ke, title: `時間到了：${t.title}`, body: "做完了嗎？打開排程本可以打勾，或往後重新安排。" });
    }
  }
  if (s.notifyDeadline !== false && now >= (s.workStart ?? 540) && !sent[`dl@${t0}`]) {
    const d0 = dueTasks.filter(t => !t.done && t.deadline === t0), d1 = dueTasks.filter(t => !t.done && t.deadline === t1);
    if (d0.length || d1.length) {
      const list = (L, w) => `${w}截止：${L.map(t => t.title).slice(0, 4).join("、")}${L.length > 4 ? ` 等 ${L.length} 項` : ""}`;
      out.push({ key: `dl@${t0}`, title: "截止日提醒", body: [d0.length ? list(d0, "今天") : "", d1.length ? list(d1, "明天") : ""].filter(Boolean).join("\n") });
    } else out.push({ key: `dl@${t0}`, silent: true });
  }
  return out;
}

async function main() {
  const admin = require("firebase-admin"), webpush = require("web-push");
  const sa = JSON.parse(process.env.SA || "{}");
  if (!sa.private_key) { console.log("::error::Missing secret FIREBASE_SERVICE_ACCOUNT"); process.exit(1); }
  admin.initializeApp({ credential: admin.credential.cert(sa) });
  const db = admin.firestore();
  const keys = vapidFrom(sa);
  webpush.setVapidDetails(`https://${sa.project_id}.firebaseapp.com`, keys.publicKey, keys.privateKey);
  const cfg = await db.doc("config/push").get();
  if (!cfg.exists || cfg.data().publicKey !== keys.publicKey) {
    await db.doc("config/push").set({ publicKey: keys.publicKey, updated: Date.now() });
    console.log("已更新推播公開金鑰");
  }
  const users = await db.collection("users").get();
  let sentCount = 0, userCount = 0;
  for (const u of users.docs) {
    const data = u.data() || {}, s = data.settings || {};
    if (!s.notifyOn || !s.pushOn) continue;
    const subs = await u.ref.collection("push").get();
    if (subs.empty) continue;
    userCount++;
    const clock = localNow(s.tz || "Asia/Taipei");
    const [todaySnap, dueSnap, logSnap] = await Promise.all([
      u.ref.collection("tasks").where("date", "==", clock.today).get(),
      s.notifyDeadline !== false ? u.ref.collection("tasks").where("deadline", "in", [clock.today, clock.tomorrow]).get() : Promise.resolve({ docs: [] }),
      u.ref.collection("meta").doc("pushlog").get()
    ]);
    const asTask = d => ({ id: d.id, ...d.data() });
    const sent = (logSnap.exists && logSnap.data().sent) || {};
    const msgs = planMessages({ settings: s, cats: data.cats, todayTasks: todaySnap.docs.map(asTask), dueTasks: dueSnap.docs.map(asTask), sent, clock });
    if (!msgs.length) continue;
    const update = {};
    for (const m of msgs) {
      update[m.key] = clock.today;
      if (m.silent) continue;
      for (const sub of subs.docs) {
        const x = sub.data();
        try {
          await webpush.sendNotification({ endpoint: x.endpoint, keys: x.keys }, JSON.stringify({ title: m.title, body: m.body, tag: m.key }), { TTL: 3600, urgency: "high" });
          sentCount++;
        } catch (e) {
          console.log(`推播失敗 ${e.statusCode || ""} ${String(e.body || e.message).slice(0, 120)}`);
          if (e.statusCode === 404 || e.statusCode === 410 || e.statusCode === 403) await sub.ref.delete();   // 這支手機取消訂閱了，或金鑰換了
        }
      }
    }
    // 只留最近兩天的紀錄
    const keep = {};
    for (const [k, v] of Object.entries({ ...sent, ...update })) if (v >= clock.yesterday) keep[k] = v;
    await u.ref.collection("meta").doc("pushlog").set({ sent: keep, updated: Date.now() });
  }
  console.log(`檢查 ${userCount} 位使用者，送出 ${sentCount} 則通知`);
}

if (require.main === module) main().catch(e => { console.error(e); process.exit(1); });
module.exports = { vapidFrom, localNow, planMessages };
