const fs = require("fs"), path = require("path");
const code = ["core.js", "testset.js", "testset2.js", "testset3.js"].map(f => fs.readFileSync(path.join(__dirname, f), "utf8")).join("\n");
const api = new Function(code + "\nreturn { bcFeats, bcForward, bcMin, bcUnpack, BC_H, BC_D, TESTSET2, TESTSET3 };")();
const buf = fs.readFileSync(process.argv[2]); const hl = buf.readUInt32LE(0);
const head = JSON.parse(buf.slice(4, 4 + hl).toString()); let off = 4 + hl; off += (4 - off % 4) % 4;
const ab = buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.length);
const M = api.bcUnpack(new Int8Array(ab, off + api.BC_H * 4, api.BC_H * api.BC_D), new Float32Array(ab, off, api.BC_H), head);
for (const [n, SET] of [["第二份", api.TESTSET2], ["口語", api.TESTSET3]]) {
  let ok = 0, okE = 0, mae = 0;
  for (const [x, c, e, m] of SET) { const o = api.bcForward(M, api.bcFeats(x)); let ci = 0; for (let k = 1; k < o.p.length; k++) if (o.p[k] > o.p[ci]) ci = k; if (M.names[ci] === c) ok++; if ((o.ev > .5) === !!e) okE++; mae += Math.abs(Math.log2(api.bcMin(o.m)) - Math.log2(m)); }
  console.log(`${n}: 分類 ${(ok / SET.length * 100).toFixed(1)}% 固定事件 ${(okE / SET.length * 100).toFixed(1)}% 時間 ×${Math.pow(2, mae / SET.length).toFixed(2)}`);
}
