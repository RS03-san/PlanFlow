# AI 小模型訓練程式

重新訓練：`node train.js 8 12 --save ../public/brain-base.bin`

- corpus.js：訓練句型（可以自己加）
- testset.js：調參數用的考題
- testset2.js：沒調過參數的考題（誠實估計準確率）
- core.js：模型本體，跟 index.html 裡的是同一份

## 老師答案（跟給 Claude 的提示指令同一套規則）

- teacher.js：143 句，照提示指令（aiPrompt）的 13 條規則標好的正確答案，用來調整內建規則
- teacher2.js：40 句，調規則時沒有看，用來誠實估計準確率
- 考試：`node teacheval.js ../public <放 fakefb.js 的資料夾> [--held] [--bad]`
  （會比對名稱、分類、固定事件、時間長度、優先順序、日期、幾點、截止日、重複、區間）
