# AI 小模型訓練程式

重新訓練：`node train.js 8 12 --save ../public/brain-base.bin`

- corpus.js：訓練句型（可以自己加）
- testset.js：調參數用的考題
- testset2.js：沒調過參數的考題（誠實估計準確率）
- core.js：模型本體，跟 index.html 裡的是同一份
