/* 訓練：node train.js [epochs] [perPhrase] → 印出考題準確率，存 brain-base.bin */
const fs = require("fs"), path = require("path");
const dir = __dirname;
const code = ["core.js", "corpus.js", "testset.js", "testset2.js"].map(f => fs.readFileSync(path.join(dir, f), "utf8")).join("\n");
const api = new Function(code + "\nreturn { TESTSET2, bcModel, bcFeats, bcForward, bcStep, bcZ, bcMin, bcPack, bcUnpack, bcRng, generate, TESTSET, BC_H, BC_D };")();
const EPOCHS = +process.argv[2] || 10, PER = +process.argv[3] || 6;
const NAMES = ["工作", "學習", "生活", "其他"];
const data = api.generate(42, PER).map(x => ({ f: api.bcFeats(x.x), c: NAMES.indexOf(x.c), e: x.e, m: api.bcZ(x.m), w: 1 }));
const M = api.bcModel(NAMES, 7), r = api.bcRng(11);
const t0 = Date.now();
const order = data.map((_, i) => i);
function evalSet(Mx, label, SET = api.TESTSET) {
  let ok = 0, okE = 0, mae = 0; const bad = [];
  for (const [x, c, e, m] of SET) {
    const o = api.bcForward(Mx, api.bcFeats(x));
    let ci = 0; for (let k = 1; k < o.p.length; k++) if (o.p[k] > o.p[ci]) ci = k;
    const pm = api.bcMin(o.m);
    if (Mx.names[ci] === c) ok++; else bad.push(`${x}→${Mx.names[ci]}(${Math.round(o.p[ci] * 100)}%)≠${c}`);
    if ((o.ev > 0.5) === !!e) okE++; else bad.push(`${x} 固定事件 ${Math.round(o.ev * 100)}%≠${e}`);
    mae += Math.abs(Math.log2(pm) - Math.log2(m));
  }
  const n = SET.length;
  console.log(`${label}: 分類 ${(ok / n * 100).toFixed(1)}%  固定事件 ${(okE / n * 100).toFixed(1)}%  時間誤差 ×${Math.pow(2, mae / n).toFixed(2)}  (n=${n})`);
  return { acc: ok / n, accE: okE / n, mult: Math.pow(2, mae / n), bad };
}
for (let ep = 0; ep < EPOCHS; ep++) {
  const lr = 0.5 * (1 - ep / EPOCHS) + 0.02;
  for (let i = order.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [order[i], order[j]] = [order[j], order[i]]; }
  for (const ix of order) api.bcStep(M, data[ix], lr);
}
console.log(`訓練資料 ${data.length} 句，${EPOCHS} 輪，${((Date.now() - t0) / 1000).toFixed(1)} 秒`);
const res = evalSet(M, "原始模型");
const pk = api.bcPack(M);
const M2 = api.bcUnpack(pk.q, pk.sc, pk.head);
const res2 = evalSet(M2, "壓縮後");
const res3 = evalSet(M2, "第二份考題（沒調過參數）", api.TESTSET2);
if (process.argv.includes("--bad")) console.log(res3.bad.join("\n"));
if (process.argv.includes("--bad")) console.log(res2.bad.join("\n"));
if (process.argv.includes("--save")) {
  // 檔案格式：4 bytes 標頭長度 + 標頭 JSON + 縮放值(float32 × H) + 權重(int8 × H × D)
  const head = Buffer.from(JSON.stringify({ ...pk.head, trainedOn: data.length, test: { acc: res3.acc, accE: res3.accE, mult: res3.mult, n: api.TESTSET2.length } }), "utf8");
  const len = Buffer.alloc(4); len.writeUInt32LE(head.length);
  const pad = Buffer.alloc((4 - ((4 + head.length) % 4)) % 4, 32);
  const buf = Buffer.concat([len, head, pad, Buffer.from(pk.sc.buffer), Buffer.from(pk.q.buffer)]);
  fs.writeFileSync(process.argv[process.argv.indexOf("--save") + 1], buf);
  console.log("saved", buf.length, "bytes");
}
