/* ===== AI 小模型核心（網頁和訓練程式共用同一份） ===== */
const BC_H = 16384, BC_D = 32, BC_MU = Math.log2(60), BC_SD = 1.2;
const bcRng = seed => () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };
function bcHash(s) { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return (h >>> 0) % BC_H; }
function bcNorm(s) {
  return String(s || "").toLowerCase().replace(/[０-９]/g, c => String.fromCharCode(c.charCodeAt(0) - 0xFEE0))
    .replace(/（\d+\/\d+）|\(\d+\/\d+\)/g, "").replace(/\d+/g, "#").replace(/[，,。.！!？?、；;：:「」『』（）()\[\]【】~～\-—_/]/g, " ").replace(/\s+/g, " ").trim();
}
/** 一句話 → 片段：每個字、相鄰兩個字、相鄰三個字、英文單字、開頭／結尾的字 */
function bcTokens(s) {
  const t = bcNorm(s), out = [];
  for (const w of (t.match(/[a-z#]+/g) || [])) { out.push("w:" + w); if (w.length > 4) out.push("p:" + w.slice(0, 4)); }
  const segs = t.replace(/[a-z#\s]+/g, " ").split(" ").filter(Boolean);
  for (const seg of segs) {
    for (let i = 0; i < seg.length; i++) {
      out.push("u:" + seg[i]);
      if (i + 1 < seg.length) out.push("b:" + seg.slice(i, i + 2));
      if (i + 2 < seg.length) out.push("t:" + seg.slice(i, i + 3));
    }
  }
  if (segs.length) { out.push("s:" + segs[0][0]); const l = segs[segs.length - 1]; out.push("e:" + l[l.length - 1]); }
  return out;
}
function bcFeats(s) { const f = [...new Set(bcTokens(s))].map(bcHash); return f.length ? f : [bcHash("u:?")]; }
function bcModel(names, seed) {
  const r = bcRng(seed || 7), C = names.length;
  return { names: names.slice(), W: new Float32Array(BC_H * BC_D).map(() => (r() - 0.5) * 0.2), Cw: new Float32Array(C * BC_D), Cb: new Float32Array(C),
    Ew: new Float32Array(BC_D), Eb: 0, Mw: new Float32Array(BC_D), Mb: 0 };
}
/** 新增分類（例如你自己加的「社團」）：多一個輸出 */
function bcAddNames(M, names) {
  const add = names.filter(n => !M.names.includes(n));
  if (!add.length) return M;
  const C = M.names.length + add.length, Cw = new Float32Array(C * BC_D), Cb = new Float32Array(C);
  Cw.set(M.Cw); Cb.set(M.Cb);
  for (let c = M.names.length; c < C; c++) Cb[c] = -2;      // 新分類一開始機率低，要等你的資料教它
  M.names = [...M.names, ...add]; M.Cw = Cw; M.Cb = Cb;
  return M;
}
function bcForward(M, f) {
  const D = BC_D, h = new Float32Array(D), W = M.W;
  for (const k of f) { const o = k * D; for (let j = 0; j < D; j++) h[j] += W[o + j]; }
  for (let j = 0; j < D; j++) h[j] /= f.length;
  const C = M.names.length, p = new Float32Array(C);
  let mx = -1e9;
  for (let c = 0; c < C; c++) { let z = M.Cb[c]; for (let j = 0; j < D; j++) z += M.Cw[c * D + j] * h[j]; p[c] = z; if (z > mx) mx = z; }
  let sum = 0; for (let c = 0; c < C; c++) { p[c] = Math.exp(p[c] - mx); sum += p[c]; }
  for (let c = 0; c < C; c++) p[c] /= sum;
  let ze = M.Eb, zm = M.Mb; for (let j = 0; j < D; j++) { ze += M.Ew[j] * h[j]; zm += M.Mw[j] * h[j]; }
  return { h, p, ev: 1 / (1 + Math.exp(-ze)), m: zm };
}
/** 一筆資料訓練一步：d = { f: 特徵, c: 分類編號(-1=不知道), e: 0/1/-1, m: 標準化後的分鐘(null=不知道), w: 權重 } */
function bcStep(M, d, lr) {
  const D = BC_D, o = bcForward(M, d.f), C = M.names.length, g = new Float32Array(D), w = d.w || 1;
  if (d.c >= 0) for (let c = 0; c < C; c++) {
    const gc = (o.p[c] - (c === d.c ? 1 : 0)) * w;
    for (let j = 0; j < D; j++) { g[j] += gc * M.Cw[c * D + j]; M.Cw[c * D + j] -= lr * gc * o.h[j]; }
    M.Cb[c] -= lr * gc;
  }
  if (d.e === 0 || d.e === 1) {
    const ge = (o.ev - d.e) * w * 0.7;
    for (let j = 0; j < D; j++) { g[j] += ge * M.Ew[j]; M.Ew[j] -= lr * ge * o.h[j]; }
    M.Eb -= lr * ge;
  }
  if (d.m != null) {
    const gm = Math.max(-2, Math.min(2, o.m - d.m)) * w * 0.5;
    for (let j = 0; j < D; j++) { g[j] += gm * M.Mw[j]; M.Mw[j] -= lr * gm * o.h[j]; }
    M.Mb -= lr * gm;
  }
  const inv = lr / d.f.length;
  for (const k of d.f) { const off = k * D; for (let j = 0; j < D; j++) M.W[off + j] -= inv * g[j]; }
}
const bcMin = z => Math.max(10, Math.min(480, Math.round(Math.pow(2, z * BC_SD + BC_MU) / 5) * 5));
const bcZ = m => (Math.log2(m) - BC_MU) / BC_SD;
/** 把訓練好的模型壓成小檔案（int8，每一列一個縮放值） */
function bcPack(M) {
  const D = BC_D, rows = BC_H, q = new Int8Array(rows * D), sc = new Float32Array(rows);
  for (let r = 0; r < rows; r++) {
    let mx = 0; for (let j = 0; j < D; j++) mx = Math.max(mx, Math.abs(M.W[r * D + j]));
    const s = mx / 127 || 1e-6; sc[r] = s;
    for (let j = 0; j < D; j++) q[r * D + j] = Math.round(M.W[r * D + j] / s);
  }
  const head = { names: M.names, Cw: Array.from(M.Cw), Cb: Array.from(M.Cb), Ew: Array.from(M.Ew), Eb: M.Eb, Mw: Array.from(M.Mw), Mb: M.Mb, H: BC_H, D };
  return { q, sc, head };
}
function bcUnpack(q, sc, head) {
  const D = BC_D, W = new Float32Array(BC_H * D);
  for (let r = 0; r < BC_H; r++) for (let j = 0; j < D; j++) W[r * D + j] = q[r * D + j] * sc[r];
  return { names: head.names.slice(), W, Cw: Float32Array.from(head.Cw), Cb: Float32Array.from(head.Cb), Ew: Float32Array.from(head.Ew), Eb: head.Eb, Mw: Float32Array.from(head.Mw), Mb: head.Mb };
}
