/* 用老師答案考「內建規則＋小模型」：node teacheval.js <public 目錄> <scratchpad> [--bad] */
const { chromium } = require('playwright');
const fs = require('fs'), path = require('path');
const TEACH = process.argv.includes('--held') ? require('./teacher2.js').TEACH2 : require('./teacher.js').TEACH;
(async () => {
  const pub = process.argv[2], SP = process.argv[3], showBad = process.argv.includes('--bad');
  const b = await chromium.launch(); const ctx = await b.newContext({ timezoneId: 'Asia/Taipei' }); const p = await ctx.newPage();
  await p.clock.install({ time: new Date('2026-11-09T08:00:00+08:00') });
  const preset = { 'users/u1': { cats: [{ id: 'c1', name: '工作', color: '#4F6BFF' }, { id: 'c2', name: '學習', color: '#8E5CF6' }, { id: 'c3', name: '生活', color: '#24965F' }, { id: 'c4', name: '其他', color: '#999' }, { id: 'cev', name: '固定事件', color: '#64748B', event: true }],
    settings: { workStart: 540, workEnd: 1080, prompt: false, setupDone: true, eventCatAdded: true, morningPlan: false }, sample: false } };
  await p.addInitScript(pr => { window.__loggedIn = true; window.__preset = pr; window.__pfExpose = true; }, preset);
  await p.route('**/*', async r => {
    const u = new URL(r.request().url());
    if (u.hostname === 'www.gstatic.com') {
      if (u.pathname.includes('app-compat')) return r.fulfill({ body: fs.readFileSync(SP + '/fakefb.js', 'utf8'), contentType: 'text/javascript' });
      return r.fulfill({ body: '', contentType: 'text/javascript' });
    }
    if (u.hostname === 'app.test') {
      if (u.pathname === '/__/firebase/init.json') return r.fulfill({ body: '{"apiKey":"x","projectId":"demo"}', contentType: 'application/json' });
      const f = path.join(pub, u.pathname === '/' ? 'index.html' : u.pathname);
      if (fs.existsSync(f)) return r.fulfill({ path: f });
      return r.fulfill({ status: 404, body: '' });
    }
    return r.abort();
  });
  await p.goto('http://app.test/'); await p.waitForFunction(() => window.__pf && window.__pf.S().cats.length > 2, null, { timeout: 20000 });
  await p.evaluate(() => window.__pf.Brain.ready && window.__pf.Brain.ready()).catch(() => {});
  await p.waitForTimeout(1500);
  const got = await p.evaluate(T => T.map(([x]) => {
    try {
      const items = window.__pf.aiParse(JSON.stringify(window.__pf.localParse(x)));
      return items.map(it => ({ t: it.title, c: window.__pf.catName(it.cat0 || it.cat), e: it.isEv ? 1 : 0, m: it.min, p: it.pri, d: it.date, tm: it.time != null ? `${String(Math.floor(it.time / 60)).padStart(2, '0')}:${String(it.time % 60).padStart(2, '0')}` : null, dl: it.deadline,
        rp: it.repeat ? (it.repeat.freq === 'weekly' ? (it.repeat.weekdays && it.repeat.weekdays.join() === '1,2,3,4,5' ? 'weekdays' : 'weekly:' + (it.repeat.weekdays || []).join(',')) : it.repeat.freq) : null, rs: it.rangeStart || null, re: it.rangeEnd || null, parts: it.parts || 1 }));
    } catch (e) { return [{ err: String(e) }]; }
  }), TEACH);
  await b.close();
  const D = s => s ? '2026-' + s : null;
  const norm = s => String(s || '').replace(/[\s、，,。.!！~～…]/g, '').toLowerCase();
  const sim = (a, b) => { a = norm(a); b = norm(b); if (!a || !b) return 0; if (a === b) return 1; const A = new Set([...a]), B = new Set([...b]); let n = 0; for (const c of A) if (B.has(c)) n++; return 2 * n / (A.size + B.size); };
  const F = { count: 0, title: 0, titleExact: 0, cat: 0, ev: 0, min: 0, pri: 0, date: 0, time: 0, dl: 0, rp: 0, range: 0 }; let N = 0, full = 0;
  const bad = [];
  TEACH.forEach(([x, exp], i) => {
    const g = got[i];
    const okCount = g.length === exp.length; if (okCount) F.count++;
    let allOk = okCount;
    exp.forEach((e, j) => {
      const [t, c, ev, m, pr, d, tm, dl, ex = {}] = e;
      // 拆開的項目：用名稱最像的那一個來比
      let o = g[j]; let bs = -1; for (const y of g) { const v = sim(y.t, t); if (v > bs) { bs = v; o = y; } }
      N++;
      if (!o || o.err) { allOk = false; bad.push(`${x} → 錯誤 ${o && o.err}`); return; }
      const chk = {
        title: sim(o.t, t) >= 0.75, titleExact: norm(o.t) === norm(t), cat: o.c === c, ev: o.e === ev,
        min: Math.abs(Math.log2(o.m / m)) <= Math.log2(1.5), pri: o.p === pr, date: (o.d || null) === D(d), time: (o.tm || null) === (tm || null), dl: (o.dl || null) === D(dl),
        rp: (o.rp || null) === (ex.rp || null) || (ex.rp && o.rp && ex.rp.startsWith('weekly') && o.rp === ex.rp), range: (o.rs || null) === D(ex.rs) && (o.re || null) === D(ex.re) && (ex.parts || 1) === (o.parts || 1)
      };
      for (const k in chk) if (chk[k]) F[k]++;
      const wrong = Object.keys(chk).filter(k => !chk[k] && k !== 'titleExact');
      if (wrong.length) { allOk = false; bad.push(`${x}\n   答案：${t}｜${c}｜${ev ? '固定' : '-'}｜${m}分｜P${pr}｜${d || '-'} ${tm || ''}｜截止${dl || '-'}${ex.rp ? '｜' + ex.rp : ''}${ex.re ? `｜${ex.rs}~${ex.re}×${ex.parts || 1}` : ''}\n   規則：${o.t}｜${o.c}｜${o.e ? '固定' : '-'}｜${o.m}分｜P${o.p}｜${o.d ? o.d.slice(5) : '-'} ${o.tm || ''}｜截止${o.dl ? o.dl.slice(5) : '-'}${o.rp ? '｜' + o.rp : ''}${o.re ? `｜${o.rs.slice(5)}~${o.re.slice(5)}×${o.parts}` : ''}   ✗ ${wrong.join(',')}`); }
    });
    if (allOk) full++;
  });
  const pc = (v, n) => (v / n * 100).toFixed(1) + '%';
  console.log(`老師答案 ${TEACH.length} 句（${N} 項）：完全一樣 ${pc(full, TEACH.length)}`);
  console.log(`  拆成幾項 ${pc(F.count, TEACH.length)}｜名稱 ${pc(F.title, N)}（一字不差 ${pc(F.titleExact, N)}）｜分類 ${pc(F.cat, N)}｜固定事件 ${pc(F.ev, N)}｜時間長度(±50%) ${pc(F.min, N)}`);
  console.log(`  優先 ${pc(F.pri, N)}｜日期 ${pc(F.date, N)}｜幾點 ${pc(F.time, N)}｜截止日 ${pc(F.dl, N)}｜重複 ${pc(F.rp, N)}｜區間 ${pc(F.range, N)}`);
  if (showBad) console.log('\n' + bad.join('\n'));
})();
