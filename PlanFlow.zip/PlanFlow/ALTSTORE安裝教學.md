# 用 AltStore 把「排程本」裝到 iPhone（不需要 Mac）

整個流程分兩段：
1. **用 GitHub 免費編譯出 `PlanFlow.ipa`**（GitHub 的 Mac 主機幫你編譯）
2. **用 AltStore 安裝 `.ipa` 到 iPhone**

需要：一台 Windows 或 Mac 電腦（給 AltServer 用）、iPhone、Apple ID（免費的就可以）、GitHub 帳號（免費）。

---

## 第一段：用 GitHub 編譯出 .ipa

1. 到 https://github.com 註冊／登入
2. 右上角 **＋ › New repository**
   - Repository name：`PlanFlow`
   - 選 **Private**（不想公開的話）
   - 按 **Create repository**
3. 在新的 repo 頁面點 **uploading an existing file**
4. 把解壓縮後 `PlanFlow` 資料夾**裡面的所有東西**拖進去（包含 `.github` 資料夾）
   - ⚠️ `.github` 是隱藏資料夾：
     - Mac：在 Finder 按 `⌘ + Shift + .` 顯示隱藏檔
     - Windows：檔案總管 › 檢視 › 勾選「隱藏的項目」
   - 如果拖不進 `.github`，也可以之後在 repo 裡按 **Add file › Create new file**，檔名輸入
     `.github/workflows/build-ipa.yml`，再把那個檔案的內容貼上
5. 按 **Commit changes**
6. 點上方 **Actions** 分頁 → 左邊點 **Build IPA** → 右邊 **Run workflow › Run workflow**
   （上傳完成時通常已經自動開始跑了）
7. 等大約 5–10 分鐘，出現綠色勾勾 ✅ 後點進去，最下面 **Artifacts** 下載 **PlanFlow-ipa**
8. 下載的是 zip，解壓縮會得到 **`PlanFlow.ipa`**

> 如果出現紅色 ❌：點進去看紅字那一步，把錯誤訊息複製給我，我幫你修程式。

## 第二段：用 AltStore 安裝

### A. 電腦安裝 AltServer
1. 到 https://altstore.io 下載 **AltServer**（Windows 或 macOS）
2. **Windows 額外要做**：安裝 Apple 官網版的 **iTunes** 和 **iCloud**（不要用 Microsoft Store 版本），AltStore 官網有連結
3. 打開 AltServer（會出現在右下角工作列／Mac 上方選單列）

### B. 把 AltStore 裝到 iPhone
1. iPhone 用線接電腦，iPhone 上點「信任這部電腦」
2. 點 AltServer 圖示 › **Install AltStore** › 選你的 iPhone
3. 輸入 Apple ID 和密碼（只會傳給 Apple 用來簽署）
4. iPhone：**設定 › 一般 › VPN 與裝置管理** › 點你的 Apple ID › **信任**
5. iOS 16 以上：**設定 › 隱私權與安全性 › 開發者模式** 打開，手機會重新開機

### C. 安裝排程本
1. 把 `PlanFlow.ipa` 傳到 iPhone（AirDrop、存到「檔案」App 的 iCloud 雲碟、或用 LINE 傳給自己再存到檔案）
2. 打開 **AltStore › My Apps** › 左上角 **＋** › 選 `PlanFlow.ipa`
3. 等它安裝完，主畫面就會出現「排程本」🎉

---

## 一定要知道的限制（免費 Apple ID）

| 項目 | 說明 |
|---|---|
| **每 7 天要更新一次** | 免費帳號簽的 App 7 天後會打不開。iPhone 和開著 AltServer 的電腦連同一個 Wi-Fi，打開 AltStore 按 **Refresh All** 就好（AltStore 也會在背景自動更新）。**資料不會不見**。 |
| 最多 3 個 App | 免費帳號同時最多 3 個側載 App（AltStore 本身算 1 個） |
| 過期了怎麼辦 | 打不開時，連同 Wi-Fi 打開 AltStore 按 Refresh 即可，資料還在 |
| 付費開發者帳號 | 每年 US$99，簽一次可以用 1 年，也能正式上架 App Store |

## 更新 App 版本
以後我幫你改程式時：把改過的檔案上傳到 GitHub repo（覆蓋舊檔）→ Actions 會自動重新編譯 → 下載新的 `.ipa` → 在 AltStore 裡再裝一次就會覆蓋更新，資料會保留。
