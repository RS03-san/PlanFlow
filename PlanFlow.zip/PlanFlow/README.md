# 排程本（PlanFlow）— iOS 工作規劃 App

用 SwiftUI + SwiftData 寫的 iPhone App，可以直接用 Xcode 打開、上機測試、送審上架。

## 功能

| 功能 | 說明 |
|---|---|
| 未完成工作重新規劃 | 過去沒做完的工作會集中顯示；可「智慧重新規劃」一次分配到未來日期、「全部移到今天」，或單項左滑選 明天 / 後天 / 下週一 / 自訂日期 |
| 每天開啟自動提示 | 每天第一次打開 App，若有沒完成的工作，會自動跳出重新規劃畫面（設定可關閉） |
| 智慧建議排程 | 依「優先順序 → 截止日 → 所需時間」排序，放進「每日可用時間」還裝得下的最早一天，並盡量在截止日前；可選擇跳過週末 |
| 排太滿自動分散 | 某天工作量超過每日可用時間時，一鍵把優先順序低的工作分散到之後 |
| 優先順序 / 分類 | 低、中、高、緊急；分類可自訂名稱、顏色、圖示 |
| 週曆 / 月曆 | 月曆顯示每天的工作點、超量標紅；週檢視顯示每天工作量長條；長按工作可**拖到別天** |
| 截止日提醒 | 自訂提醒時間＋截止日前一天自動通知 |
| 完成率統計 | 7 / 30 天完成數長條圖、完成率、延後次數、各分類狀況、最常被延後的工作 |

資料全部存在手機本機（SwiftData），不需要伺服器、不需要登入。

---

> 📱 **只想裝到自己手機、沒有 Mac？** 看 `ALTSTORE安裝教學.md`，用 GitHub 免費編譯 + AltStore 安裝。

## 一、你需要準備

1. **Mac 電腦**，安裝最新版 **Xcode**（App Store 免費下載，需 Xcode 16 以上）
2. **Apple ID**（只在自己手機測試的話，免費帳號就可以）
3. 要上架：加入 **Apple Developer Program**，每年 US$99（約 NT$3,300）
   → https://developer.apple.com/programs/enroll/

## 二、打開專案、在手機上跑

1. 解壓縮 `PlanFlow.zip`，雙擊 `PlanFlow.xcodeproj`
2. 左側點最上面藍色的 **PlanFlow** → 中間選 **TARGETS › PlanFlow** → **Signing & Capabilities**
3. **Team**：選你的 Apple ID（沒有的話按 Add Account 登入）
4. **Bundle Identifier**：把 `com.yourname.planflow` 改成獨一無二的，例如 `com.sandra.planflow`
5. iPhone 用線接上 Mac，最上方裝置選單選你的 iPhone，按 ▶︎（或 ⌘R）
6. 第一次會要求：iPhone **設定 › 隱私權與安全性 › 開發者模式** 打開；以及 **設定 › 一般 › VPN 與裝置管理** 信任你的開發者憑證

> 沒有 iPhone 也可以：裝置選單選任一個模擬器（例如 iPhone 17 Pro）按 ▶︎。

## 三、上架 App Store 步驟

### 1. 上架前一定要改的地方
- [ ] Bundle Identifier（上面第 4 步）
- [ ] `PlanFlow/Views/SettingsView.swift` 裡的 `privacyURL` 換成你的隱私權政策網址（見下方第 3 點）
- [ ] App 名稱：目前顯示名稱是「排程本」，在 TARGETS › General › Display Name 可改。App Store 上的名稱不能和別人重複，先到 App Store Connect 確認可用

### 2. 在 App Store Connect 建立 App
1. 到 https://appstoreconnect.apple.com → **我的 App** → 左上 **＋ › 新增 App**
2. 平台 iOS；名稱；主要語言 **繁體中文**；套件識別碼選剛剛那個 Bundle ID；SKU 隨便填（例如 planflow001）

### 3. 準備隱私權政策網址（必填）
`PRIVACY.md` 已經寫好內容。最簡單的方式：
- 用 **Notion** 建一頁貼上內容 → 右上 Share › Publish to web → 複製網址；或
- 放到 **GitHub Pages** / Google Sites

### 4. 上傳 App
1. Xcode 上方裝置選單選 **Any iOS Device (arm64)**
2. 選單 **Product › Archive**（等幾分鐘）
3. 跳出 Organizer 視窗 → **Distribute App** → **App Store Connect** → 一路 Next / Upload
4. 約 10–30 分鐘後，App Store Connect 的 **TestFlight** 分頁會出現這個版本（可以先用 TestFlight 在手機上測）

### 5. 填寫商店資訊（`APPSTORE_LISTING.md` 有現成文案可以複製）
- **截圖**：至少要 **6.9 吋 iPhone** 的截圖（1320 × 2868 或 1290 × 2796）。在 Xcode 用 **iPhone 17 Pro Max**（或 16 Pro Max）模擬器執行，按 ⌘S 存截圖，建議 3–5 張：今天頁、重新規劃畫面、月曆、統計
- 描述、關鍵字、支援網址（可以先填隱私權政策同一個網址或你的 Email 聯絡頁）
- **App 隱私權** → 選「**不收集資料**」（這個 App 確實不收集任何資料）
- **年齡分級** → 問卷全部選「無」→ 4+
- **類別**：生產力工具（Productivity）
- **價格**：免費或自訂
- 選擇剛剛上傳的版本（Build）
- **出口合規 / 加密**：問到時選「**否 / None of the algorithms mentioned above**」（App 沒有用到加密）

### 6. 送審
按 **新增以供審查 → 提交**。通常 1–3 天會有結果，被退件的話 Apple 會說明原因，修正後重新送出即可。

---

## 常見問題

- **打不開專案 / 顯示版本不支援**：請更新 Xcode 到 16 以上。若還是不行，可以安裝 XcodeGen（Terminal 執行 `brew install xcodegen`），在這個資料夾執行 `xcodegen`，會用 `project.yml` 重新產生專案檔。
- **Signing 出現紅字**：通常是 Team 沒選，或 Bundle ID 跟別人重複，換一個就好。
- **編譯錯誤**：把 Xcode 上的錯誤訊息（紅色那行）整段複製給我，我幫你修。
- **想加 iPad 版**：TARGETS › General › Supported Destinations 加 iPad，但上架時也要多準備 iPad 截圖。

## 專案結構

```
PlanFlow/
├─ PlanFlow.xcodeproj        ← 雙擊打開
├─ project.yml               ← 備用（XcodeGen）
└─ PlanFlow/
   ├─ PlanFlowApp.swift      App 進入點
   ├─ AppDelegate.swift      通知顯示設定
   ├─ Models/                TaskItem（工作）、TaskCategory（分類）、Priority（優先順序）
   ├─ Services/
   │   ├─ Scheduler.swift    ★ 智慧排程演算法
   │   ├─ TaskActions.swift  完成 / 重新規劃 / 刪除
   │   ├─ NotificationManager.swift  提醒通知
   │   └─ DateHelpers.swift  日期工具、設定 key
   ├─ Views/                 今天、行事曆、統計、設定、重新規劃、編輯畫面
   ├─ Assets.xcassets        App 圖示、主題色
   └─ PrivacyInfo.xcprivacy  Apple 要求的隱私清單
```

需求：iOS 17 以上、iPhone。
